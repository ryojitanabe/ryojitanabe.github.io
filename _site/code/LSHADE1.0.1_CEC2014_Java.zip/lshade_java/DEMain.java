/*
  L-SHADE implemented by Java for solving CEC2014 benchmarks

  First version: 9/Oct/2014
  Written by Ryoji Tanabe (rt.ryoji.tanabe [at] gmail.com)
*/

import java.text.DecimalFormat;
import java.io.*;
import java.util.Scanner;

public class DEMain {
    public static void main(String[] args) throws Exception{		
	DecimalFormat exp_form = new DecimalFormat("0.00000000E0");
	int num_runs = 51;
	int problem_size = 10;
    
	//parameter settings for SHADE
	int pop_size = 18 * problem_size;
	double arc_rate = 1.4;
	double p_best_rate = 0.11;
	int memory_size = 5;
    
	double[] bsf_error_array = new double[num_runs];
	double mean_error, std_error;
    

	for (int func_num = 1; func_num <= 30; func_num++) {
	    System.out.println("\n-------------------------------------------------------");
	    System.out.println("Function = " + func_num + ", Dimension size = " + problem_size + "\n");
    
	    for (int run_id = 0; run_id < num_runs; run_id++) {
		Lshade alg = new Lshade(func_num, problem_size, pop_size, arc_rate, p_best_rate, memory_size);
		bsf_error_array[run_id] = alg.run();
		System.out.println((run_id + 1) + "th run, error value = " + exp_form.format(bsf_error_array[run_id]));
	    }
	    System.out.println();

	    mean_error = 0;
	    std_error = 0;

	    for (int j = 0; j < num_runs; j++) mean_error += bsf_error_array[j];
	    mean_error /= num_runs;

	    for (int j = 0; j < num_runs; j++) std_error += Math.pow((mean_error - bsf_error_array[j]), 2.0);
	    std_error /= num_runs;
	    std_error = Math.sqrt(std_error);

	    System.out.println("\nmean = " + exp_form.format(mean_error) + ", std = " + exp_form.format(std_error));
	}
    }
}
