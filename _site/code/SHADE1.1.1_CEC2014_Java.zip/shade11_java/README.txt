Author: Ryoji Tanabe
Date: 9/Oct/2014

###
This package is a Java source code of SHADE 1.1.1.
Please note that this source code is transferred from the C++ source code of SHADE 1.1.1.
Where, the version (1.1.0) for the experiment in the following paper had a bug in the archive update mechanism which resulted in a slight performance degradation.
Version 1.1.1 fixes the bug and achieves slightly better performance compared to 1.1.0.

About SHADE 1.1, please see the following paper:

* Ryoji Tanabe, Alex S. Fukunaga: Improving the search performance of SHADE using linear population size reduction. IEEE Congress on Evolutionary Computation 2014: 1658-1665.

###
System configurations in our experimental environment:

OS: Ubuntu 12.04 LTS
CPU: core i7 (2.20GHz)
RAM: 8GB
Language: Java

###
How to execute:

Step 1. javac *.java
Step 2. java DEMain

###
Dimension size and parameter settings of the algorithm are easily changeable by rewriting source code in "DEMain.java"
If you have any questions, please feel free to contact me (rt.ryoji.tanabe@gmail.com).
