/*
  SHADE 1.1 implemented by Java for solving CEC2014 benchmarks

  First version: 9/Oct/2014
  Written by Ryoji Tanabe (rt.ryoji.tanabe [at] gmail.com)
*/

import java.text.DecimalFormat;
import java.util.*;

public class Shade {
    //problem's settings
    int func_num;
    int problem_size;
    double max_region;
    double min_region;
    double optimum;
    double val_2_reach;
    int max_func_evals;
    int nfes;
    
    //algorithm's settings
    int pop_size;
    int arc_size;
    double arc_rate;
    double p_best_rate;
    int memory_size;

    double[][] pop;
    double[] fitness;
    double[][] children;
    double[] children_fitness;
    double[] bsf_solution;
    double bsf_fitness;

    // LinkedList<Double> archive;
    double[][] archive;
    int num_arc_inds;

    boolean isStopCriteriaMet;
    DecimalFormat exp_form;

    Shade (int func_num, int problem_size, int pop_size, double arc_rate, double p_best_rate, int memory_size) {
	//problem's initialization
	this.func_num = func_num;
	this.problem_size = problem_size;
	this.max_region = 100;
	this.min_region = -100;
	this.optimum = 100 * func_num;
	this.val_2_reach = 1e-8;
	this.max_func_evals = 10000 * problem_size;
	this.nfes = 0;

	//algorithm's initialization
	this.pop_size = pop_size;
	this.arc_rate = arc_rate;
	this.arc_size = (int)Math.round(arc_rate * pop_size);
	this.p_best_rate = p_best_rate;
	this.memory_size = memory_size;

	this.pop = new double[pop_size][problem_size];
	this.fitness = new double[pop_size];
	this.children = new double[pop_size][problem_size];
	this.children_fitness = new double[pop_size];
	
	this.bsf_solution = new double[problem_size];
	this.bsf_fitness = 1e+30;	
	this.archive = new double[arc_size][problem_size];
	this.num_arc_inds = 0;
	//	this.archive = new LinkedList<Double>();

	isStopCriteriaMet = false;
	exp_form = new DecimalFormat("0.00000000E0");
    }

    /*
      Return random value from Cauchy distribution with mean "mu" and variance "gamma"
      http://www.sat.t.u-tokyo.ac.jp/~omi/random_variables_generation.html#Cauchy
    */
    double cauchy_g(double mu, double gamma) {
	return mu + gamma * Math.tan(Math.PI*(Math.random() - 0.5));
    }

    /*
      Return random value from normal distribution with mean "mu" and variance "gamma"
      http://www.sat.t.u-tokyo.ac.jp/~omi/random_variables_generation.html#Gauss
    */
    double gauss(double mu, double sigma){
	return mu + sigma * Math.sqrt(-2.0 * Math.log(Math.random())) * Math.sin(2.0 * Math.PI * Math.random());
    }

    void makeNewIndividual(double[] ind) {
	for (int i = 0; i < problem_size; i++) ind[i] = ((max_region - min_region) * Math.random()) + min_region;	
    }

    void updateBSFSolution() {
    	for (int i = 0; i < pop_size; i++) {
    	    nfes++;

    	    if ((fitness[i] - optimum) < val_2_reach) fitness[i] = optimum;

    	    if (fitness[i] < bsf_fitness) {
    		bsf_fitness = fitness[i];
    		for (int j = 0; j < problem_size; j ++) bsf_solution[j] = pop[i][j];

		if (bsf_fitness == optimum) {
		    isStopCriteriaMet = true;
		    break;
		}
    	    }

    	    // if (nfes % 1000 == 0) {
	    // 	System.out.println(nfes + " " + exp_form.format(bsf_fitness - optimum));
    	    // }

    	    if (nfes >= max_func_evals) {
		isStopCriteriaMet = true;
		break;
		//System.exit(1);
	    }
    	}
    }

    void sortIndexWithQuickSort(double[] array, int first, int last, int[] index) {
	double x = array[(first + last) / 2];
	int i = first;
	int j = last;
	double temp_var = 0;
	int temp_num = 0;

	while (true) {
	    while (array[i] < x) i++;
	    while (x < array[j]) j--;      
	    if (i >= j) break;

	    temp_var = array[i];
	    array[i] = array[j];
	    array[j] = temp_var;

	    temp_num = index[i];
	    index[i] = index[j];
	    index[j] = temp_num;

	    i++;
	    j--;
	}

	if (first < (i -1)) sortIndexWithQuickSort(array, first, i - 1, index);
	if ((j + 1) < last) sortIndexWithQuickSort(array, j + 1, last, index);
    }




    void operateCurrentToPBest1BinWithArchive(int target, int p_best_individual, double scaling_factor, double cross_rate) {
	int r1, r2;
  
	do {
	    r1 = (int)(Math.random() * pop_size);
	} while (r1 == target);
	do {
	    r2 = (int)(Math.random() * (pop_size + num_arc_inds));
	} while ((r2 == target) || (r2 == r1));

	int random_variable = (int)(Math.random() * problem_size);
  
	if (r2 >= pop_size) {
	    r2 -= pop_size;
	    for (int i = 0; i < problem_size; i++) {
		if ((Math.random() < cross_rate) || (i == random_variable)) children[target][i] = pop[target][i] + scaling_factor * (pop[p_best_individual][i] - pop[target][i]) + scaling_factor * (pop[r1][i] - archive[r2][i]);
		else children[target][i] = pop[target][i];
	    }
	}
	else {
	    for (int i = 0; i < problem_size; i++) {
		if ((Math.random() < cross_rate) || (i == random_variable)) children[target][i] = pop[target][i] + scaling_factor * (pop[p_best_individual][i] - pop[target][i]) + scaling_factor * (pop[r1][i] - pop[r2][i]);
		else children[target][i] = pop[target][i];
	    }
	}

	//If the mutant vector violates bounds, the bound handling method is applied
	// For each dimension j, if the mutant vector element v_j is outside the boundaries [x_min , x_max], we applied this bound handling method
	// If you'd like to know that precisely, please see:
	// J. Zhang and A. C. Sanderson, "JADE: Adaptive differential evolution with optional external archive,"
	// IEEE Tran. Evol. Comput., vol. 13, no. 5, pp. 945–958, 2009.
	
	for (int i = 0; i < problem_size; i++) {
	    if (children[target][i] < min_region) children[target][i] = (min_region + pop[target][i]) / 2.0;	  
	    else if (children[target][i] > max_region) children[target][i] = (max_region + pop[target][i]) / 2.0;	    
	}

	//	modifySolutionWithParentMedium(child,  pop[target]);
    }


    double run() throws Exception{
	testfunc tf = new testfunc();

	for (int i = 0; i < pop_size; i++) makeNewIndividual(pop[i]);
	for (int i = 0; i < pop_size; i++)  fitness[i] = tf.getFunctionValueWrapper(pop[i], problem_size, 1, func_num);
	updateBSFSolution();

	// //for external archive
	int rand_arc_ind;

	int num_success_params;

	double[] success_sf = new double[pop_size];
	double[] success_cr = new double[pop_size];
	double[] dif_fitness = new double[pop_size];

	// the contents of M_f and M_cr are all initialiezed 0.5
	double[] memory_sf = new double[memory_size];
	double[] memory_cr = new double[memory_size];

	for (int i = 0; i < memory_size; i++) {
	    memory_sf[i] = 0.5;
	    memory_cr[i] = 0.5;
	}

	//memory index counter
	int memory_pos = 0;
	double temp_sum_sf1, temp_sum_sf2, temp_sum_cr1, temp_sum_cr2, temp_sum, temp_weight;

	//for new parameters sampling
	double mu_sf, mu_cr;
	int rand_mem_index;

	double[] pop_sf = new double[pop_size];
	double[] pop_cr = new double[pop_size];

	//for current-to-pbest/1
	int p_best_ind;
	int p_num = (int)Math.round(pop_size *  p_best_rate);
	int[] sorted_array = new int[pop_size];
	double[] sorted_fitness = new double[pop_size];

	//main loop
	while (nfes < max_func_evals) {
	    for (int i = 0; i < pop_size; i++) sorted_array[i] = i;
	    for (int i = 0; i < pop_size; i++) sorted_fitness[i] = fitness[i];

	    sortIndexWithQuickSort(sorted_fitness, 0, pop_size - 1, sorted_array);

	    for (int target = 0; target < pop_size; target++) {
		rand_mem_index = (int)(Math.random()*memory_size);
		mu_sf = memory_sf[rand_mem_index];
		mu_cr = memory_cr[rand_mem_index];

		//generate CR_i and repair its value
		if (mu_cr == -1) {
		    pop_cr[target] = 0;
		}
		else {
		    pop_cr[target] = gauss(mu_cr, 0.1);
		    if (pop_cr[target] > 1) pop_cr[target] = 1;
		    else if (pop_cr[target] < 0) pop_cr[target] = 0;	
		}
      
		//generate F_i and repair its value
		do {	
		    pop_sf[target] = cauchy_g(mu_sf, 0.1);
		} while (pop_sf[target] <= 0);

		if (pop_sf[target] > 1) pop_sf[target] = 1;

		//p-best individual is randomly selected from the top pop_size *  p_i members
		p_best_ind = sorted_array[(int)(Math.random() * p_num)];

		operateCurrentToPBest1BinWithArchive(target, p_best_ind, pop_sf[target], pop_cr[target]);
	    }

	    for (int i = 0; i < pop_size; i++)  children_fitness[i] = tf.getFunctionValueWrapper(children[i], problem_size, 1, func_num);
	    updateBSFSolution();
	    if(isStopCriteriaMet) break;

	    num_success_params = 0;

	    //generation alternation
	    for (int i = 0; i < pop_size; i++) {
		if (children_fitness[i] == fitness[i]) {
		    fitness[i] = children_fitness[i];
		    for (int j = 0; j < problem_size; j ++) pop[i][j] = children[i][j];
		}
		else if (children_fitness[i] < fitness[i]) {
		    //parent vectors x_i which were worse than the trial vectors u_i are preserved
		    if (arc_size > 1) { 
			if (num_arc_inds < arc_size) {
			    //			    System.out.println(num_arc_inds + " " + arc_size);
			    for (int j = 0; j < problem_size; j++) archive[num_arc_inds][j] = pop[i][j];
			    num_arc_inds++;
			    
			}
			//Whenever the size of the archive exceeds, randomly selected elements are deleted to make space for the newly inserted elements
			else {
			    rand_arc_ind = (int)(Math.random() * arc_size);
			    for (int j = 0; j < problem_size; j++) archive[rand_arc_ind][j] = pop[i][j];	    
			}
		    }

		    dif_fitness[num_success_params] = Math.abs(fitness[i] - children_fitness[i]);

		    fitness[i] = children_fitness[i];
		    for (int j = 0; j < problem_size; j ++) pop[i][j] = children[i][j];
  	
		    //successful parameters are preserved in S_F and S_CR
		    success_sf[num_success_params] = pop_sf[i];
		    success_cr[num_success_params] = pop_cr[i];
		    num_success_params++;
		}
	    }
  
	    if (num_success_params > 0) {
		temp_sum_sf1 = 0;
		temp_sum_sf2 = 0;
		temp_sum_cr1 = 0;
		temp_sum_cr2 = 0;
		temp_sum = 0;
		temp_weight = 0;

		for (int i = 0; i < num_success_params; i++) temp_sum += dif_fitness[i];
      
		//weighted lehmer mean
		for (int i = 0; i < num_success_params; i++) {
		    temp_weight = dif_fitness[i] / temp_sum;

		    temp_sum_sf1 += temp_weight * success_sf[i] * success_sf[i];
		    temp_sum_sf2 += temp_weight * success_sf[i];

		    temp_sum_cr1 += temp_weight * success_cr[i] * success_cr[i];
		    temp_sum_cr2 += temp_weight * success_cr[i];
		}

		memory_sf[memory_pos] = temp_sum_sf1 / temp_sum_sf2;

		if (temp_sum_cr2 == 0 || memory_cr[memory_pos] == -1) memory_cr[memory_pos] = -1;
		else memory_cr[memory_pos] = temp_sum_cr1 / temp_sum_cr2;

		//increment the counter
		memory_pos++;
		if (memory_pos >= memory_size) memory_pos = 0;
	    }
	}

	return bsf_fitness - optimum;

	// for (int i = 0; i < pop_size; i++) {
	// 	System.out.println(pop_sf[i] + " " + pop_cr[i]);
	// }

	// for (int i = 0; i < pop_size; i++) {
	//     for (int j = 0; j < problem_size; j++) {
	//     	System.out.print(pop[i][j] + " ");
	//     }
	//     System.out.println("     " + fitness[i]);
	// }

	// System.out.println("-------------------------  ");
	// for (int j = 0; j < problem_size; j++) {
	//     System.out.print(bsf_solution[j] + " ");
	// }
	// System.out.println("     " + exp_form.format(bsf_fitness));

	// System.out.println(nfes);

	// if ((fitness[0] - optimum) < epsilon) fitness[0] = optimum;
	// bsf_fitness = fitness[0];
	// for (int j = 0; j < problem_size; j ++) bsf_solution[j] = pop[0][j];


    }

}