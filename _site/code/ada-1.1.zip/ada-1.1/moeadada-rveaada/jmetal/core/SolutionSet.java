//  SolutionSet.Java
//
//  Author:
//       Antonio J. Nebro <antonio@lcc.uma.es>
//       Juan J. Durillo <durillo@lcc.uma.es>
//
//  Copyright (c) 2011 Antonio J. Nebro, Juan J. Durillo
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.core;

import jmetal.util.Configuration;

import java.io.*;
import java.util.*;

import jmetal.util.JMException;
import jmetal.util.wrapper.XReal;

/** 
 * Class representing a SolutionSet (a set of solutions)
 */
public class SolutionSet implements Serializable {

  /**
   * Stores a list of <code>solution</code> objects.
   */
  protected final List<Solution> solutionsList_;

  /** 
   * Maximum size of the solution set 
   */
  private int capacity_ = 0; 

  /**
   * Constructor.
   * Creates an unbounded solution set.
   */
  public SolutionSet() {
    solutionsList_ = new ArrayList<Solution>();
  } // SolutionSet

  /** 
   * Creates a empty solutionSet with a maximum capacity.
   * @param maximumSize Maximum size.
   */
  public SolutionSet(int maximumSize){    
    solutionsList_ = new ArrayList<Solution>();
    capacity_      = maximumSize;
  } // SolutionSet

  /** 
   * Inserts a new solution into the SolutionSet. 
   * @param solution The <code>Solution</code> to store
   * @return True If the <code>Solution</code> has been inserted, false 
   * otherwise. 
   */
  public boolean add(Solution solution) {
    if (solutionsList_.size() == capacity_) {
      Configuration.logger_.severe("The population is full");
      Configuration.logger_.severe("Capacity is : "+capacity_);
      Configuration.logger_.severe("\t Size is: "+ this.size());
      System.exit(1);
      return false;
    } // if

    solutionsList_.add(solution);
    return true;
  } // add

  public boolean add(int index, Solution solution) {
    solutionsList_.add(index, solution) ;
    return true ;
  }
  /*
  public void add(Solution solution) {
    if (solutionsList_.size() == capacity_)
      try {
        throw new JMException("SolutionSet.Add(): the population is full") ;
      } catch (JMException e) {
        e.printStackTrace();
      }
    else
      solutionsList_.add(solution);
  }
  */
  /**
   * Returns the ith solution in the set.
   * @param i Position of the solution to obtain.
   * @return The <code>Solution</code> at the position i.
   * @throws IndexOutOfBoundsException Exception
   */
  public Solution get(int i) {
    if (i >= solutionsList_.size()) {
      throw new IndexOutOfBoundsException("Index out of Bound "+i);
    }
    return solutionsList_.get(i);
  } // get

  /**
   * Returns the maximum capacity of the solution set
   * @return The maximum capacity of the solution set
   */
  public int getMaxSize(){
    return capacity_ ;
  } // getMaxSize

  /** 
   * Sorts a SolutionSet using a <code>Comparator</code>.
   * @param comparator <code>Comparator</code> used to sort.
   */
  public void sort(Comparator comparator){
    if (comparator == null) {
      Configuration.logger_.severe("No criterium for comparing exist");
      return ;
    } // if
    Collections.sort(solutionsList_,comparator);
  } // sort

  /** 
   * Returns the index of the best Solution using a <code>Comparator</code>.
   * If there are more than one occurrences, only the index of the first one is returned
   * @param comparator <code>Comparator</code> used to compare solutions.
   * @return The index of the best Solution attending to the comparator or 
   * <code>-1<code> if the SolutionSet is empty
   */
   int indexBest(Comparator comparator){
    if ((solutionsList_ == null) || (this.solutionsList_.isEmpty())) {
      return -1;
    }

    int index = 0; 
    Solution bestKnown = solutionsList_.get(0), candidateSolution;
    int flag;
    for (int i = 1; i < solutionsList_.size(); i++) {        
      candidateSolution = solutionsList_.get(i);
      flag = comparator.compare(bestKnown, candidateSolution);
      if (flag == +1) {
        index = i;
        bestKnown = candidateSolution; 
      }
    }

    return index;
  } // indexBest


  /** 
   * Returns the best Solution using a <code>Comparator</code>.
   * If there are more than one occurrences, only the first one is returned
   * @param comparator <code>Comparator</code> used to compare solutions.
   * @return The best Solution attending to the comparator or <code>null<code>
   * if the SolutionSet is empty
   */
  public Solution best(Comparator comparator){
    int indexBest = indexBest(comparator);
    if (indexBest < 0) {
      return null;
    } else {
      return solutionsList_.get(indexBest);
    }

  } // best  


  /** 
   * Returns the index of the worst Solution using a <code>Comparator</code>.
   * If there are more than one occurrences, only the index of the first one is returned
   * @param comparator <code>Comparator</code> used to compare solutions.
   * @return The index of the worst Solution attending to the comparator or 
   * <code>-1<code> if the SolutionSet is empty
   */
  public int indexWorst(Comparator comparator){
    if ((solutionsList_ == null) || (this.solutionsList_.isEmpty())) {
      return -1;
    }

    int index = 0;
    Solution worstKnown = solutionsList_.get(0), candidateSolution;
    int flag;
    for (int i = 1; i < solutionsList_.size(); i++) {        
      candidateSolution = solutionsList_.get(i);
      flag = comparator.compare(worstKnown, candidateSolution);
      if (flag == -1) {
        index = i;
        worstKnown = candidateSolution;
      }
    }

    return index;

  } // indexWorst

  /** 
   * Returns the worst Solution using a <code>Comparator</code>.
   * If there are more than one occurrences, only the first one is returned
   * @param comparator <code>Comparator</code> used to compare solutions.
   * @return The worst Solution attending to the comparator or <code>null<code>
   * if the SolutionSet is empty
   */
  public Solution worst(Comparator comparator){

    int index = indexWorst(comparator);
    if (index < 0) {
      return null;
    } else {
      return solutionsList_.get(index);
    }

  } // worst


  /** 
   * Returns the number of solutions in the SolutionSet.
   * @return The size of the SolutionSet.
   */  
  public int size(){
    return solutionsList_.size();
  } // size

  /** 
   * Writes the objective function values of the <code>Solution</code> 
   * objects into the set in a file.
   * @param path The output file name
   */
  public void printObjectivesToFile(String path){
    try {
      /* Open the file */
      FileOutputStream fos   = new FileOutputStream(path)     ;
      OutputStreamWriter osw = new OutputStreamWriter(fos)    ;
      BufferedWriter bw      = new BufferedWriter(osw)        ;

      // bw.write("#");
      // bw.newLine();

      int numberOfObjectives = solutionsList_.get(0).getNumberOfObjectives();
    
      for (Solution aSolutionsList_ : solutionsList_) {
	  for (int j = 0; j < numberOfObjectives - 1; j++) bw.write(aSolutionsList_.getObjective(j) + " ");
	  bw.write(aSolutionsList_.getObjective(numberOfObjectives - 1) + "");

          // for (int j = 0; j < numberOfObjectives - 1; j++) bw.write(aSolutionsList_.getObjective(j).toString() + " ");

          bw.newLine();
	  
        // //if (this.vector[i].getFitness()<1.0) {
        // bw.write(aSolutionsList_.toString());
        // bw.newLine();
        // //}
      }

      // bw.write("#");
      // bw.newLine();

      /* Close the file */
      bw.close();
    }catch (IOException e) {
      Configuration.logger_.severe("Error acceding to the file");
      e.printStackTrace();
    }
  } // printObjectivesToFile

  /**
   * Writes the decision encodings.variable values of the <code>Solution</code>
   * solutions objects into the set in a file.
   * @param path The output file name
   */
  public void printVariablesToFile(String path){
    try {
      FileOutputStream fos   = new FileOutputStream(path)     ;
      OutputStreamWriter osw = new OutputStreamWriter(fos)    ;
      BufferedWriter bw      = new BufferedWriter(osw)        ;            

      if (size()>0) {
        int numberOfVariables = solutionsList_.get(0).getDecisionVariables().length ;
        for (Solution aSolutionsList_ : solutionsList_) {
          for (int j = 0; j < numberOfVariables - 1; j++)
            bw.write(aSolutionsList_.getDecisionVariables()[j].toString() + " ");
	  bw.write(aSolutionsList_.getDecisionVariables()[numberOfVariables - 1].toString());
          bw.newLine();
        }
      }
      bw.close();
    }catch (IOException e) {
      Configuration.logger_.severe("Error acceding to the file");
      e.printStackTrace();
    }       
  } // printVariablesToFile



  /**
   * Writes the decision encodings.variable values of the <code>Solution</code>
   * solutions objects into the set in a file.
   * @param path The output file name
   */
  public void printObjValAndVariablesToFile(String path){
    try {
      FileOutputStream fos   = new FileOutputStream(path)     ;
      OutputStreamWriter osw = new OutputStreamWriter(fos)    ;
      BufferedWriter bw      = new BufferedWriter(osw)        ;            

      if (size()>0) {
        int numberOfVariables = solutionsList_.get(0).getDecisionVariables().length ;
        int numberOfObjectives = solutionsList_.get(0).getNumberOfObjectives();

        for (Solution aSolutionsList_ : solutionsList_) {
	    for (int j = 0; j < numberOfObjectives; j++) bw.write(aSolutionsList_.getObjective(j) + " ");

	    for (int j = 0; j < numberOfVariables - 1; j++) bw.write(aSolutionsList_.getDecisionVariables()[j].toString() + " ");
	    bw.write(aSolutionsList_.getDecisionVariables()[numberOfVariables - 1].toString());

          bw.newLine();
        }
      }
      bw.close();
    }catch (IOException e) {
      Configuration.logger_.severe("Error acceding to the file");
      e.printStackTrace();
    }       
  } // printVariablesToFile




  /**
   * Write the number of individuals assigned to each subproblem into a file
   * @param path File name
   */
    public void printNumOfIndsEachSubproblem(String path, int numOfSubproblems) {
    try {
      FileOutputStream fos   = new FileOutputStream(path)     ;
      OutputStreamWriter osw = new OutputStreamWriter(fos)    ;
      BufferedWriter bw      = new BufferedWriter(osw)        ;

      int[] numOfInds = new int[numOfSubproblems];
      int tmpVar;
      
      for (int i = 0; i < numOfSubproblems; i++) numOfInds[i] = 0;

      for (int i = 0; i < solutionsList_.size(); i++) {
	  tmpVar = solutionsList_.get(i).getSubProbID();
	  numOfInds[tmpVar]++;
      }

      for (int i = 0; i < numOfSubproblems; i++) {
	  bw.write(numOfInds[i] + "");
	  bw.newLine();
      }

      bw.close();
    }catch (IOException e) {
      Configuration.logger_.severe("Error acceding to the file");
      e.printStackTrace();
    }
  }

  /**
   * Write the current population size of MOEA/D-AD into a file
   * @param path File name
   */
  public void printPopulationSize(String path) {
    try {
      FileOutputStream fos   = new FileOutputStream(path)     ;
      OutputStreamWriter osw = new OutputStreamWriter(fos)    ;
      BufferedWriter bw      = new BufferedWriter(osw)        ;

      int currentPopulationSize = solutionsList_.size();

      bw.write(currentPopulationSize + "");
      bw.newLine();
      bw.close();
    }catch (IOException e) {
      Configuration.logger_.severe("Error acceding to the file");
      e.printStackTrace();
    }
  }


  /**
   * Write the function values of feasible solutions into a file
   * @param path File name
   */
  public void printFeasibleFUN(String path) {
    try {
      FileOutputStream fos   = new FileOutputStream(path)     ;
      OutputStreamWriter osw = new OutputStreamWriter(fos)    ;
      BufferedWriter bw      = new BufferedWriter(osw)        ;

      int numberOfObjectives = solutionsList_.get(0).getNumberOfObjectives();	

      for (Solution aSolutionsList_ : solutionsList_) {
        if (aSolutionsList_.getOverallConstraintViolation() == 0.0) {
	    for (int j = 0; j < numberOfObjectives - 1; j++) bw.write(aSolutionsList_.getObjective(j) + " ");
	    bw.write(aSolutionsList_.getObjective(numberOfObjectives - 1) + "");
	    //	    bw.write(aSolutionsList_.toString());
	    bw.newLine();
        }
      }
      bw.close();
    }catch (IOException e) {
      Configuration.logger_.severe("Error acceding to the file");
      e.printStackTrace();
    }
  }



  /**
   * Write the encodings.variable values of feasible solutions into a file
   * @param path File name
   */
  public void printFeasibleVAR(String path) {
    try {
      FileOutputStream fos   = new FileOutputStream(path)     ;
      OutputStreamWriter osw = new OutputStreamWriter(fos)    ;
      BufferedWriter bw      = new BufferedWriter(osw)        ;            

      if (size()>0) {
        int numberOfVariables = solutionsList_.get(0).getDecisionVariables().length ;
        for (Solution aSolutionsList_ : solutionsList_) {
          if (aSolutionsList_.getOverallConstraintViolation() == 0.0) {
            for (int j = 0; j < numberOfVariables; j++)
              bw.write(aSolutionsList_.getDecisionVariables()[j].toString() + " ");
            bw.newLine();
          }
        }
      }
      bw.close();
    }catch (IOException e) {
      Configuration.logger_.severe("Error acceding to the file");
      e.printStackTrace();
    }       
  }
  
  /** 
   * Empties the SolutionSet
   */
  public void clear(){
    solutionsList_.clear();
  } // clear

  /** 
   * Deletes the <code>Solution</code> at position i in the set.
   * @param i The position of the solution to remove.
   */
  public void remove(int i){        
    if (i > solutionsList_.size()-1) {            
      Configuration.logger_.severe("Size is: "+this.size());
    } // if
    solutionsList_.remove(i);    
  } // remove


    public void setNormalizedObjectiveFunctionValues(double[] z_, double[] nad_){        
      double number_of_objectives =  this.get(0).getNumberOfObjectives();
      double tmp_normalized_value;

      for (int k = 0; k < number_of_objectives; k++) {
	  for (int i = 0; i < this.size(); i++) {
	      tmp_normalized_value = (this.get(i).getObjective(k) - z_[k]) / (nad_[k] - z_[k]);
	      this.get(i).setNormalizedObjective(k, tmp_normalized_value);      	 
	  }
	}
  }


    public void setDensityValues(){        
	double number_of_objectives =  this.get(0).getNumberOfObjectives();
	double [][] distance_matrix = new double[this.size()][this.size()];
	double tmp_sum_value;
	double encouraging, discouraging;
	double nich_radius = 1.0 / Math.pow(this.size(), 1.0 / number_of_objectives);
	double tmp_val_i, tmp_val_j;

	for (int i = 0; i < this.size(); i++) {
	    for(int j = i + 1; j < this.size(); j++) {
		tmp_sum_value = 0;
		for (int k = 0; k < number_of_objectives; k++) {
		    tmp_sum_value += (this.get(i).getNormalizedObjective(k) - this.get(j).getNormalizedObjective(k)) * (this.get(i).getNormalizedObjective(k) - this.get(j).getNormalizedObjective(k));
		}
		distance_matrix[i][j] = Math.sqrt(tmp_sum_value);
		distance_matrix[j][i] = distance_matrix[i][j];
	    }
	    distance_matrix[i][i] = 1e+30;
	}

	for (int i = 0; i < this.size(); i++) this.get(i).setDensityValue(0.0);

	for (int i = 0; i < this.size(); i++) {
	    for (int j = i + 1; j < this.size(); j++) {
		if (distance_matrix[i][j] < nich_radius) {
		    encouraging = Math.pow(0.5 * (1.0 - (distance_matrix[i][j] / nich_radius)), 2.0);
		    discouraging = Math.pow(1.5 * (1.0 - (distance_matrix[i][j] / nich_radius)), 2.0);

		    if (this.get(i).getSumMinValue() > this.get(j).getSumMinValue()) {
			tmp_val_i = this.get(i).getDensityValue() + discouraging;
			tmp_val_j = this.get(j).getDensityValue() + encouraging;
		    }
		    else if (this.get(i).getSumMinValue() < this.get(j).getSumMinValue()) {
			tmp_val_i = this.get(i).getDensityValue() + encouraging;
			tmp_val_j = this.get(j).getDensityValue() + discouraging;
		    }
		    else {
			if (Math.random() < 0.5) {
			    tmp_val_i = this.get(i).getDensityValue() + discouraging;
			    tmp_val_j = this.get(j).getDensityValue() + encouraging;
			}
			else {
			    tmp_val_i = this.get(i).getDensityValue() + encouraging;
			    tmp_val_j = this.get(j).getDensityValue() + discouraging;
			}
		    }

		    this.get(i).setDensityValue(tmp_val_i);
		    this.get(j).setDensityValue(tmp_val_j);			
		}
	    }
	}    

	for (int i = 0; i < this.size(); i++) {
	    tmp_val_i = Math.sqrt(this.get(i).getDensityValue());
	    this.get(i).setDensityValue(tmp_val_i);
	}
    }



    public void setDensityValuesSolutionSpace() throws JMException, ClassNotFoundException{        
	double number_of_variables =  this.get(0).numberOfVariables();
	double [][] distance_matrix = new double[this.size()][this.size()];
	double tmp_sum_value;
	double encouraging, discouraging;
	double nich_radius = 1.0 / Math.pow(this.size(), 1.0 / number_of_variables);
	double tmp_val_i, tmp_val_j;

	XReal tmp_individual = new XReal(this.get(0));
	double tmp_value_for_distance;

	for (int i = 0; i < this.size(); i++) {
	    for(int j = i + 1; j < this.size(); j++) {
		tmp_sum_value = 0;
		Variable[] decisionVariablesParent1  = this.get(i).getDecisionVariables();
		Variable[] decisionVariablesParent2  = this.get(j).getDecisionVariables();

		for (int k = 0; k < number_of_variables; k++) {
		    tmp_value_for_distance = (decisionVariablesParent1[k].getValue() - decisionVariablesParent2[k].getValue()) / (tmp_individual.getUpperBound(k) - tmp_individual.getLowerBound(k));
		    tmp_sum_value +=  tmp_value_for_distance * tmp_value_for_distance;
		}
		distance_matrix[i][j] = Math.sqrt(tmp_sum_value);
		distance_matrix[j][i] = distance_matrix[i][j];
	    }
	    distance_matrix[i][i] = 1e+30;
	}

	for (int i = 0; i < this.size(); i++) this.get(i).setDensityValueSolutionSpace(0.0);

	//	System.out.println(nich_radius);
	//	int count = 0;
	for (int i = 0; i < this.size(); i++) {
	    //	    count = 0;
	    for (int j = i + 1; j < this.size(); j++) {
		if (distance_matrix[i][j] < nich_radius) {
		    //		    count++;
		    encouraging = Math.pow(0.5 * (1.0 - (distance_matrix[i][j] / nich_radius)), 2.0);
		    discouraging = Math.pow(1.5 * (1.0 - (distance_matrix[i][j] / nich_radius)), 2.0);

		    if (this.get(i).getSumMinValue() > this.get(j).getSumMinValue()) {
			tmp_val_i = this.get(i).getDensityValueSolutionSpace() + discouraging;
			tmp_val_j = this.get(j).getDensityValueSolutionSpace() + encouraging;
		    }
		    else if (this.get(i).getSumMinValue() < this.get(j).getSumMinValue()) {
			tmp_val_i = this.get(i).getDensityValueSolutionSpace() + encouraging;
			tmp_val_j = this.get(j).getDensityValueSolutionSpace() + discouraging;	
		    }
		    else {
			if (Math.random() < 0.5) {
			    tmp_val_i = this.get(i).getDensityValueSolutionSpace() + discouraging;
			    tmp_val_j = this.get(j).getDensityValueSolutionSpace() + encouraging;
			}
			else {
			    tmp_val_i = this.get(i).getDensityValueSolutionSpace() + encouraging;
			    tmp_val_j = this.get(j).getDensityValueSolutionSpace() + discouraging;
			}
		    }

		    this.get(i).setDensityValueSolutionSpace(tmp_val_i);
		    this.get(j).setDensityValueSolutionSpace(tmp_val_j);			
		}
	    }
	    //	    System.out.println(i + " " + count);
	}    

	for (int i = 0; i < this.size(); i++) {
	    tmp_val_i = Math.sqrt(this.get(i).getDensityValueSolutionSpace());
	    this.get(i).setDensityValueSolutionSpace(tmp_val_i);
	}
    }

    public void setMetaObjectivesF1SumMinF2OBJDensity(){        
	double number_of_meta_objectives =  this.get(0).getNumberOfMetaObjectives();
	double tmp_value;

	for (int i = 0; i < this.size(); i++) {
	    tmp_value= this.get(i).getSumMinValue();
	    this.get(i).setMetaObjective(0, tmp_value);
	    tmp_value= this.get(i).getDensityValue();
	    this.get(i).setMetaObjective(1, tmp_value);
	}
    }

    public void setMetaObjectivesF1SumMinF2SOLDensity(){        
	double number_of_meta_objectives =  this.get(0).getNumberOfMetaObjectives();
	double tmp_value;

	for (int i = 0; i < this.size(); i++) {
	    tmp_value= this.get(i).getSumMinValue();
	    this.get(i).setMetaObjective(0, tmp_value);
	    tmp_value= this.get(i).getDensityValueSolutionSpace();
	    this.get(i).setMetaObjective(1, tmp_value);
	}
    }
    
    public void setMetaObjectivesF1SumMinF2OBJDensityF3SOLDensity(){        
	double number_of_meta_objectives =  this.get(0).getNumberOfMetaObjectives();
	double tmp_value;

	for (int i = 0; i < this.size(); i++) {
	    tmp_value= this.get(i).getSumMinValue();
	    this.get(i).setMetaObjective(0, tmp_value);
	    tmp_value= this.get(i).getDensityValue();
	    this.get(i).setMetaObjective(1, tmp_value);
	    tmp_value= this.get(i).getDensityValueSolutionSpace();
	    this.get(i).setMetaObjective(2, tmp_value);
	}
    }


    public void setSumMinValues(){        
	double number_of_objectives =  this.get(0).getNumberOfObjectives();
	double tmp_sum_value;

	for (int i = 0; i < this.size(); i++) {
	    tmp_sum_value = 0;
	    for (int k = 0; k < number_of_objectives; k++) tmp_sum_value += this.get(i).getNormalizedObjective(k);        
	    this.get(i).setSumMinValue(tmp_sum_value);
	}
    }

    public void setNormalizedObjectiveFunctionValues(){        
	double number_of_objectives =  this.get(0).getNumberOfObjectives();
	double tmp_normalized_value;

	double min_obj_value;
	double max_obj_value;

	for (int k = 0; k < number_of_objectives; k++) {
	    min_obj_value = 1e+30;
	    max_obj_value = -1e+30;

	    for (int i = 0; i < this.size(); i++) {
		if (this.get(i).getObjective(k) < min_obj_value) min_obj_value = this.get(i).getObjective(k);
		if (this.get(i).getObjective(k) > max_obj_value) max_obj_value = this.get(i).getObjective(k);
	    }

	    for (int i = 0; i < this.size(); i++) {
		tmp_normalized_value = (this.get(i).getObjective(k) - min_obj_value) / (max_obj_value - min_obj_value);
		this.get(i).setNormalizedObjective(k, tmp_normalized_value);      	 
	    }		
	}      
    }

    // public void setNormalizedVariableValues(){        
    // 	double number_of_variables =  this.get(0).numberOfVariables();
    // 	double tmp_normalized_value;

    // 	for (int k = 0; k < number_of_variables; k++) {
    // 	    for (int i = 0; i < this.size(); i++) {
    // 		tmp_normalized_value = (this.get(i).getObjective(k) - min_obj_value) / (max_obj_value - min_obj_value);
    // 		this.get(i).setNormalizedObjective(k, tmp_normalized_value);      	 
    // 	    }		
    // 	}      
    // }



  /**
   * Returns an <code>Iterator</code> to access to the solution set list.
   * @return the <code>Iterator</code>.
   */    
  public Iterator<Solution> iterator(){
    return solutionsList_.iterator();
  } // iterator   

  /** 
   * Returns a new <code>SolutionSet</code> which is the result of the union
   * between the current solution set and the one passed as a parameter.
   * @param solutionSet SolutionSet to join with the current solutionSet.
   * @return The result of the union operation.
   */
  public SolutionSet union(SolutionSet solutionSet) {       
    //Check the correct size. In development
    int newSize = this.size() + solutionSet.size();
    if (newSize < capacity_)
      newSize = capacity_;

    //Create a new population 
    SolutionSet union = new SolutionSet(newSize);                
    for (int i = 0; i < this.size(); i++) {      
      union.add(this.get(i));
    } // for

    for (int i = this.size(); i < (this.size() + solutionSet.size()); i++) {
      union.add(solutionSet.get(i-this.size()));
    } // for

    return union;        
  } // union                   

  /** 
   * Replaces a solution by a new one
   * @param position The position of the solution to replace
   * @param solution The new solution
   */
  public void replace(int position, Solution solution) {
    if (position > this.solutionsList_.size()) {
      solutionsList_.add(solution);
    } // if 
    solutionsList_.remove(position);
    solutionsList_.add(position,solution);
  } // replace

  /**
   * Copies the objectives of the solution set to a matrix
   * @return A matrix containing the objectives
   */
  public double [][] writeObjectivesToMatrix() {
    if (this.size() == 0) {
      return null;
    }
    double [][] objectives;
    objectives = new double[size()][get(0).getNumberOfObjectives()];
    for (int i = 0; i < size(); i++) {
      for (int j = 0; j < get(0).getNumberOfObjectives(); j++) {
        objectives[i][j] = get(i).getObjective(j);
      }
    }
    return objectives;
  } // writeObjectivesMatrix

  public void printObjectives() {
    for (int i = 0; i < solutionsList_.size(); i++)
      System.out.println(""+ solutionsList_.get(i)) ;
  }

  public void setCapacity(int capacity) {
    capacity_ = capacity ;
  }

  public int getCapacity() {
    return capacity_ ;
  }
} // SolutionSet

