//  AnalysisHPS2.java
//
//  Author:
//      Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2018 Ryoji Tanabe
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.metaheuristics.analysis;

import jmetal.core.*;
import jmetal.util.JMException;

import jmetal.util.PseudoRandom;
import jmetal.util.wrapper.XReal;

import java.text.DecimalFormat;
import java.util.Vector;

public class AnalysisHPS2 extends Algorithm {
  /**
   * Constructor
   * @param problem Problem to solve
   */
  public AnalysisHPS2(Problem problem) {
      super (problem) ;
  } // AnalysisHPS2

    public AnalysisHPS2(Problem problem, double rt_seed) {
	super(problem);	
	PseudoRandom.initializePseudoRandom(rt_seed);
    } // AnalysisHPS2

    /**   
     * @return a <code>SolutionSet</code> that is a set of non dominated solutions
     * as a result of the algorithm execution
     * @throws JMException 
     */
    public SolutionSet execute() throws JMException, ClassNotFoundException {
	int populationSize;
	int maxEvaluations;
	SolutionSet population;	
	Solution newSolution;
	
	maxEvaluations = ((Integer) getInputParameter("maxEvaluations")).intValue();
	population = new SolutionSet(maxEvaluations);
		
	int tilePosition;
	double randomVar;
	double tmpX1;
	double tmpX2;
	double tmpVar;
	double distortedX1;

	double translatedX1 = 0;
	double translatedX2 = 0;
	
	for (int i = 0; i < maxEvaluations; i++) {
	    newSolution = new Solution(problem_);
	    Variable[] decisionVariables  = newSolution.getDecisionVariables();

	    tilePosition = PseudoRandom.randInt(0,3);

	    double upper_x0 = 0;
	    double lower_x0 = 0;
	    double upper_x1 = 0;
	    double lower_x1 = 0;
	    
	    if (tilePosition == 0) {
		lower_x0 = 0.2;
		upper_x0 = 0.4;
		lower_x1 = 0.2;
		upper_x1 = 0.4;
	    }
	    else if (tilePosition == 1) {
		lower_x0 = 0.6;
		upper_x0 = 0.8;
		lower_x1 = 0.2;
		upper_x1 = 0.4;
	    }
	    else if (tilePosition == 2) {
		lower_x0 = 0.2;
		upper_x0 = 0.4;		
		lower_x1 = 0.6;
		upper_x1 = 0.8;
	    }
	    else if (tilePosition == 3) {
		lower_x0 = 0.6;
		upper_x0 = 0.8;		
		lower_x1 = 0.6;
		upper_x1 = 0.8;
	    }

	    tmpX1 = (upper_x0 - lower_x0) * PseudoRandom.randDouble() + lower_x0;
	    tmpX2 = (upper_x1 - lower_x1) * PseudoRandom.randDouble() + lower_x1;
	    
	    decisionVariables[0].setValue(tmpX1);
	    decisionVariables[1].setValue(tmpX2);	

	    for (int j = 2; j < 7; j++) decisionVariables[j].setValue(0.5);	
	    
	    problem_.evaluate(newSolution);
	    problem_.evaluateConstraints(newSolution);	
	    population.add(newSolution);
	} //for       

	int numRefPoints = 5000;
	SolutionSet reducedPopulation_ = getReducedPopulation(population, numRefPoints);

	reducedPopulation_.printObjectivesToFile("FUN_" + problem_.getName());
	reducedPopulation_.printVariablesToFile("VAR_" + problem_.getName());
		
	return population;
    } // execute


    SolutionSet getReducedPopulation(SolutionSet population_, int numRefPoints) throws JMException, ClassNotFoundException {
	SolutionSet reducedPopulation_ = new SolutionSet(numRefPoints);
	boolean[] isSelected = new boolean[population_.size()];
	double[][] popDistMatrix = new double[population_.size()][population_.size()];
	double[] minDistVars = new double[population_.size()];

	double tmpSumVar, tmpVar;
	int maxDistIndivIndex;
	double maxDistVar;

	double[] variablesUpperBounds;
	double[] variablesLowerBounds;

	XReal tmpInd = new XReal(population_.get(0));
	variablesUpperBounds = new double[problem_.getNumberOfVariables()];
	variablesLowerBounds = new double[problem_.getNumberOfVariables()];
    
	for (int k = 0; k < problem_.getNumberOfVariables(); k++) {
	    variablesUpperBounds[k] = tmpInd.getUpperBound(k);
	    variablesLowerBounds[k] = tmpInd.getLowerBound(k);
	}

	if (population_.size() < numRefPoints) {
	    for (int j = 0; j < population_.size(); j++) reducedPopulation_.add(population_.get(j));	    
	}
	else {
	    for (int j = 0; j < population_.size(); j++) {		   
		isSelected[j] = false;
		minDistVars[j] = 1e+30;
	    }

	    for (int j = 0; j < population_.size(); j++) {		   
		Variable[] variableX1 = population_.get(j).getDecisionVariables();

		for (int k = j; k < population_.size(); k++) {		   
		    if (j == k) {
			popDistMatrix[j][k] = 0;
		    }
		    else {
			Variable[] variableX2 = population_.get(k).getDecisionVariables();
			tmpSumVar = 0;
	    
			for (int l = 0; l < problem_.getNumberOfVariables(); l++) {
			    tmpVar = (variableX1[l].getValue() - variableX2[l].getValue()) / (variablesUpperBounds[l] - variablesLowerBounds[l]);			    
			    tmpSumVar += tmpVar * tmpVar;
			}
			popDistMatrix[j][k] = Math.sqrt(tmpSumVar);
		    }
		    popDistMatrix[k][j] = popDistMatrix[j][k];
		}		
	    }

	    int rndIndex = PseudoRandom.randInt(0, population_.size() - 1);
	    isSelected[rndIndex] = true;

	    for (int j = 0; j < population_.size(); j++) {		   
		if (minDistVars[j] > popDistMatrix[j][rndIndex] && isSelected[j] == false) minDistVars[j] = popDistMatrix[j][rndIndex];
	    }
    
	    for (int j = 0; j < numRefPoints - 1; j++) {		   
		maxDistIndivIndex = -1;
		maxDistVar = 0;

		for (int k = 0; k < population_.size(); k++) {		   
		    if (isSelected[k] == false && minDistVars[k] >= maxDistVar) {
			maxDistVar = minDistVars[k];
			maxDistIndivIndex = k;
		    }  	    
		}

		isSelected[maxDistIndivIndex] = true;
		
		for (int k = 0; k < population_.size(); k++) {		   
		    if (minDistVars[k] > popDistMatrix[k][maxDistIndivIndex] && isSelected[k] == false) minDistVars[k] = popDistMatrix[k][maxDistIndivIndex];
		}		
	    }

	    for (int j = 0; j < population_.size(); j++) {		   
		if (isSelected[j] == true) reducedPopulation_.add(population_.get(j));
	    }
	}

	return reducedPopulation_;       	
    }
        
} 
