//  AnalysisMMMOP6.java
//
//  Author:
//      Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2018 Ryoji Tanabe
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.metaheuristics.analysis;

import jmetal.core.*;
import jmetal.util.JMException;

import jmetal.util.PseudoRandom;
import jmetal.util.wrapper.XReal;

import java.text.DecimalFormat;
import java.util.Vector;

public class AnalysisMMMOP6 extends Algorithm {
  /**
   * Constructor
   * @param problem Problem to solve
   */
  public AnalysisMMMOP6(Problem problem) {
      super (problem) ;
  } // AnalysisMMMOP6

    public AnalysisMMMOP6(Problem problem, double rt_seed) {
	super(problem);	
	PseudoRandom.initializePseudoRandom(rt_seed);
    } // AnalysisMMMOP6

    /**   
     * @return a <code>SolutionSet</code> that is a set of non dominated solutions
     * as a result of the algorithm execution
     * @throws JMException 
     */
    public SolutionSet execute() throws JMException, ClassNotFoundException {
	int populationSize;
	int maxEvaluations;
	SolutionSet population;	
	Solution newSolution;
	
	maxEvaluations = ((Integer) getInputParameter("maxEvaluations")).intValue();
	population = new SolutionSet(maxEvaluations);
	String testFunc = getInputParameter("testFunc").toString();
	
	int tilePosition;
	double tmpVar;

	int kA = 1;
	int kB = 1;
	int ci = 0;
	
	if ("MMMOP6A".equals(testFunc)) {
	    kA = 0;
	    kB = 1;
	    ci = 2;
	}
	else if ("MMMOP6B".equals(testFunc)) {
	    kA = 0;
	    kB = 2;
	    ci = 2;
	}
	else if ("MMMOP6C".equals(testFunc)) {
	    kA = 2;
	    kB = 1;
	    ci = 2;
	}
	else if ("MMMOP6D".equals(testFunc)) {
	    kA = 2;
	    kB = 1;
	    ci = 2;
	}
	
	double[] discreteOptVars1 = {3, -2.80511, -3.77931, 3.58442};
	double[] discreteOptVars2 = {2, 3.13131, -3.28318, -1.84812};
	
	for (int i = 0; i < maxEvaluations; i++) {
	    newSolution = new Solution(problem_);
	    Variable[] decisionVariables  = newSolution.getDecisionVariables();

	    for (int j = 0; j < problem_.getNumberOfObjectives() - 1; j++) {
		tmpVar = PseudoRandom.randDouble();
		decisionVariables[j].setValue(tmpVar);			
	    }

	    for (int j = problem_.getNumberOfObjectives() - 1; j < problem_.getNumberOfObjectives() - 1 + kA; j+=2) {
		tilePosition = PseudoRandom.randInt(0,4-1);		

		tmpVar = (discreteOptVars1[tilePosition] / 12.0) + 0.5;
		decisionVariables[j].setValue(tmpVar);
		
		tmpVar = (discreteOptVars2[tilePosition] / 12.0) + 0.5;
		decisionVariables[j+1].setValue(tmpVar);			
	    }

	    double ti;
	    double zi;
	    
	    for (int j = problem_.getNumberOfObjectives() - 1 + kA; j < problem_.getNumberOfVariables(); j++) {
		ti = 1;
	    
		for (int k = 0; k < problem_.getNumberOfObjectives() - 1; k++) {
		    tmpVar = ((j - (problem_.getNumberOfObjectives() - 1 + kA)) * Math.PI) / kB;
		    ti *= Math.sin(2 * Math.PI * decisionVariables[k].getValue() + tmpVar); 
		}
		
		if (PseudoRandom.randDouble() < 0.5) {
		    tmpVar = (ti + 1) / 4.0;
		}
		else {
		    tmpVar = (ti + 3) / 4.0;
		}
		
		decisionVariables[j].setValue(tmpVar);		
	    }
	    
	    problem_.evaluate(newSolution);
	    problem_.evaluateConstraints(newSolution);	
	    population.add(newSolution);
	} //for       

	int numRefPoints = 5000;
	if (numRefPoints > maxEvaluations) numRefPoints = maxEvaluations;
	SolutionSet reducedPopulation_ = getReducedPopulation(population, numRefPoints);

	reducedPopulation_.printObjectivesToFile("FUN_" + testFunc);
	reducedPopulation_.printVariablesToFile("VAR_" + testFunc);
	
	return population;
    } // execute


    SolutionSet getReducedPopulation(SolutionSet population_, int numRefPoints) throws JMException, ClassNotFoundException {
	SolutionSet reducedPopulation_ = new SolutionSet(numRefPoints);
	boolean[] isSelected = new boolean[population_.size()];
	double[][] popDistMatrix = new double[population_.size()][population_.size()];
	double[] minDistVars = new double[population_.size()];

	double tmpSumVar, tmpVar;
	int maxDistIndivIndex;
	double maxDistVar;

	double[] variablesUpperBounds;
	double[] variablesLowerBounds;

	XReal tmpInd = new XReal(population_.get(0));
	variablesUpperBounds = new double[problem_.getNumberOfVariables()];
	variablesLowerBounds = new double[problem_.getNumberOfVariables()];
    
	for (int k = 0; k < problem_.getNumberOfVariables(); k++) {
	    variablesUpperBounds[k] = tmpInd.getUpperBound(k);
	    variablesLowerBounds[k] = tmpInd.getLowerBound(k);
	}

	if (population_.size() < numRefPoints) {
	    for (int j = 0; j < population_.size(); j++) reducedPopulation_.add(population_.get(j));	    
	}
	else {
	    for (int j = 0; j < population_.size(); j++) {		   
		isSelected[j] = false;
		minDistVars[j] = 1e+30;
	    }

	    for (int j = 0; j < population_.size(); j++) {		   
		Variable[] variableX1 = population_.get(j).getDecisionVariables();

		for (int k = j; k < population_.size(); k++) {		   
		    if (j == k) {
			popDistMatrix[j][k] = 0;
		    }
		    else {
			Variable[] variableX2 = population_.get(k).getDecisionVariables();
			tmpSumVar = 0;
	    
			for (int l = 0; l < problem_.getNumberOfVariables(); l++) {
			    tmpVar = (variableX1[l].getValue() - variableX2[l].getValue()) / (variablesUpperBounds[l] - variablesLowerBounds[l]);			    
			    tmpSumVar += tmpVar * tmpVar;
			}
			popDistMatrix[j][k] = Math.sqrt(tmpSumVar);
		    }
		    popDistMatrix[k][j] = popDistMatrix[j][k];
		}		
	    }

	    int rndIndex = PseudoRandom.randInt(0, population_.size() - 1);
	    isSelected[rndIndex] = true;

	    for (int j = 0; j < population_.size(); j++) {		   
		if (minDistVars[j] > popDistMatrix[j][rndIndex] && isSelected[j] == false) minDistVars[j] = popDistMatrix[j][rndIndex];
	    }
    
	    for (int j = 0; j < numRefPoints - 1; j++) {		   
		maxDistIndivIndex = -1;
		maxDistVar = 0;

		for (int k = 0; k < population_.size(); k++) {		   
		    if (isSelected[k] == false && minDistVars[k] >= maxDistVar) {
			maxDistVar = minDistVars[k];
			maxDistIndivIndex = k;
		    }  	    
		}

		isSelected[maxDistIndivIndex] = true;
		
		for (int k = 0; k < population_.size(); k++) {		   
		    if (minDistVars[k] > popDistMatrix[k][maxDistIndivIndex] && isSelected[k] == false) minDistVars[k] = popDistMatrix[k][maxDistIndivIndex];
		}		
	    }

	    for (int j = 0; j < population_.size(); j++) {		   
		if (isSelected[j] == true) reducedPopulation_.add(population_.get(j));
	    }
	}

	return reducedPopulation_;       	
    }
        
} 
