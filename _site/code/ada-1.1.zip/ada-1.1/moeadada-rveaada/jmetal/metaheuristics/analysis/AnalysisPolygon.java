//  AnalysisPolygon.java
//
//  Author:
//      Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2018 Ryoji Tanabe
//
// NOTE: The procedure of the Crossing Number Algorithm, which is used for determining whether a given two-dimentional vector is inside a polygon, was copied from https://www.nttpc.co.jp/technology/number_algorithm.html
// 
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.metaheuristics.analysis;

import jmetal.core.*;
import jmetal.util.JMException;

import jmetal.util.PseudoRandom;
import jmetal.util.wrapper.XReal;

import java.text.DecimalFormat;
import java.util.Vector;

public class AnalysisPolygon extends Algorithm {
    /**
     * Constructor
     * @param problem Problem to solve
     */
    public AnalysisPolygon(Problem problem) {
	super (problem) ;
    } // AnalysisPolygon

    public AnalysisPolygon(Problem problem, double rt_seed) {
	super(problem);	
	PseudoRandom.initializePseudoRandom(rt_seed);
    } // AnalysisPolygon

    /**   
     * @return a <code>SolutionSet</code> that is a set of non dominated solutions
     * as a result of the algorithm execution
     * @throws JMException 
     */
    public SolutionSet execute() throws JMException, ClassNotFoundException {
	int populationSize;
	int maxEvaluations;
	SolutionSet population;	
	Solution newSolution;
	
	maxEvaluations = ((Integer) getInputParameter("maxEvaluations")).intValue();
	population = new SolutionSet(maxEvaluations);

	int numberOfObjectives_ = problem_.getNumberOfObjectives();
	int numPolygons = ((Integer) getInputParameter("numPolygons")).intValue();

	double polygonCenterPosX1[] = new double[numPolygons];
	double polygonCenterPosX2[] = new double[numPolygons];

	boolean isInside = false;
	double tmpX1 = 0;
	double tmpX2 = 0;
	double translatedX1;
	double translatedX2;
	double rotationRadian = Math.toRadians(-45);
	int polygonPosition;

	if (numPolygons == 2) {
	    for (int i = 0; i < numPolygons; i++) {	    	   
		if (i == 0) {
		    polygonCenterPosX1[i] = 2.5;
		    polygonCenterPosX2[i] = 5.0;
		}
		if (i == 1) {
		    polygonCenterPosX1[i] = 7.5;
		    polygonCenterPosX2[i] = 5.0;
		}
	    }
	}
	else if (numPolygons == 4) {
	    for (int i = 0; i < numPolygons; i++) {	    	   
		if (i == 0) {
		    polygonCenterPosX1[i] = 2.5;
		    polygonCenterPosX2[i] = 2.5;
		}
		if (i == 1) {
		    polygonCenterPosX1[i] = 7.5;
		    polygonCenterPosX2[i] = 2.5;
		}
		if (i == 2) {
		    polygonCenterPosX1[i] = 2.5;
		    polygonCenterPosX2[i] = 7.5;
		}
		if (i == 3) {
		    polygonCenterPosX1[i] = 7.5;
		    polygonCenterPosX2[i] = 7.5;
		}
	    }
	}
	else if (numPolygons == 9) {
	    for (int i = 0; i < numPolygons; i++) {	    	   
		if (i == 0) {
		    polygonCenterPosX1[i] = 1.5;
		    polygonCenterPosX2[i] = 1.5;
		}
		if (i == 1) {
		    polygonCenterPosX1[i] = 5.0;
		    polygonCenterPosX2[i] = 1.5;
		}
		if (i == 2) {
		    polygonCenterPosX1[i] = 8.5;
		    polygonCenterPosX2[i] = 1.5;
		}
		if (i == 3) {
		    polygonCenterPosX1[i] = 1.5;
		    polygonCenterPosX2[i] = 5.0;
		}
		if (i == 4) {
		    polygonCenterPosX1[i] = 5.0;
		    polygonCenterPosX2[i] = 5.0;
		}
		if (i == 5) {
		    polygonCenterPosX1[i] = 8.5;
		    polygonCenterPosX2[i] = 5.0;
		}
		if (i == 6) {
		    polygonCenterPosX1[i] = 1.5;
		    polygonCenterPosX2[i] = 8.5;
		}
		if (i == 7) {
		    polygonCenterPosX1[i] = 5.0;
		    polygonCenterPosX2[i] = 8.5;
		}
		if (i == 8) {
		    polygonCenterPosX1[i] = 8.5;
		    polygonCenterPosX2[i] = 8.5;
		}
	    }
	}

	double basicPolygonCoordintatesX1[] = new double[numberOfObjectives_ + 1];
	double basicPolygonCoordintatesX2[] = new double[numberOfObjectives_ + 1];

	if (numberOfObjectives_ % 2 == 0) {
	    for (int i = 0; i < numberOfObjectives_; i++) {
		basicPolygonCoordintatesX1[i] = 0.5 * Math.sin(2.0*Math.PI*i/numberOfObjectives_ - Math.PI/numberOfObjectives_);
		basicPolygonCoordintatesX2[i] = 0.5 * Math.cos(2.0*Math.PI*i/numberOfObjectives_ - Math.PI/numberOfObjectives_);
	    }
	}
	else {
	    for (int i = 0; i < numberOfObjectives_; i++) {
		basicPolygonCoordintatesX1[i] = 0.5 * Math.sin(2.0*Math.PI*i/numberOfObjectives_);
		basicPolygonCoordintatesX2[i] = 0.5 * Math.cos(2.0*Math.PI*i/numberOfObjectives_);
	    }
	}

	basicPolygonCoordintatesX1[numberOfObjectives_] = basicPolygonCoordintatesX1[0];
	basicPolygonCoordintatesX2[numberOfObjectives_] = basicPolygonCoordintatesX2[0];

	double upperPolygonBoundX1 = -1e+30;
	double lowerPolygonBoundX1 = 1e+30;
	double upperPolygonBoundX2 = -1e+30;
	double lowerPolygonBoundX2 = 1e+30;
		    
	for (int i = 0; i < numberOfObjectives_; i++) {
	    if (upperPolygonBoundX1 < basicPolygonCoordintatesX1[i]) {
		upperPolygonBoundX1 = basicPolygonCoordintatesX1[i];
	    }
	    else if (lowerPolygonBoundX1 > basicPolygonCoordintatesX1[i]) {
		lowerPolygonBoundX1 = basicPolygonCoordintatesX1[i];
	    }
	    if (upperPolygonBoundX2 < basicPolygonCoordintatesX2[i]) {
		upperPolygonBoundX2 = basicPolygonCoordintatesX2[i];
	    }
	    else if (lowerPolygonBoundX2 > basicPolygonCoordintatesX2[i]) {
		lowerPolygonBoundX2 = basicPolygonCoordintatesX2[i];
	    }
	}

	double crossingCount;
	double vt;
	
	for (int i = 0; i < maxEvaluations; i++) {
	    newSolution = new Solution(problem_);
	    Variable[] decisionVariables  = newSolution.getDecisionVariables();

	    isInside = false;

	    while (isInside == false) {
		tmpX1 = (upperPolygonBoundX1 - lowerPolygonBoundX1) * PseudoRandom.randDouble() + lowerPolygonBoundX1;
		tmpX2 = (upperPolygonBoundX2 - lowerPolygonBoundX2) * PseudoRandom.randDouble() + lowerPolygonBoundX2;

		crossingCount = 0;
		
		// The procedure of the Crossing Number Algorithm was copied from https://www.nttpc.co.jp/technology/number_algorithm.html
		for(int j = 0; j < numberOfObjectives_; j++){
		    if ((basicPolygonCoordintatesX2[j] <= tmpX2 && basicPolygonCoordintatesX2[j + 1] > tmpX2) || (basicPolygonCoordintatesX2[j] > tmpX2 && basicPolygonCoordintatesX2[j + 1] <= tmpX2)) {
			vt = (tmpX2 - basicPolygonCoordintatesX2[j]) / (basicPolygonCoordintatesX2[j + 1] - basicPolygonCoordintatesX2[j]);
			if(tmpX1 < (basicPolygonCoordintatesX1[j] + (vt * (basicPolygonCoordintatesX1[j + 1] - basicPolygonCoordintatesX1[j])))) {
			    crossingCount++;
			}
		    }
		}

		if (crossingCount == 1) isInside = true;
	    }

	    polygonPosition = PseudoRandom.randInt(0, numPolygons - 1);
	    tmpX1 += polygonCenterPosX1[polygonPosition];
	    tmpX2 += polygonCenterPosX2[polygonPosition];	

	    if  ("PolygonProblem".equals(problem_.getName())) {
		decisionVariables[0].setValue(tmpX1);			
		decisionVariables[1].setValue(tmpX2);
	    }	    
	    else if  ("RotatedPolygonProblem".equals(problem_.getName())) { 
		translatedX1 = tmpX1 * Math.cos(rotationRadian) - tmpX2 * Math.sin(rotationRadian);
		translatedX2 = tmpX1 * Math.sin(rotationRadian) + tmpX2 * Math.cos(rotationRadian);
		decisionVariables[0].setValue(translatedX1);			
		decisionVariables[1].setValue(translatedX2);			
	    }
	    
       	    problem_.evaluate(newSolution);
	    problem_.evaluateConstraints(newSolution);
	    population.add(newSolution);
	} //for       

	int numRefPoints = 5000;
	SolutionSet reducedPopulation_ = getReducedPopulation(population, numRefPoints);
	
	// population.printObjectivesToFile("FUN_" + problem_.getName() + "_M" + numberOfObjectives_ + "_P" + numPolygons);
	// population.printVariablesToFile("VAR_" + problem_.getName() + "_M" + numberOfObjectives_ + "_P" + numPolygons);	

	reducedPopulation_.printObjectivesToFile("FUN_" + problem_.getName() + "_M" + numberOfObjectives_ + "_P" + numPolygons);
	reducedPopulation_.printVariablesToFile("VAR_" + problem_.getName() + "_M" + numberOfObjectives_ + "_P" + numPolygons);	
	
	return population;
    } // execute


    SolutionSet getReducedPopulation(SolutionSet population_, int numRefPoints) throws JMException, ClassNotFoundException {
	SolutionSet reducedPopulation_ = new SolutionSet(numRefPoints);
	boolean[] isSelected = new boolean[population_.size()];
	double[][] popDistMatrix = new double[population_.size()][population_.size()];
	double[] minDistVars = new double[population_.size()];

	double tmpSumVar, tmpVar;
	int maxDistIndivIndex;
	double maxDistVar;

	double[] variablesUpperBounds;
	double[] variablesLowerBounds;

	XReal tmpInd = new XReal(population_.get(0));
	variablesUpperBounds = new double[problem_.getNumberOfVariables()];
	variablesLowerBounds = new double[problem_.getNumberOfVariables()];
    
	for (int k = 0; k < problem_.getNumberOfVariables(); k++) {
	    variablesUpperBounds[k] = tmpInd.getUpperBound(k);
	    variablesLowerBounds[k] = tmpInd.getLowerBound(k);
	}

	
	//	System.out.println(population_.size() + " " + numRefPoints);

	if (population_.size() < numRefPoints) {
	    for (int j = 0; j < population_.size(); j++) reducedPopulation_.add(population_.get(j));	    
	}
	else {
	    for (int j = 0; j < population_.size(); j++) {		   
		isSelected[j] = false;
		minDistVars[j] = 1e+30;
	    }

	    for (int j = 0; j < population_.size(); j++) {		   
		Variable[] variableX1 = population_.get(j).getDecisionVariables();

		for (int k = j; k < population_.size(); k++) {		   
		    if (j == k) {
			popDistMatrix[j][k] = 0;
		    }
		    else {
			Variable[] variableX2 = population_.get(k).getDecisionVariables();
			tmpSumVar = 0;
	    
			for (int l = 0; l < problem_.getNumberOfVariables(); l++) {
			    tmpVar = (variableX1[l].getValue() - variableX2[l].getValue()) / (variablesUpperBounds[l] - variablesLowerBounds[l]);			    
			    tmpSumVar += tmpVar * tmpVar;
			}
			popDistMatrix[j][k] = Math.sqrt(tmpSumVar);
		    }
		    popDistMatrix[k][j] = popDistMatrix[j][k];
		}		
	    }

	    int rndIndex = PseudoRandom.randInt(0, population_.size() - 1);
	    isSelected[rndIndex] = true;

	    for (int j = 0; j < population_.size(); j++) {		   
		if (minDistVars[j] > popDistMatrix[j][rndIndex] && isSelected[j] == false) minDistVars[j] = popDistMatrix[j][rndIndex];
	    }
    
	    for (int j = 0; j < numRefPoints - 1; j++) {		   
		maxDistIndivIndex = -1;
		maxDistVar = 0;

		for (int k = 0; k < population_.size(); k++) {		   
		    if (isSelected[k] == false && minDistVars[k] >= maxDistVar) {
			maxDistVar = minDistVars[k];
			maxDistIndivIndex = k;
		    }  	    
		}

		// int tmpCount = 0;
		// for (int k = 0; k < population_.size(); k++) {		   
		//     if (isSelected[k] == false) {
		// 	tmpCount++;
		//     }  	    
		//     if (minDistVars[k] < maxDistVar) {
		// 	System.out.println(k + " " + minDistVars[k]);
		//     }
		// }

		// System.out.println(population_.size() + " " + isSelected.length + " " + j + " " + tmpCount + " " + maxDistIndivIndex);

		isSelected[maxDistIndivIndex] = true;
		
		for (int k = 0; k < population_.size(); k++) {		   
		    if (minDistVars[k] > popDistMatrix[k][maxDistIndivIndex] && isSelected[k] == false) minDistVars[k] = popDistMatrix[k][maxDistIndivIndex];
		}		
	    }

	    for (int j = 0; j < population_.size(); j++) {		   
		if (isSelected[j] == true) reducedPopulation_.add(population_.get(j));
	    }
	}

	return reducedPopulation_;       	
    }    
} 
