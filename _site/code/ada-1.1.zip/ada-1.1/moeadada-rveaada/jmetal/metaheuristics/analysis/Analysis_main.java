//  Analysis_main.java
//
//  Author:
//      Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2018 Ryoji Tanabe
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.metaheuristics.analysis;

import jmetal.core.Algorithm;
import jmetal.core.Problem;
import jmetal.core.SolutionSet;
import jmetal.problems.ProblemFactory;

import jmetal.problems.PolygonProblem;
import jmetal.problems.RotatedPolygonProblem;
import jmetal.problems.DT1;
import jmetal.problems.DT2;
import jmetal.problems.TWOONONE;
import jmetal.problems.SYMPART1;
import jmetal.problems.SYMPART2;
import jmetal.problems.SYMPART3;
import jmetal.problems.SSUF1;
import jmetal.problems.SSUF3;
import jmetal.problems.HPS2;
import jmetal.problems.MMMOP.*;

import jmetal.util.Configuration;
import jmetal.util.JMException;

import java.io.IOException;
import java.util.HashMap;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

public class Analysis_main {
  public static Logger      logger_ ;      // Logger object
  public static FileHandler fileHandler_ ; // FileHandler object

  /**
   * @param args Command line arguments.
   * @throws JMException 
   * @throws IOException 
   * @throws SecurityException 
   */
  public static void main(String [] args) throws 
                                  JMException, 
                                  SecurityException, 
                                  IOException, 
                                  ClassNotFoundException {
    Problem   problem   ; // The problem to solve
    Algorithm algorithm ; // The algorithm to use
    
    // Logger object and file to store log messages
    logger_      = Configuration.logger_ ;
    fileHandler_ = new FileHandler("Analysis_main.log"); 
    logger_.addHandler(fileHandler_) ;

    // testFunc \in \{PolygonProblem, RotatedPolygonProblem, DT1 (Omni-test), DT2, TWO-ON-ONE, SYMPART1, SYMPART2, SYMPART3, SSUF1, SSUF3, HPS2, MMMOP*\}
    String testFunc = "SYMPART1";
    // When PolygonProblem is not selected, numObjectives and numPolygons are not used
    int numPolygons = 9;
    int numObjectives = 3;
    // When DT1 is not selected, numVarsOmni is not used
    int numVarsOmni = 5;

    // maxFEvals represents the number of Pareto optimal solutions 
    int maxFEvals = 5000;
    double rndSeed = 0;	      

    if ("PolygonProblem".equals(testFunc)) problem = new PolygonProblem("Real", numObjectives, numPolygons);
    else if ("RotatedPolygonProblem".equals(testFunc)) problem = new RotatedPolygonProblem("Real", numObjectives, numPolygons);
    else if ("DT1".equals(testFunc)) problem = new DT1("Real", numVarsOmni);
    else if ("DT2".equals(testFunc)) problem = new DT2("Real");
    else if ("TWO-ON-ONE".equals(testFunc)) problem = new TWOONONE("Real");
    else if ("SYMPART1".equals(testFunc)) problem = new SYMPART1("Real");
    else if ("SYMPART2".equals(testFunc)) problem = new SYMPART2("Real");
    else if ("SYMPART3".equals(testFunc)) problem = new SYMPART3("Real");
    else if ("SSUF1".equals(testFunc)) problem = new SSUF1("Real");
    else if ("SSUF3".equals(testFunc)) problem = new SSUF3("Real");
    else if ("MMMOP1A".equals(testFunc)) problem = new MMMOP1("Real", 2, 1, 1);
    else if ("MMMOP1B".equals(testFunc)) problem = new MMMOP1("Real", 3, 1, 4);
    else if ("MMMOP2A".equals(testFunc)) problem = new MMMOP2("Real", 2, 1, 1);
    else if ("MMMOP2B".equals(testFunc)) problem = new MMMOP2("Real", 3, 1, 4);
    else if ("MMMOP3A".equals(testFunc)) problem = new MMMOP3("Real", 2, 0, 1, 0, 3);
    // In MMMOP3B, d was actually set to 1 in the Matlab code, not d=2 as presented in the original Tri... paper
    else if ("MMMOP3B".equals(testFunc)) problem = new MMMOP3("Real", 3, 0, 5, 0, 1); 
    //        else if ("MMMOP3B".equals(testFunc)) problem = new MMMOP3("Real", 3, 0, 5, 0, 2);
    else if ("MMMOP3C".equals(testFunc)) problem = new MMMOP3("Real", 2, 1, 4, 3, 3);
    else if ("MMMOP3D".equals(testFunc)) problem = new MMMOP3("Real", 3, 1, 4, 2, 2);
    else if ("MMMOP4A".equals(testFunc)) problem = new MMMOP4("Real", 2, 0, 1, 0, 4);
    else if ("MMMOP4B".equals(testFunc)) problem = new MMMOP4("Real", 3, 0, 5, 0, 3);
    else if ("MMMOP4C".equals(testFunc)) problem = new MMMOP4("Real", 2, 1, 4, 2, 4);
    else if ("MMMOP4D".equals(testFunc)) problem = new MMMOP4("Real", 3, 1, 4, 2, 3);
    else if ("MMMOP5A".equals(testFunc)) problem = new MMMOP5("Real", 2, 0, 1, 0, 3);
    else if ("MMMOP5B".equals(testFunc)) problem = new MMMOP5("Real", 3, 0, 5, 0, 1);
    else if ("MMMOP5C".equals(testFunc)) problem = new MMMOP5("Real", 2, 1, 4, 2, 2);
    else if ("MMMOP5D".equals(testFunc)) problem = new MMMOP5("Real", 3, 1, 4, 2, 1);
    else if ("MMMOP6A".equals(testFunc)) problem = new MMMOP6("Real", 2, 0, 1, 2);
    else if ("MMMOP6B".equals(testFunc)) problem = new MMMOP6("Real", 3, 0, 2, 2);
    else if ("MMMOP6C".equals(testFunc)) problem = new MMMOP6("Real", 2, 2, 1, 2);
    else if ("MMMOP6D".equals(testFunc)) problem = new MMMOP6("Real", 3, 2, 1, 2);
    else if ("HPS2".equals(testFunc)) problem = new HPS2("Real", 5);
    else {
	System.out.println("Error ! " + testFunc + " has not been defined.");
	problem = new TWOONONE("Real");
	System.exit(1);
    }

    if ("SYMPART1".equals(testFunc) || "SYMPART2".equals(testFunc) || "SYMPART3".equals(testFunc)) {
	algorithm = new AnalysisSYMPART(problem, rndSeed);    
    }
    else if ("TWO-ON-ONE".equals(testFunc)) {
	algorithm = new AnalysisTWOONONE(problem, rndSeed);    
    }
    else if ("DT1".equals(testFunc) || "DT2".equals(testFunc)) {
	algorithm = new AnalysisDT(problem, rndSeed);    
    }
    else if ("SSUF1".equals(testFunc) || "SSUF3".equals(testFunc)) {
	algorithm = new AnalysisSSUF(problem, rndSeed);    
    }
    else if ("PolygonProblem".equals(testFunc) || "RotatedPolygonProblem".equals(testFunc)) {
	algorithm = new AnalysisPolygon(problem, rndSeed);    
    }
    else if ("HPS2".equals(testFunc)) {
	algorithm = new AnalysisHPS2(problem, rndSeed);    
    }
    else if (testFunc.contains("MMMOP1")) {
    	algorithm = new AnalysisMMMOP1(problem, rndSeed);    
    }
    else if (testFunc.contains("MMMOP2")) {
    	algorithm = new AnalysisMMMOP2(problem, rndSeed);    
    }
    else if (testFunc.contains("MMMOP3")) {
    	algorithm = new AnalysisMMMOP3(problem, rndSeed);    
    }
    else if (testFunc.contains("MMMOP4")) {
    	algorithm = new AnalysisMMMOP4(problem, rndSeed);    
    }
    else if (testFunc.contains("MMMOP5")) {
    	algorithm = new AnalysisMMMOP5(problem, rndSeed);    
    }
    else if (testFunc.contains("MMMOP6")) {
    	algorithm = new AnalysisMMMOP6(problem, rndSeed);    
    }    
    else {
	System.out.println("Error ! " + testFunc + " has not been defined.");
	algorithm = new AnalysisSYMPART(problem, rndSeed);
	System.exit(1);
    }
    
    // Algorithm parameters
    algorithm.setInputParameter("maxEvaluations",maxFEvals);
    algorithm.setInputParameter("numPolygons",numPolygons);

    algorithm.setInputParameter("numVarsOmni",numVarsOmni);
    algorithm.setInputParameter("testFunc",testFunc);
    
    //    algorithm.execute();
    SolutionSet population = algorithm.execute();
  } //main
} // Analysis_main
