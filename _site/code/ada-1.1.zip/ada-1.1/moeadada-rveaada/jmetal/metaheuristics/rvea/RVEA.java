//  RVEA.java
//
//  Author:
//      Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2018 Ryoji Tanabe
//
// NOTE:
// This is a translated version of the MOEA Framework implementation of RVEA (http://moeaframework.org/) by Dr. David Hadka
// I also referred to the original implementation of RVEA (https://www.cs.bham.ac.uk/~chengr/) by Dr. Ran Cheng
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.metaheuristics.rvea;

import jmetal.core.*;
import jmetal.util.*;
import jmetal.util.JMException;
import jmetal.util.PseudoRandom;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.ArrayList;
import java.text.DecimalFormat;

public class RVEA extends Algorithm {
    int populationSize_;
    SolutionSet population_;
    SolutionSet offspringPopulation;
    SolutionSet union;
    
    /**
     * Z vector (ideal point)
     */
    double[] idealPoint;

    /**
     * Z vector (nadir point)
     */
    double[] nadirPoint;

    /**
     * Lambda vectors
     */
    double[][] originalWeightVectors;
    double[][] originalUnitReferenceVectors;
    double[][] currentUnitReferenceVectors;    

    int evaluations_;

    /**
     * Operators
     */
    Operator crossover_;
    Operator mutation_;   
    String dataDirectory_;
    int numReferenceVectors;
    double[] minAngles;

    /** 
     * Constructor
     * @param problem Problem to solve
     */
    public RVEA(Problem problem, double seed) {
	super (problem) ;
	PseudoRandom.initializePseudoRandom(seed);
    } // RVEA

    public SolutionSet execute() throws JMException, ClassNotFoundException {
	int maxEvaluations;
	evaluations_ = 0;
	maxEvaluations = ((Integer) this.getInputParameter("maxEvaluations")).intValue();
	dataDirectory_ = this.getInputParameter("dataDirectory").toString();

	populationSize_ = ((Integer) this.getInputParameter("populationSize")).intValue();
	numReferenceVectors = populationSize_;
	population_ = new SolutionSet(populationSize_);
	        
	idealPoint = new double[problem_.getNumberOfObjectives()];
	nadirPoint = new double[problem_.getNumberOfObjectives()];

	crossover_ = operators_.get("crossover"); 
	mutation_ = operators_.get("mutation"); 

	originalWeightVectors = new double[populationSize_][problem_.getNumberOfObjectives()];
	originalUnitReferenceVectors = new double[populationSize_][problem_.getNumberOfObjectives()];
	currentUnitReferenceVectors = new double[populationSize_][problem_.getNumberOfObjectives()];
	
	initUniformWeight();

	for (int i = 0; i < numReferenceVectors; i++) {
	    double norm_value = norm_vector(originalWeightVectors[i]);
	    for (int j = 0; j < problem_.getNumberOfObjectives(); j++) originalUnitReferenceVectors[i][j] = originalWeightVectors[i][j] / norm_value;	    
	}

	for (int i = 0; i < numReferenceVectors; i++) {
	    for (int j = 0; j < problem_.getNumberOfObjectives(); j++) currentUnitReferenceVectors[i][j] = originalUnitReferenceVectors[i][j];
	}
	
	// compute the minimum angles between reference vectors
	minAngles = new double[numReferenceVectors];
		
	for (int i = 0; i < numReferenceVectors; i++) {
	    minAngles[i] = smallestAngleBetweenWeights(i);
	}
		    
	initPopulation();
	initIdealPoint();   
	
	int currentNumIters = 0;
	int maxNumIters = maxEvaluations / populationSize_;

	while (maxNumIters * populationSize_ < maxEvaluations) {
	    maxNumIters += 1;
	}

	double alpha = 2.0;
	int adaptFrequency = maxNumIters / 10;
	double[] tmpObjVec = new double[problem_.getNumberOfObjectives()];
	
	while (evaluations_ < maxEvaluations) {		    
	    double scalingFactor = Math.min(currentNumIters / (double)maxNumIters, 1.0);
	    //	    System.out.println(scalingFactor + " " + adaptFrequency);
	    
	    int[] shuffledIndices = new int[population_.size()];
	    for (int i = 0; i < population_.size(); i++) shuffledIndices[i] = i;
	    shuffleArray(shuffledIndices, population_.size());

	    int offspringPopulationSize = population_.size();
	    boolean isPopulationSizeOdd = false;

	    if (population_.size() % 2 != 0) {
		offspringPopulationSize += 1;
		isPopulationSizeOdd = true;
	    }
	    
	    offspringPopulation = new SolutionSet(offspringPopulationSize);
	    Solution[] parents = new Solution[2];
    
	    for (int i = 0; i < offspringPopulationSize; i+=2) {
		parents[0] = population_.get(shuffledIndices[i]);

		if (isPopulationSizeOdd == true && i == (population_.size() - 1)) parents[1] = population_.get(shuffledIndices[0]);
		else parents[1] = population_.get(shuffledIndices[i+1]);

		Solution[] offSpring = (Solution[]) crossover_.execute(parents);
		mutation_.execute(offSpring[0]);
		mutation_.execute(offSpring[1]);
		problem_.evaluate(offSpring[0]);
		problem_.evaluate(offSpring[1]);	    
		problem_.evaluateConstraints(offSpring[0]);
		problem_.evaluateConstraints(offSpring[1]);
		offspringPopulation.add(offSpring[0]);
		offspringPopulation.add(offSpring[1]);
		evaluations_ += 2;	    
	    }
	
	    union = ((SolutionSet) population_).union(offspringPopulation);
	    setIdealPoint(union);
	    translateByIdealPoint(union);
	
	    int[] associatedReferenceVectors = new int[union.size()];
	
	    for (int i = 0; i < union.size(); i++) {
		double maxDistance = Double.NEGATIVE_INFINITY;
		int maxIndex = -1;

		for (int j = 0; j < problem_.getNumberOfObjectives(); j++) tmpObjVec[j] = union.get(i).getNormalizedObjective(j);	    	    
	    
		for (int j = 0; j < numReferenceVectors; j++) {
		    double distance = cosine(currentUnitReferenceVectors[j], tmpObjVec);

		    if (distance > maxDistance) {
			maxDistance = distance;
			maxIndex = j;
		    }
		}

		associatedReferenceVectors[i] = maxIndex;
	    }

	    population_.clear();      
	    
	    for (int i = 0; i < numReferenceVectors; i++) {
		ArrayList<Integer> associatedIndivIDs = new ArrayList<Integer>();

		for (int j = 0; j < union.size(); j++) {
		    if (associatedReferenceVectors[j] == i) associatedIndivIDs.add(j);
		}

		if (associatedIndivIDs.size() > 1) {
		    double minDistance = Double.POSITIVE_INFINITY;
		    int minIndex = -1;
		    int tmpIndivID;
		    for (int j = 0; j < associatedIndivIDs.size(); j++) {
			tmpIndivID = associatedIndivIDs.get(j);
			for (int k = 0; k < problem_.getNumberOfObjectives(); k++) tmpObjVec[k] = union.get(tmpIndivID).getNormalizedObjective(k);
			
			double penalty = problem_.getNumberOfObjectives() * Math.pow(scalingFactor, alpha) * acosine(currentUnitReferenceVectors[i], tmpObjVec) / minAngles[i];
			double tempDistance = (1.0 + penalty) * norm_vector(tmpObjVec);
		      
			if (tempDistance < minDistance) {
			    minDistance = tempDistance;
			    minIndex = tmpIndivID;
			}		    
		    }

		    population_.add(union.get(minIndex));
		}
		else if (associatedIndivIDs.size() == 1) {
		    int tmpIndivID = associatedIndivIDs.get(0);		
		    population_.add(union.get(tmpIndivID));
		}
	    }

	    if (currentNumIters % adaptFrequency == 0) {		
		//		System.out.println(currentNumIters + " " + adaptFrequency + " " + maxNumIters);
	    	setIdealPoint(population_);
	    	setNadirPoint(population_);

	    	for (int i = 0; i < numReferenceVectors; i++) {
	    	    for (int j = 0; j < problem_.getNumberOfObjectives(); j++) {
			currentUnitReferenceVectors[i][j] = originalUnitReferenceVectors[i][j] * (nadirPoint[j] - idealPoint[j]);
	    	    }

	    	    double norm_value = norm_vector(currentUnitReferenceVectors[i]);
	    	    for (int j = 0; j < problem_.getNumberOfObjectives(); j++) currentUnitReferenceVectors[i][j] = currentUnitReferenceVectors[i][j] / norm_value;	    	      
	    	}

	    	for (int i = 0; i < numReferenceVectors; i++) {
	    	    minAngles[i] = smallestAngleBetweenWeights(i);
	    	}	  
	    }
	    
	    currentNumIters++;
	}

	Ranking tmpRanking = new Ranking(population_);
	tmpRanking.getSubfront(0).printFeasibleFUN("primary_obj.dat");	 
	tmpRanking.getSubfront(0).printVariablesToFile("primary_var.dat");

	return tmpRanking.getSubfront(0);
    }

    public void translateByIdealPoint(SolutionSet union) {
	// The term "normalized" is not used in the original paper. Also, vectors obtained by this function are not actual normalized objective vectors in the range [0,1]^M
	double tmpNormalizedObj;
	
	for (int i = 0; i < union.size(); i++) {
	    for (int j = 0; j < problem_.getNumberOfObjectives(); j++) {
		tmpNormalizedObj = union.get(i).getObjective(j) - idealPoint[j];
		union.get(i).setNormalizedObjective(j, tmpNormalizedObj);
	    }
	}
    }


    public void shuffleArray(int[] array, int array_size) {
	int rand_num = 0;
	int temp_var = 0;
  
	for(int i = 1; i < array_size; i++){
	    rand_num = PseudoRandom.randInt(0, i - 1);
	    temp_var = array[i];
	    array[i] = array[rand_num];
	    array[rand_num] = temp_var;
	}
    }
    
    /**
     * Computes the smallest angle between the given reference vector and all
     * remaining vectors.
     * 
     * @param index the index of the reference vector
     * @return the smallest angle between the given reference vector and all
     *         remaining vectors
     */
    protected double smallestAngleBetweenWeights(int index) {
	double smallestAngle = Double.POSITIVE_INFINITY;
		
	for (int i = 0; i < numReferenceVectors; i++) {
	    if (i != index) {
		smallestAngle = Math.min(smallestAngle, acosine(currentUnitReferenceVectors[index], currentUnitReferenceVectors[i]));
	    }
	}
		
	return smallestAngle;
    }

    /**
     * Returns the cosine between the objective vector and a reference vector.
     * This method assumes the line is a normalized weight vector; the point
     * does not need to be normalized.
     * 
     * @param line the line originating from the origin
     * @param point the point
     * @return the cosine
     */
    public double cosine(double[] line, double[] point) {
	//	return Vector.dot(point, line) / Vector.magnitude(point);
	return innerproduct(point, line) / (norm_vector(point) * norm_vector(line));
    }
	
    /**
     * Returns the angle between the objective vector and a reference vector.
     * This method assumes the line is a normalized weight vector; the point
     * does not need to be normalized.
     * 
     * @param line the line originating from the origin
     * @param point the point
     * @return the angle (acosine)
     */
    public double acosine(double[] line, double[] point) {
	double cos_value = cosine(line, point);
	if (cos_value > 1) cos_value = 1;	
	return Math.acos(cos_value);
    }
        
    /**
     * Initialize the weight vectors, this function only can read from the 
     * existing data file, instead of generating itself.
     * 
     */
    public void initUniformWeight() {
	String dataFileName;
	dataFileName = "M" + problem_.getNumberOfObjectives() + "_mu" + populationSize_  +  ".dat";

	try {
	    // Open the file
	    FileInputStream fis = new FileInputStream(dataDirectory_ + "/"
						      + dataFileName);
	    InputStreamReader isr = new InputStreamReader(fis);
	    BufferedReader br = new BufferedReader(isr);

	    int i = 0;
	    int j = 0;
	    String aux = br.readLine();
	    while (aux != null && i < populationSize_ ) {
		StringTokenizer st = new StringTokenizer(aux);
		j = 0;
		while (st.hasMoreTokens()) {
		    double value = (new Double(st.nextToken())).doubleValue();
		    if (value == 0) value = 1e-5;
		    originalWeightVectors[i][j] = value;

		    j++;
		}
		aux = br.readLine();
		i++;
	    }
	    br.close();
	} catch (Exception e) {
	    System.out
		.println("initUniformWeight: failed when reading for file: "
			 + dataDirectory_ + "/" + dataFileName);
	    e.printStackTrace();
	}

	// System.out.println("----------------------------");
	// for (int i = 0; i < populationSize_; i++) {
	//     for (int j = 0; j < problem_.getNumberOfObjectives() - 1; j++) {
	// 	System.out.print(originalWeightVectors[i][j] + " ");
	//     }
	//     System.out.println(originalWeightVectors[i][problem_.getNumberOfObjectives() - 1]);
	// }
	// System.exit(1);
	// System.out.println("----------------------------");
    } // initUniformWeight



    /**
     * 
     */
    public void initPopulation() throws JMException, ClassNotFoundException {
	DecimalFormat exp_form = new DecimalFormat("0.00000000E0");

	for (int i = 0; i < populationSize_; i++) {
	    Solution newSolution = new Solution(problem_);
	    problem_.evaluate(newSolution);
	    evaluations_++;
	    population_.add(newSolution) ;
	} // for
    } // initPopulation

    /**
     * 
     */
    void initIdealPoint() throws JMException, ClassNotFoundException {
	for (int i = 0; i < problem_.getNumberOfObjectives(); i++) {
	    idealPoint[i] = 1.0e+30;
	}

	for (int i = 0; i < populationSize_; i++) {
	    updateIdealPoint(population_.get(i));
	}

    } // initIdealPoint

    /**
     * 
     * @param individual
     */
    void updateIdealPoint(Solution individual) {
	for (int n = 0; n < problem_.getNumberOfObjectives(); n++) {
	    if (individual.getObjective(n) < idealPoint[n]) {
		idealPoint[n] = individual.getObjective(n);
	    }
	}
    } // updateReference


    /**
     * 
     * @param individual
     */
    void setIdealPoint(SolutionSet population) {
	for (int i = 0; i < problem_.getNumberOfObjectives(); i++) idealPoint[i] = 1.0e+30;	

	for (int i = 0; i < population.size(); i++) {
	    for (int j = 0; j < problem_.getNumberOfObjectives(); j++) {
		if (population.get(i).getObjective(j) < idealPoint[j])  idealPoint[j] = population.get(i).getObjective(j);
	    }
	}
    }


    /**
     * 
     * @param individual
     */
    void setNadirPoint(SolutionSet population) {
	for (int i = 0; i < problem_.getNumberOfObjectives(); i++) nadirPoint[i] = -1.0e+30;	

	for (int i = 0; i < population.size(); i++) {
	    for (int j = 0; j < problem_.getNumberOfObjectives(); j++) {
		if (population.get(i).getObjective(j) > nadirPoint[j])  nadirPoint[j] = population.get(i).getObjective(j);
	    }
	}
    }
    

    /**
     * Calculate the norm of the vector
     * 
     * @param z
     * @return
     */
    public double norm_vector(double[] z) {
	double sum = 0;

	for (int i = 0; i < problem_.getNumberOfObjectives(); i++)
	    sum += z[i] * z[i];

	return Math.sqrt(sum);
    }

    /**
     * Calculate the dot product of two vectors
     * 
     * @param vec1
     * @param vec2
     * @return
     */
    public double innerproduct(double[] vec1, double[] vec2) {
	double sum = 0;

	for (int i = 0; i < vec1.length; i++)
	    sum += vec1[i] * vec2[i];

	return sum;
    }
} // RVEA

