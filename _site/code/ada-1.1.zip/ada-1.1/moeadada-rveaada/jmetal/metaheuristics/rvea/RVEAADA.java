//  RVEAADA.java
//
//  Author:
//      Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2018 Ryoji Tanabe
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.metaheuristics.rvea;

import jmetal.core.*;
import jmetal.util.*;
import jmetal.util.JMException;
import jmetal.util.PseudoRandom;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.util.Vector;

import java.util.ArrayList;
import jmetal.util.wrapper.XReal;

import java.text.DecimalFormat;

public class RVEAADA extends Algorithm {
    int populationSize_;
    SolutionSet population_;
    SolutionSet offspringPopulation;
    SolutionSet union;
   
    /**
     * Z vector (ideal point)
     */
    double[] idealPoint;

    /**
     * Z vector (nadir point)
     */
    double[] nadirPoint;

    /**
     * Lambda vectors
     */
    double[][] originalWeightVectors;
    double[][] originalUnitReferenceVectors;
    double[][] currentUnitReferenceVectors;    

    int evaluations_;

    /**
     * Operators
     */
    Operator crossover_;
    Operator mutation_;
    
    String dataDirectory_;
    int numReferenceVectors;
    double[] minAngles;
    double[] tmpObjVec;
    double alpha;
    double scalingFactor;
    int maxPopulationSize;    

    double[] variablesUpperBounds;
    double[] variablesLowerBounds;
    int territorialNeighborhoodSize;
    double territorySizeRate;
     
    /** 
     * Constructor
     * @param problem Problem to solve
     */
    public RVEAADA(Problem problem, double seed) {
	super (problem) ;
	PseudoRandom.initializePseudoRandom(seed);
    } // DMOEA

    public SolutionSet execute() throws JMException, ClassNotFoundException {
	int maxEvaluations;

	evaluations_ = 0;
	maxEvaluations = ((Integer) this.getInputParameter("maxEvaluations")).intValue();
	populationSize_ = ((Integer) this.getInputParameter("populationSize")).intValue();
	numReferenceVectors = populationSize_;
	dataDirectory_ = this.getInputParameter("dataDirectory").toString();
	territorySizeRate = ((Double) this.getInputParameter("territorySizeRate")).doubleValue();    

	maxPopulationSize = 10000;
	population_ = new SolutionSet(maxPopulationSize);
        
	idealPoint = new double[problem_.getNumberOfObjectives()];
	nadirPoint = new double[problem_.getNumberOfObjectives()];

	crossover_ = operators_.get("crossover"); // default: DE crossover
	mutation_ = operators_.get("mutation");  // default: polynomial mutation
       
	//originalWeightVectors = new Vector(problem_.getNumberOfObjectives()) ;
	originalWeightVectors = new double[populationSize_][problem_.getNumberOfObjectives()];
	originalUnitReferenceVectors = new double[populationSize_][problem_.getNumberOfObjectives()];
	currentUnitReferenceVectors = new double[populationSize_][problem_.getNumberOfObjectives()];
	
	initUniformWeight();

	for (int i = 0; i < numReferenceVectors; i++) {
	    double norm_value = norm_vector(originalWeightVectors[i]);
	    for (int j = 0; j < problem_.getNumberOfObjectives(); j++) originalUnitReferenceVectors[i][j] = originalWeightVectors[i][j] / norm_value;	    
	}

	for (int i = 0; i < numReferenceVectors; i++) {
	    for (int j = 0; j < problem_.getNumberOfObjectives(); j++) currentUnitReferenceVectors[i][j] = originalUnitReferenceVectors[i][j];
	}       

	// compute the minimum angles between reference vectors
	minAngles = new double[numReferenceVectors];
		
	for (int i = 0; i < numReferenceVectors; i++) {
	    minAngles[i] = smallestAngleBetweenWeights(i);
	}

	initPopulation();
	initIdealPoint();   
	
	int currentNumIters = 0;
	int maxNumIters = maxEvaluations / populationSize_;

	while (maxNumIters * populationSize_ < maxEvaluations) {
	    maxNumIters += 1;
	}
	
	alpha = 2.0;       
	int adaptFrequency = maxEvaluations / 10;
      	
	tmpObjVec = new double[problem_.getNumberOfObjectives()];

	XReal tmpInd = new XReal(population_.get(0));
	variablesUpperBounds = new double[problem_.getNumberOfVariables()];
	variablesLowerBounds = new double[problem_.getNumberOfVariables()];
    
	for (int k = 0; k < problem_.getNumberOfVariables(); k++) {
	    variablesUpperBounds[k] = tmpInd.getUpperBound(k);
	    variablesLowerBounds[k] = tmpInd.getLowerBound(k);
	}	
	
	int r1, r2;
	
	while (evaluations_ < maxEvaluations) {	    
	    scalingFactor = Math.min(currentNumIters / (double)maxNumIters, 1.0);
	    	    
	    Solution child;       
	    Solution[] parents = new Solution[2];
	   
	    // random selection
	    r1 = PseudoRandom.randInt(0, population_.size() - 1);
	    do {
		r2 = PseudoRandom.randInt(0, population_.size() - 1);
	    } while (r2 == r1);
	
	    parents[0] = population_.get(r1);
	    parents[1] = population_.get(r2);

	    Solution[] offSpring = (Solution[]) crossover_.execute(parents);
	    child = offSpring[0];
	    mutation_.execute(child);
	    problem_.evaluate(child);      
	    problem_.evaluateConstraints(child);
	    evaluations_++;

	    offspringPopulation = new SolutionSet(1);
	    offspringPopulation.add(child);
	    
	    union = ((SolutionSet) population_).union(offspringPopulation);
	    setIdealPoint(union);
	    translateByIdealPoint(union);
		
	    for (int i = 0; i < union.size(); i++) {
		double maxDistance = Double.NEGATIVE_INFINITY;
		int maxIndex = -1;

		for (int j = 0; j < problem_.getNumberOfObjectives(); j++) tmpObjVec[j] = union.get(i).getNormalizedObjective(j);	    	    
	    
		for (int j = 0; j < numReferenceVectors; j++) {
		    double distance = cosine(currentUnitReferenceVectors[j], tmpObjVec);

		    if (distance > maxDistance) {
			maxDistance = distance;
			maxIndex = j;
		    }
		}

		union.get(i).setSubProbID(maxIndex);
	    }

	    ArrayList<Integer> candidateIndivIDs = new ArrayList<Integer>();

	    int tmpProbID;
	    int updateSubprobID = child.getSubProbID();

	    for (int i = 0; i < population_.size(); i++) population_.get(i).setReplacedOrder(-1);

	    for (int i = 0; i < population_.size(); i++) {
		tmpProbID = population_.get(i).getSubProbID();
		if (tmpProbID == updateSubprobID) candidateIndivIDs.add(i);
	    }

	    if (candidateIndivIDs.size() == 0) {
		population_.add(child);
	    }
	    else {	    
		boolean isExistsNeighborhood = false;		       
		int tmpIndvID;
		double fitnessChild;
		double fitnessTarget;
	    
		int[] sortedIndeces = getSortedIndeces(child);
		int replaced_count = 0;
		isExistsNeighborhood = false;
	    
		for (int i = 0; i < candidateIndivIDs.size(); i++) {	
		    tmpIndvID = candidateIndivIDs.get(i);
		    //		isExistsNeighborhood = false;
		
		    if (isNeighborhood(tmpIndvID, sortedIndeces) == true) {
			isExistsNeighborhood = true;
			fitnessChild = getAPDValue(child, updateSubprobID);
			fitnessTarget = getAPDValue(population_.get(tmpIndvID), updateSubprobID);
		    
			if (fitnessChild < fitnessTarget) {
			    population_.replace(tmpIndvID, new Solution(child));		    
			    population_.get(tmpIndvID).setReplacedOrder(replaced_count);
			    replaced_count++;
			}
		    }
		}

		if (isExistsNeighborhood == false) {
		    population_.add(child);
		}
		if (replaced_count >= 2){
		    for (int targetRepOrder = 1; targetRepOrder < replaced_count; targetRepOrder++) {		   
			for (int j = 0; j < population_.size(); j++) {
			    if (population_.get(j).getReplacedOrder() == targetRepOrder) {
				population_.remove(j);		    
			    }
			}
		    }
		}
	    }
	    	    
	    if (currentNumIters == 0 || evaluations_ % adaptFrequency == 0) {		
		//	    	System.out.println(currentNumIters + " " + adaptFrequency + " " + maxNumIters);

	    	setIdealPoint(population_);
	    	setNadirPoint(population_);

	    	for (int i = 0; i < numReferenceVectors; i++) {
	    	    for (int j = 0; j < problem_.getNumberOfObjectives(); j++) {
	    		currentUnitReferenceVectors[i][j] = originalUnitReferenceVectors[i][j] * (nadirPoint[j] - idealPoint[j]);
	    	    }

	    	    double norm_value = norm_vector(currentUnitReferenceVectors[i]);
	    	    for (int j = 0; j < problem_.getNumberOfObjectives(); j++) currentUnitReferenceVectors[i][j] = currentUnitReferenceVectors[i][j] / norm_value;	    	      
	    	}

	    	for (int i = 0; i < numReferenceVectors; i++) {
	    	    minAngles[i] = smallestAngleBetweenWeights(i);
	    	}	  
	    }

	    currentNumIters++;     		    	    	    
	}

	Ranking tmpRanking = new Ranking(population_);

	// the primary solution set
	SolutionSet primarySolutionSet = getBestIndividuals(tmpRanking.getSubfront(0));
	primarySolutionSet.printFeasibleFUN("primary_obj.dat");	 
	primarySolutionSet.printVariablesToFile("primary_var.dat");

	// the secondary solution set
	SolutionSet secondarySolutionSet = new SolutionSet(100);
	int targerSubprobID = 76;
	    
	for (int i = 0; i < population_.size(); i++) {
	    if (population_.get(i).getSubProbID() == targerSubprobID) {	    
		secondarySolutionSet.add(population_.get(i));
	    }
	}

	secondarySolutionSet.printFeasibleFUN("secondary_obj.dat");	 
	secondarySolutionSet.printVariablesToFile("secondary_var.dat");	      
    
	// the tertiary solution set
	SolutionSet tertiarySolutionSet = getReducedPopulation(tmpRanking.getSubfront(0));	    
	tertiarySolutionSet.printFeasibleFUN("tertiary_obj.dat");	 
	tertiarySolutionSet.printVariablesToFile("tertiary_var.dat");	      
	
	return population_;
    }

    SolutionSet getBestIndividuals(SolutionSet population) throws JMException, ClassNotFoundException {
	SolutionSet bestPopulation = new SolutionSet(numReferenceVectors);
	setIdealPoint(population);
	translateByIdealPoint(population);
	
	int[] associatedReferenceVectors = new int[population.size()];
	
	for (int i = 0; i < population.size(); i++) {
	    double maxDistance = Double.NEGATIVE_INFINITY;
	    int maxIndex = -1;

	    for (int j = 0; j < problem_.getNumberOfObjectives(); j++) tmpObjVec[j] = population.get(i).getNormalizedObjective(j);	    	    
	    
	    for (int j = 0; j < numReferenceVectors; j++) {
		double distance = cosine(currentUnitReferenceVectors[j], tmpObjVec);
		
		if (distance > maxDistance) {
		    maxDistance = distance;
		    maxIndex = j;
		}
	    }

	    associatedReferenceVectors[i] = maxIndex;
	}	 

	
	for (int i = 0; i < numReferenceVectors; i++) {
	    ArrayList<Integer> associatedIndivIDs = new ArrayList<Integer>();
	    
	    for (int j = 0; j < population.size(); j++) {
		if (associatedReferenceVectors[j] == i) associatedIndivIDs.add(j);
	    }

	    if (associatedIndivIDs.size() > 1) {
		double minDistance = Double.POSITIVE_INFINITY;
		int minIndex = -1;
		int tmpIndivID;
		
		for (int j = 0; j < associatedIndivIDs.size(); j++) {
		    tmpIndivID = associatedIndivIDs.get(j);
		    for (int k = 0; k < problem_.getNumberOfObjectives(); k++) tmpObjVec[k] = population.get(tmpIndivID).getNormalizedObjective(k);
		    
		    double penalty = problem_.getNumberOfObjectives() * Math.pow(scalingFactor, alpha) * acosine(currentUnitReferenceVectors[i], tmpObjVec) / minAngles[i];
		    double tempDistance = (1.0 + penalty) * norm_vector(tmpObjVec);
		    
		    if (tempDistance < minDistance) {
			minDistance = tempDistance;
			minIndex = tmpIndivID;
		    }		    
		}
				
		bestPopulation.add(population.get(minIndex));
	    }
	    else if (associatedIndivIDs.size() == 1) {
		int tmpIndivID = associatedIndivIDs.get(0);		
		bestPopulation.add(population.get(tmpIndivID));
	    }
	}
	
	return bestPopulation;       	
    }
    
    SolutionSet getReducedPopulation(SolutionSet population_) throws JMException, ClassNotFoundException {
	SolutionSet reducedPopulation_ = new SolutionSet(numReferenceVectors);
	boolean[] isSelected = new boolean[population_.size()];
	double[][] popDistMatrix = new double[population_.size()][population_.size()];
	double[] minDistVars = new double[population_.size()];

	double tmpSumVar, tmpVar;
	int maxDistIndivIndex;
	double maxDistVar;

	//	System.out.println(population_.size() + " " + numWeightVecs);

	if (population_.size() < numReferenceVectors) {
	    for (int j = 0; j < population_.size(); j++) reducedPopulation_.add(population_.get(j));	    
	}
	else {
	    for (int j = 0; j < population_.size(); j++) {		   
		isSelected[j] = false;
		minDistVars[j] = 1e+30;
	    }

	    for (int j = 0; j < population_.size(); j++) {		   
		Variable[] variableX1 = population_.get(j).getDecisionVariables();

		for (int k = j; k < population_.size(); k++) {		   
		    if (j == k) {
			popDistMatrix[j][k] = 0;
		    }
		    else {
			Variable[] variableX2 = population_.get(k).getDecisionVariables();
			tmpSumVar = 0;
	    
			for (int l = 0; l < problem_.getNumberOfVariables(); l++) {
			    tmpVar = (variableX1[l].getValue() - variableX2[l].getValue()) / (variablesUpperBounds[l] - variablesLowerBounds[l]);			    
			    tmpSumVar += tmpVar * tmpVar;
			}
			popDistMatrix[j][k] = Math.sqrt(tmpSumVar);
		    }
		    popDistMatrix[k][j] = popDistMatrix[j][k];
		}
	    }

	    int rndIndex = PseudoRandom.randInt(0, population_.size() - 1);
	    isSelected[rndIndex] = true;

	    for (int j = 0; j < population_.size(); j++) {		   
		if (minDistVars[j] > popDistMatrix[j][rndIndex] && isSelected[j] == false) minDistVars[j] = popDistMatrix[j][rndIndex];
	    }
    
	    for (int j = 0; j < numReferenceVectors - 1; j++) {		   
		maxDistIndivIndex = -1;
		maxDistVar = 0;

		for (int k = 0; k < population_.size(); k++) {		   
		    if (isSelected[k] == false && minDistVars[k] >= maxDistVar) {
			maxDistVar = minDistVars[k];
			maxDistIndivIndex = k;
		    }  	    
		}

		// int tmpCount = 0;
		// for (int k = 0; k < population_.size(); k++) {		   
		//     if (isSelected[k] == false) {
		// 	tmpCount++;
		//     }  	    
		//     if (minDistVars[k] < maxDistVar) {
		// 	System.out.println(k + " " + minDistVars[k]);
		//     }
		// }

		// System.out.println(population_.size() + " " + isSelected.length + " " + j + " " + tmpCount + " " + maxDistIndivIndex);

		isSelected[maxDistIndivIndex] = true;
		
		for (int k = 0; k < population_.size(); k++) {		   
		    if (minDistVars[k] > popDistMatrix[k][maxDistIndivIndex] && isSelected[k] == false) minDistVars[k] = popDistMatrix[k][maxDistIndivIndex];
		}		
	    }

	    for (int j = 0; j < population_.size(); j++) {		   
		if (isSelected[j] == true) reducedPopulation_.add(population_.get(j));
	    }
	}

	return reducedPopulation_;       	
    }
    

    double getAPDValue(Solution individual, int targetSubprobID) {

	for (int k = 0; k < problem_.getNumberOfObjectives(); k++) tmpObjVec[k] = individual.getNormalizedObjective(k);		    
	double penalty = problem_.getNumberOfObjectives() * Math.pow(scalingFactor, alpha) * acosine(currentUnitReferenceVectors[targetSubprobID], tmpObjVec) / minAngles[targetSubprobID];
	double tempDistance = (1.0 + penalty) * norm_vector(tmpObjVec);

	return tempDistance;
    }
    

        void sortIndexWithQuickSort(double[] array, int first, int last, int[] index) {
	double x = array[(first + last) / 2];
	int i = first;
	int j = last;
	double temp_var = 0;
	int temp_num = 0;

	while (true) {
	    while (array[i] < x) i++;
	    while (x < array[j]) j--;      
	    if (i >= j) break;

	    temp_var = array[i];
	    array[i] = array[j];
	    array[j] = temp_var;

	    temp_num = index[i];
	    index[i] = index[j];
	    index[j] = temp_num;

	    i++;
	    j--;
	}

	if (first < (i -1)) sortIndexWithQuickSort(array, first, i - 1, index);
	if ((j + 1) < last) sortIndexWithQuickSort(array, j + 1, last, index);
    }


    int[] getSortedIndeces(Solution child) throws JMException, ClassNotFoundException {
	double[] distanceFromTarget = new double[population_.size()];
	int[] sortedIndeces = new int[population_.size()];

	Variable[] variablesTarget  = child.getDecisionVariables();
	double tmpSumVar;
	double tmpVar;

	for (int j = 0; j < population_.size(); j++) {
	    Variable[] variablesArchiveInds = population_.get(j).getDecisionVariables();
	    tmpSumVar = 0;
	    
	    for (int k = 0; k < problem_.getNumberOfVariables(); k++) {
		tmpVar = (variablesTarget[k].getValue() - variablesArchiveInds[k].getValue()) / (variablesUpperBounds[k] - variablesLowerBounds[k]);			    
		tmpSumVar += tmpVar * tmpVar;
	    }

	    distanceFromTarget[j] = Math.sqrt(tmpSumVar);
	}

	for (int j = 0; j < population_.size(); j++) sortedIndeces[j] = j;
	sortIndexWithQuickSort(distanceFromTarget, 0, population_.size() - 1, sortedIndeces);

	return sortedIndeces;
    }
    
    boolean isNeighborhood(int targetIndivID, int[] sortedIndeces) throws JMException, ClassNotFoundException {
	boolean isExistsNeighborhood = false;
	territorialNeighborhoodSize = (int)(territorySizeRate * population_.size());
	//	territorialNeighborhoodSize = (int)(territorySizeRate * numWeightVecs);
	//	System.out.println(territorySizeRate + " " + numWeightVecs + " " + currentPopulationSize + " " + population_.size() + " " + territorialNeighborhoodSize);
	
	for (int j = 0; j < territorialNeighborhoodSize; j++) {
	    if (sortedIndeces[j] == targetIndivID) {
		isExistsNeighborhood = true;
		break;
	    }
	}

	return isExistsNeighborhood;
    }

    
    // /**
    //  * Associates each solution to the nearest reference vector, returning a
    //  * list-of-lists.  The outer list maps to each reference vector using their
    //  * index.  The inner list is an unordered collection of the solutions
    //  * associated with the reference point.
    //  * 
    //  * @param population the population of solutions
    //  * @return the association of solutions to reference points
    //  */
    // protected List<List<Solution>> associateToReferencePoint(SolutionSet union) {
    // 	List<List<Solution>> result = new ArrayList<List<Solution>>();

    // 	for (int i = 0; i < numReferenceVectors; i++) {
    // 	    result.add(new ArrayList<Solution>());
    // 	}

    // 	for (Solution solution : population) {
    // 	    double[] objectives = (double[])solution.getAttribute(NORMALIZED_OBJECTIVES);
    // 	    double maxDistance = Double.NEGATIVE_INFINITY;
    // 	    int maxIndex = -1;

    // 	    for (int i = 0; i < numReferenceVectors; i++) {
    // 		double distance = cosine(currentUnitReferenceVectors.get(i), objectives);

    // 		if (distance > maxDistance) {
    // 		    maxDistance = distance;
    // 		    maxIndex = i;
    // 		}
    // 	    }
			
    // 	    // if there is only a single solution, then the normalized
    // 	    // objectives will be 0 (since the ideal point == the solution);
    // 	    // in this case, the solution could be associated with any
    // 	    // reference vector
    // 	    if (maxIndex < 0) {
    // 		maxIndex = 0;
    // 	    }

    // 	    result.get(maxIndex).add(solution);
    // 	}

    // 	return result;
    // }    

    public void translateByIdealPoint(SolutionSet union) {
	// The term "normalized" is not used in the original paper. Also, vectors obtained by this function are not actual normalized objective vectors in the range [0,1]^M
	double tmpNormalizedObj;
	
	for (int i = 0; i < union.size(); i++) {
	    for (int j = 0; j < problem_.getNumberOfObjectives(); j++) {
		tmpNormalizedObj = union.get(i).getObjective(j) - idealPoint[j];
		union.get(i).setNormalizedObjective(j, tmpNormalizedObj);
	    }
	}
    }


    public void shuffleArray(int[] array, int array_size) {
	int rand_num = 0;
	int temp_var = 0;
  
	for(int i = 1; i < array_size; i++){
	    rand_num = PseudoRandom.randInt(0, i - 1);
	    temp_var = array[i];
	    array[i] = array[rand_num];
	    array[rand_num] = temp_var;
	}
    }
    
    /**
     * Computes the smallest angle between the given reference vector and all
     * remaining vectors.
     * 
     * @param index the index of the reference vector
     * @return the smallest angle between the given reference vector and all
     *         remaining vectors
     */
    protected double smallestAngleBetweenWeights(int index) {
	double smallestAngle = Double.POSITIVE_INFINITY;
		
	for (int i = 0; i < numReferenceVectors; i++) {
	    if (i != index) {
		smallestAngle = Math.min(smallestAngle, acosine(currentUnitReferenceVectors[index], currentUnitReferenceVectors[i]));
	    }
	}
		
	return smallestAngle;
    }

    /**
     * Returns the cosine between the objective vector and a reference vector.
     * This method assumes the line is a normalized weight vector; the point
     * does not need to be normalized.
     * 
     * @param line the line originating from the origin
     * @param point the point
     * @return the cosine
     */
    public double cosine(double[] line, double[] point) {
	//	return Vector.dot(point, line) / Vector.magnitude(point);
	return innerproduct(point, line) / (norm_vector(point) * norm_vector(line));
    }
	
    /**
     * Returns the angle between the objective vector and a reference vector.
     * This method assumes the line is a normalized weight vector; the point
     * does not need to be normalized.
     * 
     * @param line the line originating from the origin
     * @param point the point
     * @return the angle (acosine)
     */
    public double acosine(double[] line, double[] point) {
	return Math.acos(cosine(line, point));
    }
    
    




    /**
     * Initialize the weight vectors, this function only can read from the 
     * existing data file, instead of generating itself.
     * 
     */
    public void initUniformWeight() {
	String dataFileName;
	// dataFileName = "W" + problem_.getNumberOfObjectives() + "D_"
	// 		+ populationSize_ + ".dat";

	//		dataFileName = "W" + problem_.getNumberOfObjectives() + "D_tanabe.dat";
	//		dataFileName = "M" + problem_.getNumberOfObjectives() + ".dat";
	dataFileName = "M" + problem_.getNumberOfObjectives() + "_mu" + populationSize_  +  ".dat";
	//		System.out.println(dataFileName);
	try {
	    // Open the file
	    FileInputStream fis = new FileInputStream(dataDirectory_ + "/"
						      + dataFileName);
	    InputStreamReader isr = new InputStreamReader(fis);
	    BufferedReader br = new BufferedReader(isr);

	    int i = 0;
	    int j = 0;
	    String aux = br.readLine();
	    while (aux != null && i < populationSize_ ) {
		StringTokenizer st = new StringTokenizer(aux);
		j = 0;
		while (st.hasMoreTokens()) {
		    double value = (new Double(st.nextToken())).doubleValue();
		    if (value == 0) value = 1e-5;
		    originalWeightVectors[i][j] = value;

		    j++;
		}
		aux = br.readLine();
		i++;

		//				System.out.println(i);
	    }
	    br.close();
	} catch (Exception e) {
	    System.out
		.println("initUniformWeight: failed when reading for file: "
			 + dataDirectory_ + "/" + dataFileName);
	    e.printStackTrace();
	}

	// System.out.println("----------------------------");

	// for (int i = 0; i < populationSize_; i++) {
	//     for (int j = 0; j < problem_.getNumberOfObjectives() - 1; j++) {
	// 	System.out.print(originalWeightVectors[i][j] + " ");
	//     }
	//     System.out.println(originalWeightVectors[i][problem_.getNumberOfObjectives() - 1]);
	// }
	// System.exit(1);
	// System.out.println("----------------------------");
    } // initUniformWeight



    /**
     * 
     */
    public void initPopulation() throws JMException, ClassNotFoundException {
	DecimalFormat exp_form = new DecimalFormat("0.00000000E0");
	//      DecimalFormat exp_form = new DecimalFormat("0.00000E0");
	//      DecimalFormat exp_form = new DecimalFormat("0.00000");

	for (int i = 0; i < populationSize_; i++) {
	    Solution newSolution = new Solution(problem_);

	    problem_.evaluate(newSolution);

	    // for (int j = 0; j < problem_.getNumberOfObjectives(); j++) {
	    // 	  System.out.print(exp_form.format(newSolution.getObjective(j)) + " ");
	    // }
	    // for (int j = 0; j < problem_.getNumberOfVariables() - 1; j++) {
	    // 	  System.out.print(newSolution.getDecisionVariables()[j] + " ");
	    // }
	    // System.out.println(newSolution.getDecisionVariables()[problem_.getNumberOfVariables() - 1]);

	    evaluations_++;
	    population_.add(newSolution) ;
	} // for
    } // initPopulation

    /**
     * 
     */
    void initIdealPoint() throws JMException, ClassNotFoundException {
	for (int i = 0; i < problem_.getNumberOfObjectives(); i++) {
	    idealPoint[i] = 1.0e+30;
	    // indArray_[i] = new Solution(problem_);
	    // problem_.evaluate(indArray_[i]);
	    //      evaluations_++;
	} // for

	for (int i = 0; i < populationSize_; i++) {
	    updateIdealPoint(population_.get(i));
	} // for

    } // initIdealPoint


    /**
     * 
     * @param individual
     */
    void updateIdealPoint(Solution individual) {
	for (int n = 0; n < problem_.getNumberOfObjectives(); n++) {
	    if (individual.getObjective(n) < idealPoint[n]) {
		idealPoint[n] = individual.getObjective(n);
	    }
	}

	// for (int n = 0; n < problem_.getNumberOfObjectives(); n++) {
	//   if (individual.getObjective(n) > nadirPoint[n]) {
	//     nadirPoint[n] = individual.getObjective(n);
	//   }
	// }

    } // updateReference


    /**
     * 
     * @param individual
     */
    void setIdealPoint(SolutionSet population) {
	for (int i = 0; i < problem_.getNumberOfObjectives(); i++) idealPoint[i] = 1.0e+30;	

	for (int i = 0; i < population.size(); i++) {
	    for (int j = 0; j < problem_.getNumberOfObjectives(); j++) {
		if (population.get(i).getObjective(j) < idealPoint[j])  idealPoint[j] = population.get(i).getObjective(j);
	    }
	}
    }


    /**
     * 
     * @param individual
     */
    void setNadirPoint(SolutionSet population) {
	for (int i = 0; i < problem_.getNumberOfObjectives(); i++) nadirPoint[i] = -1.0e+30;	

	for (int i = 0; i < population.size(); i++) {
	    for (int j = 0; j < problem_.getNumberOfObjectives(); j++) {
		if (population.get(i).getObjective(j) > nadirPoint[j])  nadirPoint[j] = population.get(i).getObjective(j);
	    }
	}
    }
    

    /**
     * Calculate the norm of the vector
     * 
     * @param z
     * @return
     */
    public double norm_vector(double[] z) {
	double sum = 0;

	for (int i = 0; i < problem_.getNumberOfObjectives(); i++)
	    sum += z[i] * z[i];

	return Math.sqrt(sum);
    }

    /**
     * Calculate the dot product of two vectors
     * 
     * @param vec1
     * @param vec2
     * @return
     */
    public double innerproduct(double[] vec1, double[] vec2) {
	double sum = 0;

	for (int i = 0; i < vec1.length; i++)
	    sum += vec1[i] * vec2[i];

	return sum;
    }



} // RVEAADA

