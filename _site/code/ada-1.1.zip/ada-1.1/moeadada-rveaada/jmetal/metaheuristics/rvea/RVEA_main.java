//  RVEA_main.java
//
//  Author:
//      Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2018 Ryoji Tanabe
//
// NOTE:
// This is based on the MOEA Framework implementation of RVEA (http://moeaframework.org/) by Dr. David Hadka
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.metaheuristics.rvea;

import jmetal.core.Algorithm;
import jmetal.core.Operator;
import jmetal.core.Problem;
import jmetal.core.SolutionSet;
import jmetal.operators.crossover.CrossoverFactory;
import jmetal.operators.mutation.MutationFactory;

import jmetal.problems.PolygonProblem;
import jmetal.problems.DT1;
import jmetal.problems.DT2;
import jmetal.problems.TWOONONE;
import jmetal.problems.SYMPART1;
import jmetal.problems.SYMPART2;
import jmetal.problems.SYMPART3;
import jmetal.problems.SSUF1;
import jmetal.problems.SSUF3;
import jmetal.problems.HPS2;
import jmetal.problems.MMMOP.*;

import jmetal.problems.ProblemFactory;
import jmetal.qualityIndicator.QualityIndicator;
import jmetal.util.Configuration;
import jmetal.util.JMException;

import java.io.IOException;
import java.util.HashMap;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
/**
 * This class executes the algorithm described in:
 * Ran Cheng, Yaochu Jin, Markus Olhofer, Bernhard Sendhoff: A Reference Vector Guided Evolutionary Algorithm for Many-Objective Optimization. IEEE Trans. Evolutionary Computation 20(5): 773-791 (2016)
 */
public class RVEA_main {
    public static Logger      logger_ ;      // Logger object
    public static FileHandler fileHandler_ ; // FileHandler object

    /**
     * @param args Command line arguments. The first (optional) argument specifies 
     *      the problem to solve.
     * @throws JMException 
     * @throws IOException 
     * @throws SecurityException 
     * Usage: three options
     *      - jmetal.metaheuristics.moead.RVEA_main
     *      - jmetal.metaheuristics.moead.RVEA_main problemName
     *      - jmetal.metaheuristics.moead.RVEA_main problemName ParetoFrontFile
     * @throws ClassNotFoundException 
 
     */
    public static void main(String [] args) throws JMException, SecurityException, IOException, ClassNotFoundException {
	Problem   problem   ;         // The problem to solve
	Algorithm algorithm ;         // The algorithm to use
	Operator  crossover ;         // Crossover operator
	Operator  mutation  ;         // Mutation operator
	HashMap  parameters ; // Operator parameters

	// Logger object and file to store log messages
	logger_      = Configuration.logger_ ;
	fileHandler_ = new FileHandler("RVEA.log"); 
	logger_.addHandler(fileHandler_) ;
	
	// testFunc \in \{PolygonProblem, RotatedPolygonProblem, DT1 (Omni-test), DT2, TWO-ON-ONE, SYMPART1, SYMPART2, SYMPART3, SSUF1, SSUF3\}
	String testFunc = "SYMPART1";
	// When PolygonProblem is not selected, numObjs and numPolygons are not used
	int numObjs = 3;
	int numPolygons = 9;
	// When DT1 is not selected, numVarsOmni is not used
	int numVarsOmni = 5;

	//  Select from "rvea" and "rvea-ada"
	String alg = "rvea-ada";
	int populationSize = 100;		   
	double territorySizeRate = 0.1;	

	int maxEvaluations = 30000;
	int runID = 0;
	double seed = 0.01 * runID;	        	

	if ("PolygonProblem".equals(testFunc)) problem = new PolygonProblem("Real", numObjs, numPolygons);	
	else if ("DT1".equals(testFunc)) problem = new DT1("Real", numVarsOmni);
	else if ("DT2".equals(testFunc)) problem = new DT2("Real");
	else if ("TWO-ON-ONE".equals(testFunc)) problem = new TWOONONE("Real");
	else if ("SYMPART1".equals(testFunc)) problem = new SYMPART1("Real");
	else if ("SYMPART2".equals(testFunc)) problem = new SYMPART2("Real");
	else if ("SYMPART3".equals(testFunc)) problem = new SYMPART3("Real");
	else if ("SSUF1".equals(testFunc)) problem = new SSUF1("Real");
	else if ("SSUF3".equals(testFunc)) problem = new SSUF3("Real");
	else if ("MMMOP1A".equals(testFunc)) problem = new MMMOP1("Real", 2, 1, 1);
	else if ("MMMOP1B".equals(testFunc)) problem = new MMMOP1("Real", 3, 1, 4);
	else if ("MMMOP2A".equals(testFunc)) problem = new MMMOP2("Real", 2, 1, 1);
	else if ("MMMOP2B".equals(testFunc)) problem = new MMMOP2("Real", 3, 1, 4);
	else if ("MMMOP3A".equals(testFunc)) problem = new MMMOP3("Real", 2, 0, 1, 0, 3);
	// In MMMOP3B, d was actually set to 1 in the Matlab code, not d=2 as presented in the original Tri... paper
	else if ("MMMOP3B".equals(testFunc)) problem = new MMMOP3("Real", 3, 0, 5, 0, 1); 
	//        else if ("MMMOP3B".equals(testFunc)) problem = new MMMOP3("Real", 3, 0, 5, 0, 2);
	else if ("MMMOP3C".equals(testFunc)) problem = new MMMOP3("Real", 2, 1, 4, 3, 3);
	else if ("MMMOP3D".equals(testFunc)) problem = new MMMOP3("Real", 3, 1, 4, 2, 2);
	else if ("MMMOP4A".equals(testFunc)) problem = new MMMOP4("Real", 2, 0, 1, 0, 4);
	else if ("MMMOP4B".equals(testFunc)) problem = new MMMOP4("Real", 3, 0, 5, 0, 3);
	else if ("MMMOP4C".equals(testFunc)) problem = new MMMOP4("Real", 2, 1, 4, 2, 4);
	else if ("MMMOP4D".equals(testFunc)) problem = new MMMOP4("Real", 3, 1, 4, 2, 3);
	else if ("MMMOP5A".equals(testFunc)) problem = new MMMOP5("Real", 2, 0, 1, 0, 3);
	else if ("MMMOP5B".equals(testFunc)) problem = new MMMOP5("Real", 3, 0, 5, 0, 1);
	else if ("MMMOP5C".equals(testFunc)) problem = new MMMOP5("Real", 2, 1, 4, 2, 2);
	else if ("MMMOP5D".equals(testFunc)) problem = new MMMOP5("Real", 3, 1, 4, 2, 1);
	else if ("MMMOP6A".equals(testFunc)) problem = new MMMOP6("Real", 2, 0, 1, 2);
	else if ("MMMOP6B".equals(testFunc)) problem = new MMMOP6("Real", 3, 0, 2, 2);
	else if ("MMMOP6C".equals(testFunc)) problem = new MMMOP6("Real", 2, 2, 1, 2);
	else if ("MMMOP6D".equals(testFunc)) problem = new MMMOP6("Real", 3, 2, 1, 2);
	else if ("HPS2".equals(testFunc)) problem = new HPS2("Real", 5);
	else {
	    System.out.println("Error! " + testFunc + " is not defined");
	    problem = new TWOONONE("Real");
	    System.exit(-1);
	}
	
	if (alg.equals("rvea")) {
	    algorithm = new RVEA(problem,seed);
	}
	else if (alg.equals("rvea-ada")) {
	    algorithm = new RVEAADA(problem,seed);
	}
	else {
	    System.out.println("Error! " + alg + " is not defined");
	    algorithm = new RVEA(problem,seed);	    
	    System.exit(-1);
	}
	
	// Algorithm parameters
	algorithm.setInputParameter("populationSize", populationSize);
	algorithm.setInputParameter("maxEvaluations", maxEvaluations);    
	algorithm.setInputParameter("dataDirectory", "sld_weight");   
	algorithm.setInputParameter("territorySizeRate", territorySizeRate);       
    
	parameters = new HashMap() ;
	parameters.put("probability", 1.0) ;
	parameters.put("distributionIndex", 20.0) ;
	crossover = CrossoverFactory.getCrossoverOperator("SBXCrossover", parameters);                   

	// Mutation operator
	parameters = new HashMap() ;
	parameters.put("probability", 1.0/problem.getNumberOfVariables()) ;
	parameters.put("distributionIndex", 20.0) ;
	mutation = MutationFactory.getMutationOperator("PolynomialMutation", parameters);                    
    
	algorithm.addOperator("crossover",crossover);
	algorithm.addOperator("mutation",mutation);
	
	SolutionSet population = algorithm.execute();      
    } //main
} // RVEA_main
