//  HPS2.java
//
//  Author:
//       Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2018 Ryoji Tanabe
//
// For details of the problem, please see the following paper:
// B. Zhang, K. Shafi, and H. A. Abbass, "On Benchmark Problems and Metrics for Decision Space Performance Analysis in Multi-Objective Optimization," IJCIA, vol. 16, no. 1, pp. 1-18, 2017.
// 
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.problems;

import jmetal.core.Problem;
import jmetal.core.Solution;
import jmetal.encodings.solutionType.ArrayRealSolutionType;
import jmetal.encodings.solutionType.BinaryRealSolutionType;
import jmetal.encodings.solutionType.RealSolutionType;
import jmetal.util.JMException;
import jmetal.util.wrapper.XReal;

/**
 * Class representing problem HPS2
 */
public class HPS2 extends Problem {  
    
    /** 
     * Constructor.
     * Creates a default instance of the HPS2 problem.
     * @param solutionType The solution type must "Real", "BinaryReal, and "ArrayReal". 
     */
    public HPS2(String solutionType) throws ClassNotFoundException {
	this(solutionType, 7);
    } // HPS2
  
    /** 
     * Constructor.
     * Creates a new instance of the HPS2 problem.
     * @param numberOfVariables Number of variables of the problem 
     * @param solutionType The solution type must "Real", "BinaryReal, and "ArrayReal". 
     */
    public HPS2(String solutionType, Integer numberOfDistanceVariables) {
	numberOfVariables_   = 2 + numberOfDistanceVariables;
	numberOfObjectives_  = 2                            ;
	numberOfConstraints_ = 0                            ;
	problemName_         = "HPS2"                    ;
        
	upperLimit_ = new double[numberOfVariables_] ;
	lowerLimit_ = new double[numberOfVariables_] ;
       
	for (int i = 0; i < numberOfVariables_; i++) {
	    lowerLimit_[i] = 0;
	    upperLimit_[i] = 1;
	} // for
        
	if (solutionType.compareTo("BinaryReal") == 0)
	    solutionType_ = new BinaryRealSolutionType(this) ;
	else if (solutionType.compareTo("Real") == 0)
	    solutionType_ = new RealSolutionType(this) ;
	else if (solutionType.compareTo("ArrayReal") == 0)
	    solutionType_ = new ArrayRealSolutionType(this) ;
	else {
	    System.out.println("Error: solution type " + solutionType + " invalid") ;
	    System.exit(-1) ;
	}
    } // HPS2
    
    /** 
     * Evaluates a solution 
     * @param solution The solution to evaluate
     * @throws JMException 
     */
    public void evaluate(Solution solution) throws JMException {
	XReal vars = new XReal(solution) ;
	double [] f = new double[2] ; // function values     
	double [] x = new double[numberOfVariables_] ;
	int k = 2;

	for (int i = 0 ; i < numberOfVariables_; i++) x[i] = vars.getValue(i) ;

	//Step 1. Calculate the position function value
	// x[0] and x[1] are the position-related variabels
	int position_rank_value = 0;
	int pos_x0 = -1;
	int pos_x1 = -1;
	double normalized_x0 = -1;
	double normalized_x1 = -1;
	
	for (int i = 0; i < 5; i++) {
	    double lower_var = 0.2 * i;
	    double upper_var = 0.2 * (i + 1);

	    // System.out.println(lower_var + " " + upper_var);
	    
	    if (lower_var <= x[0] && upper_var >= x[0]) {
		pos_x0 = i;
		normalized_x0 = (x[0] - lower_var) / (upper_var - lower_var);
	    }
	    if (lower_var <= x[1] && upper_var >= x[1]) {
		pos_x1 = i;	    
		normalized_x1 = (x[1] - lower_var) / (upper_var - lower_var);
	    }
	}
	
	double tmp_var = normalized_x0 + normalized_x1 + 1;
			
	if ((x[0] >= 0.2 && x[0] <= 0.4) || (x[0] >= 0.6 && x[0] <= 0.8)) {
	    if ((x[1] >= 0.2 && x[1] <= 0.4) || (x[1] >= 0.6 && x[1] <= 0.8)) {
		position_rank_value = 1;
	    }
	}
	
	if (position_rank_value == 0 && (x[0] >= 0.2 && x[0] <= 0.8) && (x[1] >= 0.2 && x[1] <= 0.8)) {
	    position_rank_value = 2;						
	}

	if (position_rank_value == 0) position_rank_value = 3;						
			      	
	f[0] = position_rank_value * (tmp_var);
	f[1] = position_rank_value * (1 / tmp_var);
	
	//Step 2. Calculate the distance function value
	// x[i] (i>1) are the distance-related variabels
	double g = 0.0;
	for (int i = k; i < numberOfVariables_; i++) g += (x[i] - 0.5)*(x[i] - 0.5) - Math.cos(20.0 * Math.PI * (x[i] - 0.5));
	
	g = 1 + 100 * (numberOfVariables_ - k + g);        

	f[0] *= g;
	f[1] *= g;

	solution.setObjective(0, f[0]);
	solution.setObjective(1, f[1]);
    } // evaluate
} // HPS2
