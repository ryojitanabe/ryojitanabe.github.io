//  MMMOP4.java
//
//  Author:
//       Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2018 Ryoji Tanabe
//
// For details of the problem, please see the following paper:
// Y. Liu, G. G. Yen, and D. Gong, "A Multi-Modal Multi-Objective Evolutionary Algorithm Using Two-Archive and Recombination Strategies," IEEE TEVC, 2018 (in press).
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.problems.MMMOP;

import jmetal.core.Problem;
import jmetal.core.Solution;
import jmetal.core.Variable;
import jmetal.encodings.solutionType.BinaryRealSolutionType;
import jmetal.encodings.solutionType.RealSolutionType;
import jmetal.util.JMException;

/** 
 * Class representing problem MMMOP4 
 */
public class MMMOP4 extends Problem {   
    int kA;
    int kB;
    int ci;
    int di;

    /** 
     * Creates a default MMMOP4 problem (7 variables and 3 objectives)
     * @param solutionType The solution type must "Real" or "BinaryReal". 
     */
    public MMMOP4(String solutionType) throws ClassNotFoundException {
	this(solutionType, 2, 1, 1, 1, 1);
    } // MMMOP4   
    
    /** 
     * Creates a MMMOP4 problem instance
     * @param numberOfVariables Number of variables
     * @param numberOfObjectives Number of objective functions
     * @param solutionType The solution type must "Real" or "BinaryReal". 
     */
    public MMMOP4(String solutionType, 
		  Integer numberOfObjectives,
		  Integer numberOfVariablesA,
		  Integer numberOfVariablesB,
		  Integer ciVar,
		  Integer diVar) {
	numberOfObjectives_ = numberOfObjectives;
	kA = numberOfVariablesA;
	kB = numberOfVariablesB;
	numberOfVariables_  = numberOfObjectives -1 + kA + kB;
	ci = ciVar;
	di = diVar;

	numberOfConstraints_= 0;
	problemName_        = "MMMOP4";
        
	lowerLimit_ = new double[numberOfVariables_];
	upperLimit_ = new double[numberOfVariables_];        
	for (int var = 0; var < numberOfVariables_; var++){
	    lowerLimit_[var] = 0.0;
	    upperLimit_[var] = 1.0;
	} //for
        
	if (solutionType.compareTo("BinaryReal") == 0)
	    solutionType_ = new BinaryRealSolutionType(this) ;
	else if (solutionType.compareTo("Real") == 0)
	    solutionType_ = new RealSolutionType(this) ;
	else {
	    System.out.println("Error: solution type " + solutionType + " invalid") ;
	    System.exit(-1) ;
	}            
    }            
 
    /** 
     * Evaluates a solution 
     * @param solution The solution to evaluate
     * @throws JMException 
     */    
    public void evaluate(Solution solution) throws JMException {
	Variable[] gen  = solution.getDecisionVariables();
                
	double [] x = new double[numberOfVariables_];
	double [] f = new double[numberOfObjectives_];
	double [] xA = new double[kA];
	double [] xB = new double[kB];
	int tmpID;
    
	for (int i = 0; i < numberOfVariables_; i++) x[i] = gen[i].getValue();

	for (int i = 0; i < kA; i++) {
	    tmpID = numberOfObjectives_ -1 + i;	
	    xA[i] = gen[tmpID].getValue();
	}
    
	for (int i = 0; i < kB; i++) {
	    tmpID = numberOfObjectives_ -1 + kA + i;	
	    xB[i] = gen[tmpID].getValue();
	}
    
	double resA = 0;
	double resB = 0;

	double yj;
    
	for (int i = 0; i < kA; i++) resA  += Math.cos(2 * Math.PI * ci * xA[i]);    
	for (int i = 0; i < kB; i++) resB  += (xB[i] - 0.5) * (xB[i] - 0.5) - Math.cos(20 * Math.PI * (xB[i] - 0.5));

	double g = 100 * (kA + kB + resA + resB);       
	for (int i = 0; i < numberOfObjectives_; i++) f[i] = (1.0 + g);
    
	double dsum;

	for (int i = 0; i < numberOfObjectives_; i++){
	    for (int j = 0; j < numberOfObjectives_ - (i + 1); j++) {            
		dsum = 0;	    
		yj =x[j] * di * (di + 1) * 0.5;
	    
		for (int k = di; k >= 0 ; k--) {            
		    dsum = dsum + k;              
		    if (yj <= dsum) {
			yj = (yj - dsum + k) / di;
			break;
		    }
		}
	    		
		f[i] *= Math.cos(yj*0.5*Math.PI);
	    }
    
	    if (i != 0){
		int aux = numberOfObjectives_ - (i + 1);
		dsum = 0;	    
		yj =x[aux] * di * (di + 1) * 0.5;
	    
		for (int k = di; k >= 0 ; k--) {            
		    dsum = dsum + k;              
		    if (yj <= dsum) {
			yj = (yj - dsum + k) / di;
			break;
		    }
		}
	    	    
		f[i] *= Math.sin(yj*0.5*Math.PI);
	    } // if
	} //for
    
	for (int i = 0; i < numberOfObjectives_; i++)
	    solution.setObjective(i,f[i]);        
    } // evaluate   
  
}

