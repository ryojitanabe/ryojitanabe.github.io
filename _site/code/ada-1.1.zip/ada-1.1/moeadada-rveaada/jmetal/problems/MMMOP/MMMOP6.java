//  MMMOP6.java
//
//  Author:
//       Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2018 Ryoji Tanabe
//
// For details of the problem, please see the following paper:
// Y. Liu, G. G. Yen, and D. Gong, "A Multi-Modal Multi-Objective Evolutionary Algorithm Using Two-Archive and Recombination Strategies," IEEE TEVC, 2018 (in press).
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.problems.MMMOP;

import jmetal.core.Problem;
import jmetal.core.Solution;
import jmetal.core.Variable;
import jmetal.encodings.solutionType.BinaryRealSolutionType;
import jmetal.encodings.solutionType.RealSolutionType;
import jmetal.util.JMException;

/** 
 * Class representing problem MMMOP6 
 */
public class MMMOP6 extends Problem {   
    int kA;
    int kB;
    int ci;

    /** 
     * Creates a default MMMOP6 problem (7 variables and 3 objectives)
     * @param solutionType The solution type must "Real" or "BinaryReal". 
     */
    public MMMOP6(String solutionType) throws ClassNotFoundException {
	this(solutionType, 2, 1, 1, 1);
    } // MMMOP6   
    
    /** 
     * Creates a MMMOP6 problem instance
     * @param numberOfVariables Number of variables
     * @param numberOfObjectives Number of objective functions
     * @param solutionType The solution type must "Real" or "BinaryReal". 
     */
    public MMMOP6(String solutionType, 
		  Integer numberOfObjectives,
		  Integer numberOfVariablesA,
		  Integer numberOfVariablesB,
		  Integer ciVar) {
	numberOfObjectives_ = numberOfObjectives;
	kA = numberOfVariablesA;
	kB = numberOfVariablesB;
	numberOfVariables_  = numberOfObjectives -1 + kA + kB;
	ci = ciVar;
    
	numberOfConstraints_= 0;
	problemName_        = "MMMOP6";
        
	lowerLimit_ = new double[numberOfVariables_];
	upperLimit_ = new double[numberOfVariables_];        
	for (int var = 0; var < numberOfVariables_; var++){
	    lowerLimit_[var] = 0.0;
	    upperLimit_[var] = 1.0;
	} //for
        
	if (solutionType.compareTo("BinaryReal") == 0)
	    solutionType_ = new BinaryRealSolutionType(this) ;
	else if (solutionType.compareTo("Real") == 0)
	    solutionType_ = new RealSolutionType(this) ;
	else {
	    System.out.println("Error: solution type " + solutionType + " invalid") ;
	    System.exit(-1) ;
	}            
    }            
 
    /** 
     * Evaluates a solution 
     * @param solution The solution to evaluate
     * @throws JMException 
     */    
    public void evaluate(Solution solution) throws JMException {
	Variable[] gen  = solution.getDecisionVariables();
                
	double [] x = new double[numberOfVariables_];
	double [] f = new double[numberOfObjectives_];
	double [] xA = new double[kA];
	double [] xB = new double[kB];
	int tmpID;
    
	for (int i = 0; i < numberOfVariables_; i++) x[i] = gen[i].getValue();

	for (int i = 0; i < kA; i++) {
	    tmpID = numberOfObjectives_ -1 + i;	
	    xA[i] = gen[tmpID].getValue();
	}
    
	for (int i = 0; i < kB; i++) {
	    tmpID = numberOfObjectives_ -1 + kA + i;	
	    xB[i] = gen[tmpID].getValue();
	}
    
	double resA = 0;
	double resB = 0;

	double yi;
	double yiplus;
    
	for (int i = 0; i < kA - 1; i+=1) {
	    yi = 12 * (xA[i] - 0.5);
	    yiplus = 12 * (xA[i+1] - 0.5);
	    resA  += Math.pow(yi * yi + yiplus - 11, 2) + Math.pow(yi + yiplus * yiplus - 7, 2);
	}

	double zi;
	double ti;
	double tmpVar;
    
	for (int i = 0; i < kB; i++) {
	    zi = 2 * ci * xB[i] - 2 * Math.floor(ci * xB[i]) - 1;
	    ti = 1;

	    for (int j = 0; j < numberOfObjectives_ - 1; j++) {
		tmpVar = (i * Math.PI) / kB;
		ti *= Math.sin(2 * Math.PI * x[j] + tmpVar); 
	    }
	
	    resB  += (zi - ti) * (zi - ti);
	}
	
	double g = resA + resB;       

	// This implementation is different from the Tri... paper.
	// This implementation is based on the original Matlab source code of MMMOP6.
	for (int i = 0; i < numberOfObjectives_; i++) f[i] = (1.0 + g);
    
	for (int i = 0; i < numberOfObjectives_; i++){
	    for (int j = 0; j < numberOfObjectives_ - (i + 1); j++) {            
		f[i] *= Math.cos(x[j]*0.5*Math.PI);
	    }
    
	    if (i != 0){
		int aux = numberOfObjectives_ - (i + 1);    	    
		f[i] *= Math.sin(x[aux]*0.5*Math.PI);
	    } // if
	} //for
    
	for (int i = 0; i < numberOfObjectives_; i++)
	    solution.setObjective(i,f[i]);        
    } // evaluate     
}

