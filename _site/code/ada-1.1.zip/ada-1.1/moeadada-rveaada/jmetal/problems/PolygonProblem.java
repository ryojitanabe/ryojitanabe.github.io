//  FourPolygonProblem.java
//
//  Author:
//       Antonio J. Nebro <antonio@lcc.uma.es>
//       Juan J. Durillo <durillo@lcc.uma.es>
//
//  Copyright (c) 2011 Antonio J. Nebro, Juan J. Durillo
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.
package jmetal.problems;

import jmetal.core.Problem;
import jmetal.core.Solution;
import jmetal.core.Variable;
import jmetal.encodings.solutionType.BinaryRealSolutionType;
import jmetal.encodings.solutionType.RealSolutionType;
import jmetal.util.JMException;

/**
 * Class representing problem PolygonProblem
 */
public class PolygonProblem extends Problem {  
     
    // double upperLimit_ = new double[numberOfVariables_] ;
    // double lowerLimit_ = new double[numberOfVariables_] ;
    double[][] all_polygon_coordinates_x;
    double[][] all_polygon_coordinates_y;
    int num_polygons;

  /** 
   * Constructor.
   * Creates a new instance of the PolygonProblem problem.
   * @param solutionType The solution type must "Real" or "BinaryReal".
   */
    public PolygonProblem(String solutionType, Integer numberOfObjectives, Integer num_polygons_) {
	numberOfVariables_   = 2  ;
	num_polygons = num_polygons_;
	numberOfObjectives_  = numberOfObjectives;
	numberOfConstraints_ = 0  ;
	problemName_         = "PolygonProblem"                    ;
        
	upperLimit_ = new double[numberOfVariables_] ;
	lowerLimit_ = new double[numberOfVariables_] ;
       
	for (int i = 0; i < numberOfVariables_; i++) {
	    // lowerLimit_[i] = -1.0;
	    // upperLimit_[i] = 2.0;
	    lowerLimit_[i] = 0.0;
	    upperLimit_[i] = 10.0;
	} // for
        
	if (solutionType.compareTo("BinaryReal") == 0)
	    solutionType_ = new BinaryRealSolutionType(this) ;
	else if (solutionType.compareTo("Real") == 0)
	    solutionType_ = new RealSolutionType(this) ;
	else {
	    System.out.println("Error: solution type " + solutionType + " invalid") ;
	    System.exit(-1) ;
	}  

	all_polygon_coordinates_x = new double[num_polygons][numberOfObjectives_];
	all_polygon_coordinates_y = new double[num_polygons][numberOfObjectives_];
	// all_polygon_coordinates_x = new double[num_polygons][4];
	// all_polygon_coordinates_y = new double[num_polygons][4];

	double original_polygon_coordintates_x[] = new double[numberOfObjectives_];
	double original_polygon_coordintates_y[] = new double[numberOfObjectives_];


	if (numberOfObjectives_ % 2 == 0) {
	    for (int i = 0; i < numberOfObjectives_; i++) {
		original_polygon_coordintates_x[i] = 0.5 * Math.sin(2.0*Math.PI*i/numberOfObjectives_ - Math.PI/numberOfObjectives_);
		original_polygon_coordintates_y[i] = 0.5 * Math.cos(2.0*Math.PI*i/numberOfObjectives_ - Math.PI/numberOfObjectives_);
	    }
	}
	else {
	    for (int i = 0; i < numberOfObjectives_; i++) {
		original_polygon_coordintates_x[i] = 0.5 * Math.sin(2.0*Math.PI*i/numberOfObjectives_);
		original_polygon_coordintates_y[i] = 0.5 * Math.cos(2.0*Math.PI*i/numberOfObjectives_);
	    }
	}

	// for (int i = 0; i < numberOfObjectives_; i++) {	    
	//     System.out.println(original_polygon_coordintates_x[i] + " " + original_polygon_coordintates_y[i]);
	// }
	// System.exit(1);

	double polygon_center_x = 0, polygon_center_y = 0;

	if (num_polygons == 2) {
	    for (int i = 0; i < num_polygons; i++) {	    	   
		if (i == 0) {
		    polygon_center_x = 2.5;
		    polygon_center_y = 5.0;
		}
		if (i == 1) {
		    polygon_center_x = 7.5;
		    polygon_center_y = 5.0;
		}
		for (int j = 0; j < numberOfObjectives_; j++) {
		    all_polygon_coordinates_x[i][j] = original_polygon_coordintates_x[j] + polygon_center_x;
		    all_polygon_coordinates_y[i][j] = original_polygon_coordintates_y[j] + polygon_center_y;
		}
	    }
	}
	else if (num_polygons == 4) {
	    for (int i = 0; i < num_polygons; i++) {	    	   
		if (i == 0) {
		    polygon_center_x = 2.5;
		    polygon_center_y = 2.5;
		}
		if (i == 1) {
		    polygon_center_x = 7.5;
		    polygon_center_y = 2.5;
		}
		if (i == 2) {
		    polygon_center_x = 2.5;
		    polygon_center_y = 7.5;
		}
		if (i == 3) {
		    polygon_center_x = 7.5;
		    polygon_center_y = 7.5;
		}

		for (int j = 0; j < numberOfObjectives_; j++) {
		    all_polygon_coordinates_x[i][j] = original_polygon_coordintates_x[j] + polygon_center_x;
		    all_polygon_coordinates_y[i][j] = original_polygon_coordintates_y[j] + polygon_center_y;
		}
	    }
	}
	else if (num_polygons == 9) {
	    for (int i = 0; i < num_polygons; i++) {	    	   
		if (i == 0) {
		    polygon_center_x = 1.5;
		    polygon_center_y = 1.5;
		}
		if (i == 1) {
		    polygon_center_x = 5.0;
		    polygon_center_y = 1.5;
		}
		if (i == 2) {
		    polygon_center_x = 8.5;
		    polygon_center_y = 1.5;
		}
		if (i == 3) {
		    polygon_center_x = 1.5;
		    polygon_center_y = 5.0;
		}
		if (i == 4) {
		    polygon_center_x = 5.0;
		    polygon_center_y = 5.0;
		}
		if (i == 5) {
		    polygon_center_x = 8.5;
		    polygon_center_y = 5.0;
		}
		if (i == 6) {
		    polygon_center_x = 1.5;
		    polygon_center_y = 8.5;
		}
		if (i == 7) {
		    polygon_center_x = 5.0;
		    polygon_center_y = 8.5;
		}
		if (i == 8) {
		    polygon_center_x = 8.5;
		    polygon_center_y = 8.5;
		}

		for (int j = 0; j < numberOfObjectives_; j++) {
		    all_polygon_coordinates_x[i][j] = original_polygon_coordintates_x[j] + polygon_center_x;
		    all_polygon_coordinates_y[i][j] = original_polygon_coordintates_y[j] + polygon_center_y;
		}
	    }
	}



	       

    } // PolygonProblem
    
    /** 
     * Evaluates a solution 
     * @param solution The solution to evaluate
     * @throws JMException 
     */
    public void evaluate(Solution solution) throws JMException {
	Variable[] decisionVariables  = solution.getDecisionVariables();
	double solution_x = decisionVariables[0].getValue();
	double solution_y = decisionVariables[1].getValue();

	double tmp_sum, tmp_distance, min_distance;

    
	//    System.out.println("-----------");
	for (int i = 0; i < numberOfObjectives_; i++) {
	    //    System.out.println(i + " -------");
	    min_distance = 1e+30;

	    for (int j = 0; j < num_polygons; j++) {
		//	for (int j = num_polygons - 1; j >= 0; j--) {
		tmp_sum = 0;
		tmp_sum += (solution_x - all_polygon_coordinates_x[j][i]) * (solution_x - all_polygon_coordinates_x[j][i]);
		tmp_sum += (solution_y - all_polygon_coordinates_y[j][i]) * (solution_y - all_polygon_coordinates_y[j][i]);
		tmp_distance = Math.sqrt(tmp_sum);
		if (tmp_distance < min_distance) min_distance = tmp_distance;
		//	    System.out.println(j + " " + tmp_distance + " "  + all_polygon_coordinates_x[j][i] + " " + all_polygon_coordinates_y[j][i]);
	    }

	    solution.setObjective(i, min_distance);
	}

	//	System.out.println(numberOfObjectives_ + " " + num_polygons);
        
	// solution.setObjective(1, fx[1]);
    } // evaluate
} // PolygonProblem
