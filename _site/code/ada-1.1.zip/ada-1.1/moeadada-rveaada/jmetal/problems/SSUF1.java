//  SSUF1.java
//
//  Author:
//       Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2018 Ryoji Tanabe
//
//  For details of the problem, please see the following paper:
// J. J. Liang, C. T. Yue, B. Y. Qu: Multimodal multi-objective optimization: A preliminary study. CEC 2016: 2454-2461
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.
package jmetal.problems;

import jmetal.core.Problem;
import jmetal.core.Solution;
import jmetal.core.Variable;
import jmetal.encodings.solutionType.BinaryRealSolutionType;
import jmetal.encodings.solutionType.RealSolutionType;
import jmetal.util.JMException;

/**
 * Class representing problem SSUF1
 */
public class SSUF1 extends Problem {  
     
  /** 
   * Constructor.
   * Creates a new instance of the SSUF1 problem.
   * @param solutionType The solution type must "Real" or "BinaryReal".
   */
    public SSUF1(String solutionType) {
	numberOfVariables_   = 2;
	numberOfObjectives_  = 2;
	numberOfConstraints_ = 0  ;
	problemName_         = "SSUF1"                    ;
        
	upperLimit_ = new double[numberOfVariables_] ;
	lowerLimit_ = new double[numberOfVariables_] ;
       
	// x1
	lowerLimit_[0] = 1.0;
	upperLimit_[0] = 3.0;
	//x2
	lowerLimit_[1] = -1.0;
	upperLimit_[1] = 1.0;
       
	if (solutionType.compareTo("BinaryReal") == 0)
	    solutionType_ = new BinaryRealSolutionType(this) ;
	else if (solutionType.compareTo("Real") == 0)
	    solutionType_ = new RealSolutionType(this) ;
	else {
	    System.out.println("Error: solution type " + solutionType + " invalid") ;
	    System.exit(-1) ;
	}  
    } // SSUF1
    
    /** 
     * Evaluates a solution 
     * @param solution The solution to evaluate
     * @throws JMException 
     */
    public void evaluate(Solution solution) throws JMException {
	Variable[] decisionVariables = solution.getDecisionVariables();
	double x1, x2;
	double tmpVar1, tmpVar2;

	x1 = decisionVariables[0].getValue();
	x2 = decisionVariables[1].getValue();

	// f1
	tmpVar1 = Math.abs(x1 - 2);
	solution.setObjective(0, tmpVar1);	

	// f2
	tmpVar1 = 2 * Math.pow(x2 - Math.sin(6 * Math.PI * Math.abs(x1 - 2) + Math.PI), 2);
	tmpVar2 = 1 - Math.sqrt(Math.abs(x1 - 2)) + tmpVar1;
	solution.setObjective(1, tmpVar2);	       
    } // evaluate
} // SSUF1
