// NOTE:
// The original source code was downloaded from www.cs.bham.ac.uk/~xin/papers/TEVC2016FebManyEAs.zip

package jmetal.metaheuristics.nsgaIII;

import jmetal.core.*;
import jmetal.util.*;
import jmetal.util.ranking.NondominatedRanking;
import jmetal.util.ranking.Ranking;
import jmetal.util.vector.VectorGenerator;
import jmetal.util.vector.TwoLevelWeightVectorGenerator;

import java.text.DecimalFormat;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

import java.io.FileWriter;
import java.io.IOException;
import java.io.File;

public class NSGAIIISBX extends Algorithm {
    int populationSize_;
    int numWeightVecs;
    int numChildren;

    SolutionSet population_;
    SolutionSet offspringPopulation_;
    SolutionSet union_;
    int generations_;
    Operator mutationOperator;
    Operator crossoverOperator;
    
    double[][] lambda_; // reference points

    boolean normalization_; // do normalization or not

    public NSGAIIISBX(Problem problem, double seed) {
	super(problem);		
	PseudoRandom.initializePseudoRandom(seed);
    } // NSGAII
    
    public SolutionSet execute() throws JMException, ClassNotFoundException {
	int evaluations = 0;
	int maxEvaluations = ((Integer) getInputParameter("maxEvaluations")).intValue();
	populationSize_ = ((Integer) getInputParameter("populationSize")).intValue();
	numWeightVecs = ((Integer) getInputParameter("numWeightVecs")).intValue();
	numChildren = populationSize_;
	
	generations_ = 0;

	normalization_ = ((Boolean) this.getInputParameter("normalization")).booleanValue();
	mutationOperator = operators_.get("mutation");
	crossoverOperator = operators_.get("crossover");

	initPopulation();
	evaluations += populationSize_;

	initUniformWeight();
			
	int r1, r2;
	
	while (evaluations < maxEvaluations) {
	    offspringPopulation_ = new SolutionSet(numChildren);

	    for (int i = 0; i < numChildren; i++) {
		if (evaluations < maxEvaluations) {
		    Solution[] parents = new Solution[2];
		    Solution child = new Solution(problem_);

		    r1 = PseudoRandom.randInt(0, populationSize_ - 1);
		    do {
			r2 = PseudoRandom.randInt(0, populationSize_ - 1);
		    } while (r2 == r1);
		    parents[0] = population_.get(r1);
		    parents[1] = population_.get(r2);

		    Solution[] offSpring = (Solution[]) crossoverOperator.execute(parents);
		    child = offSpring[0];	   
		    mutationOperator.execute(child);	    

		    problem_.evaluate(child);
		    problem_.evaluateConstraints(child);
		    offspringPopulation_.add(child);
		    evaluations++;
		}			    
	    } // for
							
	    union_ = ((SolutionSet) population_).union(offspringPopulation_);

	    // Ranking the union
	    Ranking ranking = new NondominatedRanking(union_);
	    int remain = populationSize_;
	    int index = 0;
	    SolutionSet front = null;
	    population_.clear();

	    // Obtain the next front
	    front = ranking.getSubfront(index);

	    while ((remain > 0) && (remain >= front.size())) {

		for (int k = 0; k < front.size(); k++) {
		    population_.add(front.get(k));
		} // for

		// Decrement remain
		remain = remain - front.size();

		// Obtain the next front
		index++;
		if (remain > 0) {
		    front = ranking.getSubfront(index);
		} // if
	    }

	    //System.out.println("aaaa " + evaluations);
	    Niching niching = new Niching(population_, front, lambda_, remain,
					  normalization_);

	    if (remain > 0) { // front contains individuals to insert
		niching.execute();
		remain = 0;
	    }
			
	    generations_++;			
	}

	Ranking tmpRanking = new NondominatedRanking(population_);
	tmpRanking.getSubfront(0).printFeasibleFUN("primary_obj.dat");	 
	tmpRanking.getSubfront(0).printVariablesToFile("primary_var.dat");

	return tmpRanking.getSubfront(0);	
	}
	    
    /**
     * Initialize the weight vectors, this function only can read from the 
     * existing data file, instead of generating itself.
     * 
     */
    public void initUniformWeight() {
	lambda_ = new double[numWeightVecs][problem_.getNumberOfObjectives()];
	String dataFileName;
	dataFileName = "sld_weight/M" + problem_.getNumberOfObjectives() + "_mu" + populationSize_ + ".dat";
	
	try {
	    // Open the file
	    FileInputStream fis = new FileInputStream(dataFileName);
	    InputStreamReader isr = new InputStreamReader(fis);
	    BufferedReader br = new BufferedReader(isr);

	    int i = 0;
	    int j = 0;
	    String aux = br.readLine();
	    while (aux != null && i < numWeightVecs) {
		StringTokenizer st = new StringTokenizer(aux);
		j = 0;
		while (st.hasMoreTokens()) {
		    double value = (new Double(st.nextToken())).doubleValue();
		    lambda_[i][j] = value;
		    j++;
		}
		aux = br.readLine();
		i++;

		//				System.out.println(i);
	    }

	    if (i != numWeightVecs) {
		System.out.println("Error! The predifined number of reference points is " + i + ", not " + numWeightVecs);
		System.exit(-1);			    
	    }

	    br.close();
	} catch (Exception e) {
	    System.out
		.println("initUniformWeight: failed when reading for file: "
			 + dataFileName);
	    e.printStackTrace();
	}

	// System.out.println("----------------------------");

	// for (int i = 0; i < numWeightVecs; i++) {
	//     for (int j = 0; j < problem_.getNumberOfObjectives() - 1; j++) {
	// 	System.out.print(lambda_[i][j] + " ");
	//     }
	//     System.out.println(lambda_[i][problem_.getNumberOfObjectives() - 1]);
	// }
	// System.exit(1);
	// System.out.println("----------------------------");
    } // initUniformWeight

    
	public void initPopulation() throws JMException, ClassNotFoundException {

		population_ = new SolutionSet(populationSize_);

		for (int i = 0; i < populationSize_; i++) {
			Solution newSolution = new Solution(problem_);

			problem_.evaluate(newSolution);
			population_.add(newSolution);

			// for (int j = 0; j < problem_.getNumberOfObjectives(); j++) {
			//     System.out.print(exp_form.format(newSolution.getObjective(j)) + " ");
			// }
			// for (int j = 0; j < problem_.getNumberOfVariables() - 1; j++) {
			//     System.out.print(newSolution.getDecisionVariables()[j] + " ");
			// }
			// System.out.println(newSolution.getDecisionVariables()[problem_.getNumberOfVariables() - 1]);

		} // for
	} // initPopulation
	
	
	static void plotLine(SolutionSet population) throws JMException {
		int nv = population.get(0).numberOfVariables();
		
		for (int i = 0; i < population.size(); i++) {
			Solution sol = population.get(i);
			System.out.print("plot(" + "[");

			for (int j = 1; j <= nv; j++) {
				if (j != nv)
					System.out.print(j + ",");
				else
					System.out.print(j + "],");

			}

			System.out.print("[");

			for (int j = 1; j <= nv; j++) {
				if (j != nv)
					System.out.print(sol.getDecisionVariables()[j - 1]
							.getValue() + ",");
				else
					System.out.print(sol.getDecisionVariables()[j - 1]
							.getValue() + "])");
			}
			System.out.println(";");
			System.out.println("hold on;");

		}
	}

} // NSGA-III

