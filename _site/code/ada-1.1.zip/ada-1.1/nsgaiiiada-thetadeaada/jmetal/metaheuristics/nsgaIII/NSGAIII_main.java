//  NSGAIII_main.java
//
//  Author:
//      Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
// NOTE:
// This is based on the source code of NSGA-III implemented by Dr. Yuan Yuan. The original source code was downloaded from www.cs.bham.ac.uk/~xin/papers/TEVC2016FebManyEAs.zip

package jmetal.metaheuristics.nsgaIII;

import java.util.HashMap;

import jmetal.core.Algorithm;
import jmetal.core.Operator;
import jmetal.core.Problem;
import jmetal.core.SolutionSet;
import jmetal.operators.crossover.CrossoverFactory;
import jmetal.operators.mutation.MutationFactory;
import jmetal.util.JMException;

import jmetal.problems.PolygonProblem;
import jmetal.problems.RotatedPolygonProblem;
import jmetal.problems.DT1;
import jmetal.problems.DT2;
import jmetal.problems.TWOONONE;
import jmetal.problems.SYMPART1;
import jmetal.problems.SYMPART2;
import jmetal.problems.SYMPART3;
import jmetal.problems.SSUF1;
import jmetal.problems.SSUF3;
import jmetal.problems.HPS2;
import jmetal.problems.MMMOP.*;

public class NSGAIII_main {
    public static void main(String args[]) throws JMException, ClassNotFoundException{		
	Problem problem; // The problem to solve
	Algorithm algorithm; // The algorithm to use
	Operator crossover;
	Operator mutation; // Mutation operator

	HashMap parameters; // Operator parameters

	// testFunc \in \{PolygonProblem, RotatedPolygonProblem, DT1 (Omni-test), DT2, TWO-ON-ONE, SYMPART1, SYMPART2, SYMPART3, SSUF1, SSUF3\}
	String testFunc = "SYMPART1";
	// When PolygonProblem is not selected, numObjs and numPolygons are not used
	int numObjs = 3;
	int numPolygons = 9;
	// When DT1 is not selected, numVarsOmni is not used
	int numVarsOmni = 5;

	//  Select from "nsga-iii" and "nsga-iii-ada"
	String alg = "nsga-iii-ada";
	int populationSize = 100;		   
	double territorySizeRate = 0.1;	

	int maxEvaluations = 30000;
	int runID = 0;
	double seed = 0.01 * runID;	        	

	if ("PolygonProblem".equals(testFunc)) problem = new PolygonProblem("Real", numObjs, numPolygons);	
	else if ("DT1".equals(testFunc)) problem = new DT1("Real", numVarsOmni);
	else if ("DT2".equals(testFunc)) problem = new DT2("Real");
	else if ("TWO-ON-ONE".equals(testFunc)) problem = new TWOONONE("Real");
	else if ("SYMPART1".equals(testFunc)) problem = new SYMPART1("Real");
	else if ("SYMPART2".equals(testFunc)) problem = new SYMPART2("Real");
	else if ("SYMPART3".equals(testFunc)) problem = new SYMPART3("Real");
	else if ("SSUF1".equals(testFunc)) problem = new SSUF1("Real");
	else if ("SSUF3".equals(testFunc)) problem = new SSUF3("Real");
	else if ("MMMOP1A".equals(testFunc)) problem = new MMMOP1("Real", 2, 1, 1);
	else if ("MMMOP1B".equals(testFunc)) problem = new MMMOP1("Real", 3, 1, 4);
	else if ("MMMOP2A".equals(testFunc)) problem = new MMMOP2("Real", 2, 1, 1);
	else if ("MMMOP2B".equals(testFunc)) problem = new MMMOP2("Real", 3, 1, 4);
	else if ("MMMOP3A".equals(testFunc)) problem = new MMMOP3("Real", 2, 0, 1, 0, 3);
	// In MMMOP3B, d was actually set to 1 in the Matlab code, not d=2 as presented in the original Tri... paper
	else if ("MMMOP3B".equals(testFunc)) problem = new MMMOP3("Real", 3, 0, 5, 0, 1); 
	//        else if ("MMMOP3B".equals(testFunc)) problem = new MMMOP3("Real", 3, 0, 5, 0, 2);
	else if ("MMMOP3C".equals(testFunc)) problem = new MMMOP3("Real", 2, 1, 4, 3, 3);
	else if ("MMMOP3D".equals(testFunc)) problem = new MMMOP3("Real", 3, 1, 4, 2, 2);
	else if ("MMMOP4A".equals(testFunc)) problem = new MMMOP4("Real", 2, 0, 1, 0, 4);
	else if ("MMMOP4B".equals(testFunc)) problem = new MMMOP4("Real", 3, 0, 5, 0, 3);
	else if ("MMMOP4C".equals(testFunc)) problem = new MMMOP4("Real", 2, 1, 4, 2, 4);
	else if ("MMMOP4D".equals(testFunc)) problem = new MMMOP4("Real", 3, 1, 4, 2, 3);
	else if ("MMMOP5A".equals(testFunc)) problem = new MMMOP5("Real", 2, 0, 1, 0, 3);
	else if ("MMMOP5B".equals(testFunc)) problem = new MMMOP5("Real", 3, 0, 5, 0, 1);
	else if ("MMMOP5C".equals(testFunc)) problem = new MMMOP5("Real", 2, 1, 4, 2, 2);
	else if ("MMMOP5D".equals(testFunc)) problem = new MMMOP5("Real", 3, 1, 4, 2, 1);
	else if ("MMMOP6A".equals(testFunc)) problem = new MMMOP6("Real", 2, 0, 1, 2);
	else if ("MMMOP6B".equals(testFunc)) problem = new MMMOP6("Real", 3, 0, 2, 2);
	else if ("MMMOP6C".equals(testFunc)) problem = new MMMOP6("Real", 2, 2, 1, 2);
	else if ("MMMOP6D".equals(testFunc)) problem = new MMMOP6("Real", 3, 2, 1, 2);
	else if ("HPS2".equals(testFunc)) problem = new HPS2("Real", 5);
	else {
	    System.out.println("Error! " + testFunc + " is not defined");
	    problem = new TWOONONE("Real");
	    System.exit(-1);
	}

	if (alg.equals("nsga-iii")) {
	    algorithm = new NSGAIIISBX(problem, seed);
	}
	else if (alg.equals("nsga-iii-ada")) {		    
	    algorithm = new NSGAIIIADA(problem, seed);
	}
	else {
	    System.out.println("Error! " + alg + " is not defined");
	    algorithm = new NSGAIIISBX(problem, seed);
	    System.exit(-1);
	}

	// Algorithm parameters
	algorithm.setInputParameter("populationSize",populationSize);
	algorithm.setInputParameter("maxEvaluations",maxEvaluations);
	algorithm.setInputParameter("numWeightVecs",populationSize);
	algorithm.setInputParameter("territorySizeRate", territorySizeRate);
		
	parameters = new HashMap() ;
	parameters.put("probability", 1.0) ;
	parameters.put("distributionIndex", 20.0) ;
	crossover = CrossoverFactory.getCrossoverOperator("SBXCrossover", parameters);                   

	// Mutation operator
	parameters = new HashMap() ;
	parameters.put("probability", 1.0/problem.getNumberOfVariables()) ;
	parameters.put("distributionIndex", 20.0) ;
	mutation = MutationFactory.getMutationOperator("PolynomialMutation", parameters);                    

	algorithm.setInputParameter("normalization", true);

	algorithm.addOperator("crossover",crossover);
	algorithm.addOperator("mutation", mutation);
				
	SolutionSet population = algorithm.execute();
    }
}
