//  ThetaDEAADA.java
//
//  Author:
//      Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2018 Ryoji Tanabe
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.metaheuristics.thetadea;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import Jama.Matrix;

import jmetal.core.Algorithm;
import jmetal.core.Operator;
import jmetal.core.Problem;
import jmetal.core.Solution;
import jmetal.core.SolutionSet;
import jmetal.operators.mutation.Mutation;

import jmetal.util.Distance;
import jmetal.util.JMException;
import jmetal.util.Permutation;
import jmetal.util.PseudoRandom;

import jmetal.util.comparators.CrowdingComparator;
import jmetal.util.comparators.DominanceComparator;
import jmetal.util.comparators.FitnessComparator;

import jmetal.util.ranking.NondominatedRanking;
import jmetal.util.ranking.Ranking;
import jmetal.util.ranking.ThetaRanking;
import jmetal.util.vector.TwoLevelWeightVectorGenerator;
import jmetal.util.vector.VectorGenerator;
import java.text.DecimalFormat;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import jmetal.util.*;

import jmetal.util.wrapper.XReal;
import java.util.ArrayList;
import jmetal.util.comparators.DominanceComparator;
import jmetal.util.comparators.OverallConstraintViolationComparator;
import java.util.Comparator;
import jmetal.core.*;

public class ThetaDEAADA extends Algorithm {

    /**
     * stores a <code>Comparator</code> for dominance checking
     */
    private static final Comparator dominance_ = new DominanceComparator();

    /**
     * stores a <code>Comparator</code> for Overal Constraint Violation
     * Comparator checking
     */
    private static final Comparator constraint_ = new OverallConstraintViolationComparator();
   
    int populationSize_;   // population size       
    SolutionSet population_;   // current population
	
    SolutionSet union_;    // the union of current population and offspring population	       	
    int generations_;   // generations			
    Operator crossover_; // crossover		
    Operator mutation_;   // mutation operator	
    boolean normalize_;  // normalization or not
    double theta_;     // parameter theta 

    double[][] lambda_; // reference points	
    double[] zideal_;   // ideal point
    double[] znadir_;   // nadir point	
    double[][] extremePoints_; // extreme points
	
    int numWeightVecs;
    double territorySizeRate;
    int territorialNeighborhoodSize;
    int maximumPopulationSize;

    double[] variablesUpperBounds;
    double[] variablesLowerBounds;    
    
    public ThetaDEAADA(Problem problem, double seed) {
	super(problem);
	PseudoRandom.initializePseudoRandom(seed);
    } // ThetaDEAADA 
	

    public SolutionSet execute() throws JMException, ClassNotFoundException {
	generations_ = 0;

	int evaluations_ = 0;
	int maxEvaluations = ((Integer) getInputParameter("maxEvaluations")).intValue();
	maximumPopulationSize = 10000;
	populationSize_ = ((Integer) getInputParameter("populationSize")).intValue();
	numWeightVecs = populationSize_;
	territorySizeRate = ((Double) this.getInputParameter("territorySizeRate")).doubleValue();       

	theta_ =  ((Double)this.getInputParameter("theta")).doubleValue();
	normalize_ = ((Boolean) this.getInputParameter("normalize")).booleanValue();		

	initUniformWeight();				

	crossover_ = operators_.get("crossover"); // set the crossover operator
	mutation_ = operators_.get("mutation");  // set the mutation operator		
	
	initPopulation();   // initialize the population;
	evaluations_  += populationSize_;

	initIdealPoint();  // initialize the ideal point		
	initNadirPoint();    // initialize the nadir point		
	initExtremePoints(); // initialize the extreme points

	XReal tmpInd = new XReal(population_.get(0));
	variablesUpperBounds = new double[problem_.getNumberOfVariables()];
	variablesLowerBounds = new double[problem_.getNumberOfVariables()];
	
	for (int k = 0; k < problem_.getNumberOfVariables(); k++) {
	    variablesUpperBounds[k] = tmpInd.getUpperBound(k);
	    variablesLowerBounds[k] = tmpInd.getLowerBound(k);
	}
		
	int r1, r2;

	while (evaluations_ < maxEvaluations) {
	    System.out.println("Number of evaluations = " + evaluations_);
	    Solution[] parents = new Solution[2];
	    Solution child = new Solution(problem_);

	    r1 = PseudoRandom.randInt(0, population_.size() - 1);
	    do {
		r2 = PseudoRandom.randInt(0, population_.size() - 1);
	    } while (r2 == r1);
	    parents[0] = population_.get(r1);
	    parents[1] = population_.get(r2);

	    Solution[] offSpring = (Solution[]) crossover_.execute(parents);
	    child = offSpring[0];
	    mutation_.execute(child);
	    
	    problem_.evaluate(child);
	    problem_.evaluateConstraints(child);
	    evaluations_++;		

	    SolutionSet offspringPopulation = new SolutionSet(1);
	    offspringPopulation.add(child);
	    union_ = ((SolutionSet) population_).union(offspringPopulation);	    

	    SolutionSet[] sets = getParetoFronts();
	    SolutionSet firstFront = sets[0];   // the first non-dominated front
	    
	    updateIdealPoint(firstFront);  // update the ideal point				    
	    updateNadirPoint(firstFront);  // update the nadir point
	    normalizePopulation(union_);  // normalize the population using ideal point and nadir point
	    
	    updateProblem(child);
	    generations_++;
	}

	Ranking tmpRanking = new NondominatedRanking(population_);

	// the primary solution set
	SolutionSet primarySolutionSet = getBestIndividuals(tmpRanking.getSubfront(0));
	primarySolutionSet.printFeasibleFUN("primary_obj.dat");	 
	primarySolutionSet.printVariablesToFile("primary_var.dat");

	// the secondary solution set
	SolutionSet secondarySolutionSet = new SolutionSet(100);
	int targerSubprobID = 76;
	    
	for (int i = 0; i < population_.size(); i++) {
	    if (population_.get(i).getSubProbID() == targerSubprobID) {	    
		secondarySolutionSet.add(population_.get(i));
	    }
	}

	secondarySolutionSet.printFeasibleFUN("secondary_obj.dat");	 
	secondarySolutionSet.printVariablesToFile("secondary_var.dat");	      
    
	// the tertiary solution set
	SolutionSet tertiarySolutionSet = getReducedPopulation(tmpRanking.getSubfront(0));	    
	tertiarySolutionSet.printFeasibleFUN("tertiary_obj.dat");	 
	tertiarySolutionSet.printVariablesToFile("tertiary_var.dat");	      

	return population_;		
    }



        SolutionSet getBestIndividuals(SolutionSet population) throws JMException, ClassNotFoundException {
	SolutionSet bestPopulation = new SolutionSet(numWeightVecs);
	int tmpProbID;
	int tmpIndivID;

	for (int i = 0; i < numWeightVecs; i++) {
	    ArrayList<Integer> candidateIndivIDs = new ArrayList<Integer>();

	    for (int j = 0; j < population.size(); j++) {
		tmpProbID = population.get(j).getSubProbID();
		if (tmpProbID == i) candidateIndivIDs.add(j);
	    }

	    if (candidateIndivIDs.size() == 1) {
		tmpIndivID = candidateIndivIDs.get(0);
		bestPopulation.add(population.get(tmpIndivID));		
	    }
	    else if (candidateIndivIDs.size() > 1) {	    
		SolutionSet tmpPop = new SolutionSet(candidateIndivIDs.size());

		for (int j = 0; j < candidateIndivIDs.size(); j++) {
		    tmpIndivID = candidateIndivIDs.get(j);
		    tmpPop.add(population.get(tmpIndivID));		
		}
		
		Ranking ranking = new NondominatedRanking(tmpPop);
		SolutionSet nondominatedPop = ranking.getSubfront(0);

		if (nondominatedPop.size() == 1) {
		    bestPopulation.add(nondominatedPop.get(0));				    
		}
		else {
		    int minPBIID = -1;
		    double minPBI = 1e+30;		   
		    double tmpPBI;
		    
		    for (int j = 0; j < nondominatedPop.size(); j++) {
			tmpPBI = fitnessFunction(nondominatedPop.get(j), lambda_[i]);
			
			if (tmpPBI < minPBI) {
			    minPBI = tmpPBI;
			    minPBIID = j;		
			}
		    }

		    bestPopulation.add(nondominatedPop.get(minPBIID));		
		}
	    }
	} 
       	    
	return bestPopulation;       	
    }
    

    SolutionSet getReducedPopulation(SolutionSet population_) throws JMException, ClassNotFoundException {
	SolutionSet reducedPopulation_ = new SolutionSet(numWeightVecs);
	boolean[] isSelected = new boolean[population_.size()];
	double[][] popDistMatrix = new double[population_.size()][population_.size()];
	double[] minDistVars = new double[population_.size()];

	double tmpSumVar, tmpVar;
	int maxDistIndivIndex;
	double maxDistVar;

	//	System.out.println(population_.size() + " " + numWeightVecs);

	if (population_.size() < numWeightVecs) {
	    for (int j = 0; j < population_.size(); j++) reducedPopulation_.add(population_.get(j));	    
	}
	else {
	    for (int j = 0; j < population_.size(); j++) {		   
		isSelected[j] = false;
		minDistVars[j] = 1e+30;
	    }

	    for (int j = 0; j < population_.size(); j++) {		   
		Variable[] variableX1 = population_.get(j).getDecisionVariables();

		for (int k = j; k < population_.size(); k++) {		   
		    if (j == k) {
			popDistMatrix[j][k] = 0;
		    }
		    else {
			Variable[] variableX2 = population_.get(k).getDecisionVariables();
			tmpSumVar = 0;
	    
			for (int l = 0; l < problem_.getNumberOfVariables(); l++) {
			    tmpVar = (variableX1[l].getValue() - variableX2[l].getValue()) / (variablesUpperBounds[l] - variablesLowerBounds[l]);			    
			    tmpSumVar += tmpVar * tmpVar;
			}
			popDistMatrix[j][k] = Math.sqrt(tmpSumVar);
		    }
		    popDistMatrix[k][j] = popDistMatrix[j][k];
		}
	    }

	    int rndIndex = PseudoRandom.randInt(0, population_.size() - 1);
	    isSelected[rndIndex] = true;

	    for (int j = 0; j < population_.size(); j++) {		   
		if (minDistVars[j] > popDistMatrix[j][rndIndex] && isSelected[j] == false) minDistVars[j] = popDistMatrix[j][rndIndex];
	    }
    
	    for (int j = 0; j < numWeightVecs - 1; j++) {		   
		maxDistIndivIndex = -1;
		maxDistVar = 0;

		for (int k = 0; k < population_.size(); k++) {		   
		    if (isSelected[k] == false && minDistVars[k] >= maxDistVar) {
			maxDistVar = minDistVars[k];
			maxDistIndivIndex = k;
		    }  	    
		}

		isSelected[maxDistIndivIndex] = true;
		
		for (int k = 0; k < population_.size(); k++) {		   
		    if (minDistVars[k] > popDistMatrix[k][maxDistIndivIndex] && isSelected[k] == false) minDistVars[k] = popDistMatrix[k][maxDistIndivIndex];
		}		
	    }

	    for (int j = 0; j < population_.size(); j++) {		   
		if (isSelected[j] == true) reducedPopulation_.add(population_.get(j));
	    }
	}

	return reducedPopulation_;       	
    }
        
    double fitnessFunction(Solution individual, double[] lambda) {
	double fitness;
	fitness = 0.0;

	double theta; // penalty parameter
	theta = 5.0;
	
	for (int i = 0; i < problem_.getNumberOfObjectives(); i++) {
	    if (Math.abs(lambda[i] - 1.0) <= 1e-6) {
		theta = 1E6;
		break;
	    }
	}	    

	// normalize the weight vector (line segment)
	double nd = norm_vector(lambda);
	for (int i = 0; i < problem_.getNumberOfObjectives(); i++)
	    lambda[i] = lambda[i] / nd;

	double[] realA = new double[problem_.getNumberOfObjectives()];
	double[] realB = new double[problem_.getNumberOfObjectives()];

	// difference between current point and reference point
	for (int n = 0; n < problem_.getNumberOfObjectives(); n++) {
	    //	    realA[n] = (individual.getObjective(n) - z_[n]);
	    realA[n] = (individual.getNormalizedObjective(n));
	}

	// distance along the line segment
	double d1 = Math.abs(innerproduct(realA, lambda));

	// distance to the line segment
	for (int n = 0; n < problem_.getNumberOfObjectives(); n++) {
	    //	    realB[n] = (individual.getObjective(n) - (z_[n] + d1 * lambda[n]));
	    realB[n] = (individual.getNormalizedObjective(n) - (d1 * lambda[n]));
	}

	double d2 = norm_vector(realB);
	fitness = d1 + theta * d2;

	return fitness;
  } // fitnessEvaluation

	/**
	 * Calculate the norm of the vector
	 * 
	 * @param z
	 * @return
	 */
	public double norm_vector(double[] z) {
		double sum = 0;

		for (int i = 0; i < problem_.getNumberOfObjectives(); i++)
			sum += z[i] * z[i];

		return Math.sqrt(sum);
	}

	/**
	 * Calculate the dot product of two vectors
	 * 
	 * @param vec1
	 * @param vec2
	 * @return
	 */
	public double innerproduct(double[] vec1, double[] vec2) {
		double sum = 0;

		for (int i = 0; i < vec1.length; i++)
			sum += vec1[i] * vec2[i];

		return sum;
	}    
    

    void updateProblem(Solution child) throws JMException, ClassNotFoundException {
    	int nearestProbId = 0;
    	double minDistanceVar = 1e+30;
    	double tmpDistanceVar;

    	int tmpProbID;
    	int tmpIndvID;
    	boolean isExistsNeighborhood = false;
	
    	ArrayList<Integer> candidateIndivIDs = new ArrayList<Integer>();
    	ArrayList<Integer> replacedIndivIDs = new ArrayList<Integer>();
    	int updateSubprobID;

	int flagDominate;
	double fitnessChild;
	double fitnessTarget;	
	
	//	distance in the weight space
	for (int i = 0; i < numWeightVecs; i++) {
	    tmpDistanceVar = getPerpendicularDistance(child, lambda_[i]);
	    //	    System.out.println(tmpDistanceVar);
	    if (tmpDistanceVar < minDistanceVar) {
		minDistanceVar = tmpDistanceVar;
		nearestProbId = i;		
	    }
	}

	updateSubprobID = nearestProbId;
	child.setSubProbID(updateSubprobID);
	child.setReplacedOrder(-1);

	for (int i = 0; i < population_.size(); i++) population_.get(i).setReplacedOrder(-1);

	for (int i = 0; i < population_.size(); i++) {
	    tmpProbID = population_.get(i).getSubProbID();
	    if (tmpProbID == updateSubprobID) candidateIndivIDs.add(i);
	}
		
	int[] sortedIndeces = getSortedIndeces(child);
	int replaced_count = 0;
	isExistsNeighborhood = false;
			
	for (int i = 0; i < candidateIndivIDs.size(); i++) {	
	    tmpIndvID = candidateIndivIDs.get(i);

	    if (isNeighborhood(tmpIndvID, sortedIndeces) == true) {
		isExistsNeighborhood = true;
		// child vs. population_.get(tmpIndvID)
		// -1: child dominated population_.get(tmpIndvID)
		// 1: child is dominated by population_.get(tmpIndvID)
		// 0: child and population_.get(tmpIndvID) are nondominated 
		flagDominate = constraint_.compare(child, population_.get(tmpIndvID));
		if (flagDominate == 0) {
		    flagDominate = dominance_.compare(child, population_.get(tmpIndvID));
		}

		// secondary criterion
		// if the two individuals are nondominated, the tie-breaking is beased on the PBI value
		if (flagDominate == 0) {
    		    fitnessChild = fitnessFunction(child, lambda_[updateSubprobID]);
    		    fitnessTarget = fitnessFunction(population_.get(tmpIndvID), lambda_[updateSubprobID]);

    		    if (fitnessChild < fitnessTarget) flagDominate = -1;    		    
		    else if (fitnessChild > fitnessTarget) flagDominate = 1;    		    
		    else flagDominate = -1;		    		    
		}
		
		if (flagDominate == -1) {		    
		    population_.replace(tmpIndvID, new Solution(child));		    
		    population_.get(tmpIndvID).setReplacedOrder(replaced_count);
		    replaced_count++;
		}
	    }
	}

	if (isExistsNeighborhood == false) {
	    population_.add(child);
	}
	if (replaced_count >= 2){
	    //	    System.out.println(population_.size() + " " + candidateIndivIDs.size() + " " + replaced_count);
	    for (int targetRepOrder = 1; targetRepOrder < replaced_count; targetRepOrder++) {		   
		for (int j = 0; j < population_.size(); j++) {
		    if (population_.get(j).getReplacedOrder() == targetRepOrder) population_.remove(j);	    
		}
	    }
	}
	
	for (int i = 0; i < numWeightVecs; i++) {		   
	    int tmp_couter = 0;
	    for (int j = 0; j < population_.size(); j++) {
		tmpProbID = population_.get(j).getSubProbID();
		if (tmpProbID == i) tmp_couter++;		
	    }

	    if (tmp_couter == 0) {
		System.out.println("Error! Something is wrong");
		System.exit(-1);
	    }	    
	}
    } // updateProblem


    int[] getSortedIndeces(Solution child) throws JMException, ClassNotFoundException {
	double[] distanceFromTarget = new double[population_.size()];
	int[] sortedIndeces = new int[population_.size()];

	Variable[] variablesTarget  = child.getDecisionVariables();
	double tmpSumVar;
	double tmpVar;

	for (int j = 0; j < population_.size(); j++) {
	    Variable[] variablesArchiveInds = population_.get(j).getDecisionVariables();
	    tmpSumVar = 0;
	    
	    for (int k = 0; k < problem_.getNumberOfVariables(); k++) {
		tmpVar = (variablesTarget[k].getValue() - variablesArchiveInds[k].getValue()) / (variablesUpperBounds[k] - variablesLowerBounds[k]);			    
		tmpSumVar += tmpVar * tmpVar;
	    }

	    distanceFromTarget[j] = Math.sqrt(tmpSumVar);
	}

	for (int j = 0; j < population_.size(); j++) sortedIndeces[j] = j;
	sortIndexWithQuickSort(distanceFromTarget, 0, population_.size() - 1, sortedIndeces);

	return sortedIndeces;
    }
    
    boolean isNeighborhood(int targetIndivID, int[] sortedIndeces) throws JMException, ClassNotFoundException {
	boolean isExistsNeighborhood = false;
	territorialNeighborhoodSize = (int)(territorySizeRate * population_.size());
	//	System.out.println(territorialNeighborhoodSize);
	//	territorialNeighborhoodSize = (int)(territorySizeRate * numWeightVecs);
	//	System.out.println(territorySizeRate + " " + numWeightVecs + " " + population_.size() + " " + territorialNeighborhoodSize);
	
	for (int j = 0; j < territorialNeighborhoodSize; j++) {
	    if (sortedIndeces[j] == targetIndivID) {
		isExistsNeighborhood = true;
		break;
	    }
	}

	return isExistsNeighborhood;
    }

    
    double getPerpendicularDistance(Solution individual, double[] lambda) {
	double d1, d2, nl;

	d1 = d2 = nl = 0.0;

	for (int i = 0; i < individual.getNumberOfObjectives(); i++) {
	    //d1 += (individual.getObjective(i) - zideal[i]) * lambda[i];
	    d1 += individual.getNormalizedObjective(i) * lambda[i];

	    nl += (lambda[i] * lambda[i]);
	}
	nl = Math.sqrt(nl);
	d1 = Math.abs(d1) / nl;

	for (int i = 0; i < individual.getNumberOfObjectives(); i++) {
	    //d2 += ((individual.getObjective(i) - zideal[i]) - d1 * (lambda[i] / nl)) * ((individual.getObjective(i) - zideal[i]) - d1 * (lambda[i] / nl));
	    d2 += (individual.getNormalizedObjective(i) - d1 * (lambda[i] / nl)) * (individual.getNormalizedObjective(i) - d1 * (lambda[i] / nl));

	}
	d2 = Math.sqrt(d2);

	return d2;
    }
    
    void sortIndexWithQuickSort(double[] array, int first, int last, int[] index) {
	double x = array[(first + last) / 2];
	int i = first;
	int j = last;
	double temp_var = 0;
	int temp_num = 0;

	while (true) {
	    while (array[i] < x) i++;
	    while (x < array[j]) j--;      
	    if (i >= j) break;

	    temp_var = array[i];
	    array[i] = array[j];
	    array[j] = temp_var;

	    temp_num = index[i];
	    index[i] = index[j];
	    index[j] = temp_num;

	    i++;
	    j--;
	}

	if (first < (i -1)) sortIndexWithQuickSort(array, first, i - 1, index);
	if ((j + 1) < last) sortIndexWithQuickSort(array, j + 1, last, index);
    }

    
	
    public void initExtremePoints() {
	int obj = problem_.getNumberOfObjectives();
	extremePoints_ = new double[obj][obj];
	for (int i = 0; i < obj; i++){
	    for (int j = 0; j < obj; j++){
		extremePoints_[i][j] = 1.0e+30;
	    }
	}
		
    }
	
    void getNextPopulation(SolutionSet pop){
	Ranking ranking = new ThetaRanking(pop, lambda_, zideal_, 
					   theta_, normalize_);
		
	int remain = populationSize_;
	int index = 0;
	SolutionSet front = null;
	population_.clear();

	// Obtain the next front
	front = ranking.getSubfront(index);

		
	while ((remain > 0) && (remain >= front.size())) {
			
			
	    for (int k = 0; k < front.size(); k++) {
		population_.add(front.get(k));
	    } // for

	    // Decrement remain
	    remain = remain - front.size();

	    // Obtain the next front
	    index++;
	    if (remain > 0) {
		front = ranking.getSubfront(index);
	    } // if
	} // while

	if (remain > 0) { // front contains individuals to insert
		
	    int[] perm = new Permutation().intPermutation(front.size());
	    for (int k = 0; k < remain; k++) {
		population_.add(front.get(perm[k]));
	    } // for
	    remain = 0;
			
	} // if
    }

    SolutionSet[] getParetoFronts() {
		
	SolutionSet[] sets = new SolutionSet[2];
	Ranking ranking = new NondominatedRanking(union_);

	int remain = populationSize_;
	int index = 0;
	SolutionSet front = null;
	SolutionSet mgPopulation = new SolutionSet();

	front = ranking.getSubfront(index);

	sets[0] = front;

	while ((remain > 0) && (remain >= front.size())) {

	    for (int k = 0; k < front.size(); k++) {
		mgPopulation.add(front.get(k));
	    } // for

	    // Decrement remain
	    remain = remain - front.size();

	    // Obtain the next front
	    index++;
	    if (remain > 0) {
		front = ranking.getSubfront(index);
	    } // if
	}
	if (remain > 0) { // front contains individuals to insert
	    for (int k = 0; k < front.size(); k++) {
		mgPopulation.add(front.get(k));
	    }
	}

	sets[1] = mgPopulation;

	return sets;
    }


    /**
     * Initialize the weight vectors, this function only can read from the 
     * existing data file, instead of generating itself.
     * 
     */
    public void initUniformWeight() {
	lambda_ = new double[numWeightVecs][problem_.getNumberOfObjectives()];
	String dataFileName;
	dataFileName = "sld_weight/M" + problem_.getNumberOfObjectives() + "_mu" + populationSize_ + ".dat";
	
	try {
	    // Open the file
	    FileInputStream fis = new FileInputStream(dataFileName);
	    InputStreamReader isr = new InputStreamReader(fis);
	    BufferedReader br = new BufferedReader(isr);

	    int i = 0;
	    int j = 0;
	    String aux = br.readLine();
	    while (aux != null && i < numWeightVecs) {
		StringTokenizer st = new StringTokenizer(aux);
		j = 0;
		while (st.hasMoreTokens()) {
		    double value = (new Double(st.nextToken())).doubleValue();
		    lambda_[i][j] = value;
		    j++;
		}
		aux = br.readLine();
		i++;

		//				System.out.println(i);
	    }

	    if (i != numWeightVecs) {
		System.out.println("Error! The predifined number of reference points is " + i + ", not " + numWeightVecs);
		System.exit(-1);			    
	    }

	    br.close();
	} catch (Exception e) {
	    System.out
		.println("initUniformWeight: failed when reading for file: "
			 + dataFileName);
	    e.printStackTrace();
	}

	// System.out.println("----------------------------");

	// for (int i = 0; i < numWeightVecs; i++) {
	//     for (int j = 0; j < problem_.getNumberOfObjectives() - 1; j++) {
	// 	System.out.print(lambda_[i][j] + " ");
	//     }
	//     System.out.println(lambda_[i][problem_.getNumberOfObjectives() - 1]);
	// }
	// System.exit(1);
	// System.out.println("----------------------------");
    } // initUniformWeight

    
    void initPopulation() throws JMException, ClassNotFoundException {
	//	    population_= new SolutionSet(populationSize_);
	population_ = new SolutionSet(maximumPopulationSize);
	
	for (int i = 0; i < populationSize_; i++) {
	    Solution newSolution = new Solution(problem_);
	    problem_.evaluate(newSolution);
	    problem_.evaluateConstraints(newSolution);
	    newSolution.setSubProbID(i);
	    population_.add(newSolution);
	}
    } 

	
    // void createOffSpringPopulation() throws JMException {
    // 	offspringPopulation_ = new SolutionSet(populationSize_);

    // 	for (int i = 0; i < populationSize_; i++) 
    // 	    doCrossover(i);
    // }
	
	
    // void doCrossover(int i) throws JMException{
    // 	int r;
    // 	do {
    // 	    r = PseudoRandom.randInt(0, populationSize_ - 1);
    // 	} while (r == i);
		
    // 	Solution[] parents = new Solution[2];
		
    // 	parents[0] = population_.get(i);
    // 	parents[1] = population_.get(r);
		
    // 	Solution[] offSpring = (Solution[]) crossover_
    // 	    .execute(parents);
		
    // 	mutation_.execute(offSpring[0]);
		
    // 	problem_.evaluate(offSpring[0]);
		
		
    // 	offspringPopulation_.add(offSpring[0]);
    // }
	
	
    void copyObjectiveValues(double[] array, Solution individual) {
	for (int i = 0; i < individual.numberOfObjectives(); i++) {
	    array[i] = individual.getObjective(i);
	}
    }
	

    double asfFunction(Solution sol, int j) {
	double max = Double.MIN_VALUE;
	double epsilon = 1.0E-6;

	int obj = problem_.getNumberOfObjectives();

	for (int i = 0; i < obj; i++) {

	    double val = Math.abs((sol.getObjective(i) - zideal_[i])
				  / (znadir_[i] - zideal_[i]));

	    if (j != i)
		val = val / epsilon;

	    if (val > max)
		max = val;
	}

	return max;
    }

    double asfFunction(double[] ref, int j) {
	double max = Double.MIN_VALUE;
	double epsilon = 1.0E-6;

	int obj = problem_.getNumberOfObjectives();

	for (int i = 0; i < obj; i++) {

	    double val = Math.abs((ref[i] - zideal_[i])
				  / (znadir_[i] - zideal_[i]));
			

	    if (j != i)
		val = val / epsilon;

	    if (val > max)
		max = val;
	}

	return max;
    }
	
	
	
    void initIdealPoint() {
	int obj = problem_.getNumberOfObjectives();
	zideal_ = new double[obj];
	for (int j = 0; j < obj; j++) {
	    zideal_[j] = Double.MAX_VALUE;

	    for (int i = 0; i < population_.size(); i++) {
		if (population_.get(i).getObjective(j) < zideal_[j])
		    zideal_[j] = population_.get(i).getObjective(j);
	    }
	}
    }
	
	
    void updateIdealPoint(SolutionSet pop){
	for (int j = 0; j < problem_.getNumberOfObjectives(); j++) {
	    for (int i = 0; i < pop.size(); i++) {
		if (pop.get(i).getObjective(j) < zideal_[j])
		    zideal_[j] = pop.get(i).getObjective(j);
	    }
	}
    }
	
    void initNadirPoint() {
	int obj = problem_.getNumberOfObjectives();
	znadir_ = new double[obj];
	for (int j = 0; j < obj; j++) {
	    znadir_[j] = Double.MIN_VALUE;

	    for (int i = 0; i < population_.size(); i++) {
		if (population_.get(i).getObjective(j) > znadir_[j])
		    znadir_[j] = population_.get(i).getObjective(j);
	    }
	}
    }
	
	
	

	
    void updateNadirPoint(SolutionSet pop){
		
	updateExtremePoints(pop);

		
	int obj = problem_.getNumberOfObjectives();
	double[][] temp = new double[obj][obj];

	for (int i = 0; i < obj; i++) {
	    for (int j = 0; j < obj; j++) {
		double val = extremePoints_[i][j] - zideal_[j];
		temp[i][j] = val;
	    }
	}

	Matrix EX = new Matrix(temp);

	boolean sucess = true;
		
	if (EX.rank() == EX.getRowDimension()) {
	    double[] u = new double[obj];
	    for (int j = 0; j < obj; j++)
		u[j] = 1;

	    Matrix UM = new Matrix(u, obj);

	    Matrix AL = EX.inverse().times(UM);

	    int j = 0;
	    for (j = 0; j < obj; j++) {

		double aj = 1.0 / AL.get(j, 0) + zideal_[j];
		

		if ((aj > zideal_[j]) && (!Double.isInfinite(aj)) && (!Double.isNaN(aj)))
		    znadir_[j] = aj;
		else {
		    sucess = false;
		    break;
		}
	    }
	} 
	else 
	    sucess = false;
		
		
	if (!sucess){
	    double[] zmax = computeMaxPoint(pop);
	    for (int j = 0; j < obj; j++) {
		znadir_[j] = zmax[j];
	    }
	}
    }
	
	
	
	
    public void updateExtremePoints(SolutionSet pop){
	for (int i = 0; i < pop.size(); i++)
	    updateExtremePoints(pop.get(i));
    }
	
	
    public void updateExtremePoints(Solution individual){
	int obj = problem_.getNumberOfObjectives();
	for (int i = 0; i < obj; i++){
	    double asf1 = asfFunction(individual, i);
	    double asf2 = asfFunction(extremePoints_[i], i);
			
	    if (asf1 < asf2){
		copyObjectiveValues(extremePoints_[i], individual);
	    }
	}
    }
	
	
    double[] computeMaxPoint(SolutionSet pop){
	int obj = problem_.getNumberOfObjectives();
	double zmax[] = new double[obj];
	for (int j = 0; j < obj; j++) {
	    zmax[j] = Double.MIN_VALUE;

	    for (int i = 0; i < pop.size(); i++) {
		if (pop.get(i).getObjective(j) > zmax[j])
		    zmax[j] = pop.get(i).getObjective(j);
	    }
	}
	return zmax;
    }
	
    void normalizePopulation(SolutionSet pop) {

	int obj = problem_.getNumberOfObjectives();

	for (int i = 0; i < pop.size(); i++) {
	    Solution sol = pop.get(i);

	    for (int j = 0; j < obj; j++) {

		double val = (sol.getObjective(j) - zideal_[j])
		    / (znadir_[j] - zideal_[j]);

		sol.setNormalizedObjective(j, val);
	    }
	}
    }
	

}
