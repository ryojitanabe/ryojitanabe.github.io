package jmetal.util.ranking;

import java.util.ArrayList;

import java.util.List;




import jmetal.core.Solution;
import jmetal.core.SolutionSet;

import jmetal.util.PseudoRandom;
import jmetal.util.comparators.FitnessComparator;
import jmetal.util.comparators.RankAndDistanceComparator;




public class ThetaRanking implements Ranking {

	private SolutionSet solutionSet_;

	private List<SolutionSet> ranking_;

	private SolutionSet[] refSets_;
	

	double[][] lambda_;
	double[] zideal_;

	double theta_;

	int obj_;
	
	final double inf = 1E6;
	
	boolean normalize_;

	public ThetaRanking(SolutionSet solutionSet,  double[][] lambda, 
			double[] zideal, 
			double theta, boolean normalize) {
		this.solutionSet_ = solutionSet;
		this.lambda_ = lambda;
	
		this.theta_ = theta;
		this.obj_ = solutionSet.get(0).numberOfObjectives();
	
		this.zideal_ = zideal;
		
		this.normalize_ = normalize;

		ranking_ = new ArrayList<SolutionSet>();

		refSets_ = new SolutionSet[lambda_.length];
		for (int i = 0; i < refSets_.length; i++)
			refSets_[i] = new SolutionSet();
		
		associate();
	//	printInfo();
		rank();
		
	//	System.out.println(ranking_.get(0).size());
	//	System.out.println();
		
	}
	
	
	void newRank(){
		int maxLen = Integer.MIN_VALUE;
		
		Ranking ranking = new NondominatedRanking(solutionSet_);
		
		for (int i = 0; i < refSets_.length; i++) {
		//	Ranking ranking = new NondominatedRanking(refSets_[i]);
			if (refSets_[i].size() > maxLen)
				maxLen = refSets_[i].size();
			refSets_[i].sort(new RankAndDistanceComparator());
		}
		
		
		

		for (int i = 0; i < maxLen; i++) {
			SolutionSet set = new SolutionSet();
			for (int j = 0; j < refSets_.length; j++) {
				if (refSets_[j].size() > i) {
					refSets_[j].get(i).setRank(i);
					set.add(refSets_[j].get(i));
				}
			}
			ranking_.add(set);
		}
	}
	
	
	void printInfo() {
		for (int i = 0; i < lambda_.length; i++){
			if (refSets_[i].size() == 0)
				continue;
			Ranking ranking = new NondominatedRanking(refSets_[i]);
			System.out.print(ranking.getNumberOfSubfronts() + " ");
/*			for (int j = 0; j < ranking.getNumberOfSubfronts(); j++){
				if (j ==  ranking.getNumberOfSubfronts()-1)
					System.out.print(ranking.getSubfront(j).size() + ",");
				else {
					System.out.print(";");
				}
			}*/
			
		}
		System.out.println();
	}
	
	
	void associate() {
		
		double[] dists = null;
		for (int k = 0; k < solutionSet_.size(); k++) {

			Solution sol = solutionSet_.get(k);

			dists = getDistances(sol, lambda_[0]);
			double d2 = dists[1];
			double d1 = dists[0];
			int index = 0;

			for (int j = 1; j < lambda_.length; j++) {

				dists = getDistances(sol, lambda_[j]);

				if (dists[1] < d2) {
					d2 = dists[1];
					d1 = dists[0];
					index = j;
				}
			}

			
			setFitness(sol, index, d1, d2);
			sol.setVDistance(d2);
			sol.setKDistance(d1);
			
	//		System.out.println("d1: " + d1  + "\t" + "d2: " + d2);
	
			
		//	setFitness(sol, index);
			refSets_[index].add(sol);
			sol.setClusterID(index);

		}
		
		
/*		for (int i = 0; i < refSets_.length; i++){
			SolutionSet set = refSets_[i];
			double dminV = Double.MAX_VALUE;
			double dmaxV = Double.MIN_VALUE;
			double dminK = Double.MAX_VALUE;
			double dmaxK = Double.MIN_VALUE;
			for (int j = 0; j < set.size(); j++){
				if (set.get(j).getVDistance() < dminV)
					dminV =  set.get(j).getVDistance();
				if (set.get(j).getVDistance() > dmaxV)
					dmaxV =  set.get(j).getVDistance();
				if (set.get(j).getKDistance() < dminK)
					dminK =  set.get(j).getKDistance();
				if (set.get(j).getKDistance() > dmaxK)
					dmaxK =  set.get(j).getKDistance();
			}
			
			for (int j = 0; j < set.size(); j++){
				double vd = (set.get(j).getVDistance() - dminV) / (dmaxV - dminV);
				double vk = (set.get(j).getKDistance() - dminK) / (dmaxK - dminK);
				set.get(j).setFitness(vk + theta_ * vd);
			}
		}*/
		
/*		for (int i = 0; i < refSets_.length; i++){
		//	System.out.println("cluster: " + i);
			double maxRatio = Double.MIN_VALUE;
			for (int j = 0; j < refSets_[i].size() - 1; j++){
				Solution s1 = refSets_[i].get(j);
				Solution s2 = refSets_[i].get(j + 1);
				double ratio = Math.abs((s1.getKDistance() - s2.getKDistance()) /(s1.getVDistance() - s2.getVDistance()));
				if (ratio > maxRatio)
					maxRatio = ratio;
			}
			for (int j = 0; j < refSets_[i].size(); j++) {
				if (maxRatio > 5)
					refSets_[i].get(j).setFitness(
							refSets_[i].get(j).getKDistance() + 1e6
									* refSets_[i].get(j).getVDistance());
				else
					refSets_[i].get(j).setFitness(
							refSets_[i].get(j).getKDistance() + 5
									* refSets_[i].get(j).getVDistance());
				refSets_[i].get(j).setFitness(
						refSets_[i].get(j).getKDistance() + 5 * maxRatio
								* refSets_[i].get(j).getVDistance());
			}
		}*/
	}
	
	
	void setFitness(Solution sol, int index) {  //TCH fitness

		double maxFun = -1.0e+30;

		for (int n = 0; n < this.obj_; n++) {
			double diff;

			if (this.normalize_)
				diff = Math.abs(sol.getNormalizedObjective(n));
			else
				diff = Math.abs(sol.getObjective(n) - zideal_[n]);

			double feval;
			if (lambda_[index][n] == 0) {
				feval = diff / 0.000001;
			} else {
				feval = diff / lambda_[index][n];
			}
			if (feval > maxFun) {
				maxFun = feval;
			}
		} // for
		
		sol.setFitness(maxFun);

	}
	
	
	void setFitness(Solution sol, int index, double d1, double d2){
		
		if (this.normalize_) {
			if (!isObjAxis(index))
				sol.setFitness(d1 + theta_ * d2);
			else
				sol.setFitness(d1 + inf * d2);
		}
		else {
			sol.setFitness(d1 + theta_ * d2);
		//	sol.setFitness(Math.sqrt(d1 * d1 + d2 * d2));
		//	sol.setFitness(d2);
		}
	}
	
	double[] getDistances(Solution sol, double[] ref){
		if (this.normalize_)
			return getDistancesWithNormalize(sol, ref);
		else
			return getDistancesWithoutNormalize(sol, ref);
	}
	
	
	
	boolean isObjAxis(int index){
		for (int j = 0; j < obj_; j++){
			if (lambda_[index][j] != 0 && lambda_[index][j] != 1)
				return false;
		}
		return true;
	}
	
	
	
	double[] getDistancesWithoutNormalize(Solution sol, double[] ref) {
		double[] d = new double[2];

		double d1, d2, nl;

		d1 = d2 = nl = 0.0;

		for (int i = 0; i < sol.numberOfObjectives(); i++) {
			d1 += (sol.getObjective(i) - zideal_[i]) * ref[i];
			nl += (ref[i] * ref[i]);
		}
		nl = Math.sqrt(nl);
		d1 = Math.abs(d1) / nl;

		d2 = 0;
		for (int i = 0; i < sol.numberOfObjectives(); i++) {
			d2 += ((sol.getObjective(i) - zideal_[i]) - d1 * (ref[i] / nl))
					* ((sol.getObjective(i) - zideal_[i]) - d1 * (ref[i] / nl));
		}
		d2 = Math.sqrt(d2);

		d[0] = d1;
		d[1] = d2;

		return d;
	}

	double[] getDistancesWithNormalize(Solution sol, double[] ref) {
		double ip = 0;
		double refLenSQ = 0;

		double[] d = new double[2];
		for (int j = 0; j < obj_; j++) {

			ip += sol.getNormalizedObjective(j) * ref[j];
			refLenSQ += (ref[j] * ref[j]);
		}
		refLenSQ = Math.sqrt(refLenSQ);

		d[0] = Math.abs(ip) / refLenSQ;

		d[1] = 0;
		
		
		
		for (int i = 0; i < sol.numberOfObjectives(); i++) {
			d[1] += (sol.getNormalizedObjective(i) - d[0] * (ref[i] / refLenSQ))
					* (sol.getNormalizedObjective(i) - d[0]
							* (ref[i] / refLenSQ));
		}
		d[1] = Math.sqrt(d[1]);
		
		return d;
	}


	
	

	
	
	
	void rank() {

		int maxLen = Integer.MIN_VALUE;
		for (int i = 0; i < refSets_.length; i++) {
			
			if (refSets_[i].size() > maxLen)
				maxLen = refSets_[i].size();
			refSets_[i].sort(new FitnessComparator());
		}


		for (int i = 0; i < maxLen; i++) {
			SolutionSet set = new SolutionSet();
			for (int j = 0; j < refSets_.length; j++) {
				if (refSets_[j].size() > i) {
					refSets_[j].get(i).setRank(i);
					set.add(refSets_[j].get(i));
				}
			}
			ranking_.add(set);
		}
	}


	
	
	public SolutionSet getSubfront(int rank) {
		return ranking_.get(rank);
	} // getSubFront

	/**
	 * Returns the total number of subFronts founds.
	 */
	public int getNumberOfSubfronts() {
		return ranking_.size();
	} // getNumberOfSubfronts
	
}
