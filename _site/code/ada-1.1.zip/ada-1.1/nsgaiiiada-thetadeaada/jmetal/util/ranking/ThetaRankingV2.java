package jmetal.util.ranking;


import java.util.ArrayList;

import java.util.List;




import jmetal.core.Solution;
import jmetal.core.SolutionSet;

import jmetal.util.PseudoRandom;
import jmetal.util.comparators.FitnessComparator;




public class ThetaRankingV2 implements Ranking {

	private SolutionSet solutionSet_;

	private SolutionSet[] refSets_;
	

	private SolutionSet population_;
	
	
	double[][] lambda_;
	boolean[] flag_;
	boolean[] isDele_;
	
	double[] zideal_;
	
	
	Solution[] array_;

	double theta_;

	int obj_;
	
	final double inf = 1E6;
	
	boolean normalize_;
	
	int count_;

	public ThetaRankingV2(SolutionSet solutionSet,  SolutionSet population, double[][] lambda, 
			double[] zideal, 
			double theta, boolean normalize) {
		this.solutionSet_ = solutionSet;
		this.lambda_ = lambda;
	
		this.theta_ = theta;
		this.obj_ = solutionSet.get(0).numberOfObjectives();
	
		this.zideal_ = zideal;
		
		this.normalize_ = normalize;

		refSets_ = new SolutionSet[lambda_.length];
		for (int i = 0; i < refSets_.length; i++)
			refSets_[i] = new SolutionSet();
		
		
		this.population_ = population;
		
		flag_ = new boolean[lambda_.length];
		for (int i = 0; i < flag_.length; i++)
			flag_[i] = false;
		
		isDele_ = new boolean[solutionSet_.size()];
		for (int i = 0; i < solutionSet_.size(); i++)
			isDele_[i] = false;
		
		
		count_ = 0;
		
		array_ = new Solution[lambda_.length];
		
	}
	
	
	public void execute(){
		population_.clear();
		
		while (count_ < lambda_.length){
			associate();
			addSolutions();
		}
		
		for (int i = 0; i < array_.length; i++){
			population_.add(array_[i]);
		}
	}
	
	void associate() {
		
		double[] dists = null;
		for (int k = 0; k < solutionSet_.size(); k++) {
			
			if (isDele_[k])
				continue;

			Solution sol = solutionSet_.get(k);
			
			double d2 = Double.MAX_VALUE;
			double d1 = Double.MAX_VALUE;
			int index = -1;

			for (int j = 0; j < lambda_.length; j++) {
				if (flag_[j])
					continue;

				dists = getDistances(sol, lambda_[j]);

				if (dists[1] < d2) {
					d2 = dists[1];
					d1 = dists[0];
					index = j;
				}
			}

			sol.setLocation(k);
			
			setFitness(sol, index, d1, d2);
			sol.setVDistance(d2);
			sol.setKDistance(d1);
			
			refSets_[index].add(sol);
			sol.setClusterID(index);

		}
	}
	
	
	void addSolutions(){
		for (int i = 0; i < refSets_.length; i++){
			if (flag_[i])
				continue;
			
			if (refSets_[i].size() > 0){
				double min = Double.MAX_VALUE;
				int index = -1;
				for (int j = 0; j < refSets_[i].size(); j++){
					if (refSets_[i].get(j).getFitness() < min){
						min = refSets_[i].get(j).getFitness();
						index = j;
					}
				}
		//		population_.add(refSets_[i].get(index));
				
				array_[i] = refSets_[i].get(index);
				count_++;
				
				flag_[i] = true;
				
				int loc = refSets_[i].get(index).getLocation();
				
				isDele_[loc] = true;
			}
		}
	}
	
	
	
	
	
	
	void setFitness(Solution sol, int index) {  //TCH fitness

		double maxFun = -1.0e+30;

		for (int n = 0; n < this.obj_; n++) {
			double diff;

			if (this.normalize_)
				diff = Math.abs(sol.getNormalizedObjective(n));
			else
				diff = Math.abs(sol.getObjective(n) - zideal_[n]);

			double feval;
			if (lambda_[index][n] == 0) {
				feval = diff / 0.0001;
			} else {
				feval = diff / lambda_[index][n];
			}
			if (feval > maxFun) {
				maxFun = feval;
			}
		} // for
		
		sol.setFitness(maxFun);

	}
	
	
	void setFitness(Solution sol, int index, double d1, double d2){
		
		if (this.normalize_) {
			if (!isObjAxis(index))
				sol.setFitness(d1 + theta_ * d2);
			else
				sol.setFitness(d1 + inf * d2);
		}
		else {
			sol.setFitness(d1 + theta_ * d2);
		//	sol.setFitness(Math.sqrt(d1 * d1 + d2 * d2));
		//	sol.setFitness(d2);
		}
	}
	
	double[] getDistances(Solution sol, double[] ref){
		if (this.normalize_)
			return getDistancesWithNormalize(sol, ref);
		else
			return getDistancesWithoutNormalize(sol, ref);
	}
	
	
	
	boolean isObjAxis(int index){
		for (int j = 0; j < obj_; j++){
			if (lambda_[index][j] != 0 && lambda_[index][j] != 1)
				return false;
		}
		return true;
	}
	
	
	
	double[] getDistancesWithoutNormalize(Solution sol, double[] ref) {
		double[] d = new double[2];

		double d1, d2, nl;

		d1 = d2 = nl = 0.0;

		for (int i = 0; i < sol.numberOfObjectives(); i++) {
			d1 += (sol.getObjective(i) - zideal_[i]) * ref[i];
			nl += (ref[i] * ref[i]);
		}
		nl = Math.sqrt(nl);
		d1 = Math.abs(d1) / nl;

		d2 = 0;
		for (int i = 0; i < sol.numberOfObjectives(); i++) {
			d2 += ((sol.getObjective(i) - zideal_[i]) - d1 * (ref[i] / nl))
					* ((sol.getObjective(i) - zideal_[i]) - d1 * (ref[i] / nl));
		}
		d2 = Math.sqrt(d2);

		d[0] = d1;
		d[1] = d2;

		return d;
	}

	double[] getDistancesWithNormalize(Solution sol, double[] ref) {
		double ip = 0;
		double refLenSQ = 0;

		double[] d = new double[2];
		for (int j = 0; j < obj_; j++) {

			ip += sol.getNormalizedObjective(j) * ref[j];
			refLenSQ += (ref[j] * ref[j]);
		}
		refLenSQ = Math.sqrt(refLenSQ);

		d[0] = Math.abs(ip) / refLenSQ;

		d[1] = 0;
		
		
		
		for (int i = 0; i < sol.numberOfObjectives(); i++) {
			d[1] += (sol.getNormalizedObjective(i) - d[0] * (ref[i] / refLenSQ))
					* (sol.getNormalizedObjective(i) - d[0]
							* (ref[i] / refLenSQ));
		}
		d[1] = Math.sqrt(d[1]);
		
		return d;
	}


	
	

	
	



	
	
	public SolutionSet getSubfront(int rank) {
		return null;
	} // getSubFront

	/**
	 * Returns the total number of subFronts founds.
	 */
	public int getNumberOfSubfronts() {
		return 0;
	} // getNumberOfSubfronts
	
}
