//  AnalysisDT.java
//
//  Author:
//      Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2018 Ryoji Tanabe
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.metaheuristics.analysis;

import jmetal.core.*;
import jmetal.util.JMException;

import jmetal.util.PseudoRandom;
import jmetal.util.wrapper.XReal;

import java.text.DecimalFormat;
import java.util.Vector;

public class AnalysisDT extends Algorithm {
    /**
     * Constructor
     * @param problem Problem to solve
     */
    public AnalysisDT(Problem problem) {
	super (problem) ;
    } // AnalysisDT

    public AnalysisDT(Problem problem, double rt_seed) {
	super(problem);	
	PseudoRandom.initializePseudoRandom(rt_seed);
    } // AnalysisDT

    /**   
     * @return a <code>SolutionSet</code> that is a set of non dominated solutions
     * as a result of the algorithm execution
     * @throws JMException 
     */
    public SolutionSet execute() throws JMException, ClassNotFoundException {
	int populationSize;
	int maxEvaluations;
	SolutionSet population;
	double randomVar;

	int tilePosition = PseudoRandom.randInt(0,3 - 1);
	double maxVar;
	double minVar;
	double tmpVar;
	Solution newSolution;
	
	maxEvaluations = ((Integer) getInputParameter("maxEvaluations")).intValue();
	population = new SolutionSet(maxEvaluations);

	for (int i = 0; i < maxEvaluations; i++) {
	    newSolution = new Solution(problem_);
	    Variable[] decisionVariables  = newSolution.getDecisionVariables();
	    randomVar = PseudoRandom.randDouble();

	    for (int j = 0; j < 5; j++) {
		tilePosition = PseudoRandom.randInt(0,3 - 1);
		maxVar = 2 * tilePosition  + (3.0 / 2.0);
		minVar = 2 * tilePosition  + 1.0;
		tmpVar = (maxVar - minVar) * randomVar + minVar;

		decisionVariables[j].setValue(tmpVar);			
	    }

	    problem_.evaluate(newSolution);
	    problem_.evaluateConstraints(newSolution);
	    population.add(newSolution);
	} //for       

	population.printObjectivesToFile("FUN_DT") ;
	population.printVariablesToFile("VAR_DT");    
   
	return population;
    } // execute
} 
