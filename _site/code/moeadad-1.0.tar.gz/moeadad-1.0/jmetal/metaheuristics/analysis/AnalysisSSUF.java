//  AnalysisSSUF.java
//
//  Author:
//      Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2018 Ryoji Tanabe
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.metaheuristics.analysis;

import jmetal.core.*;
import jmetal.util.JMException;

import jmetal.util.PseudoRandom;
import jmetal.util.wrapper.XReal;

import java.text.DecimalFormat;
import java.util.Vector;

public class AnalysisSSUF extends Algorithm {
    /**
     * Constructor
     * @param problem Problem to solve
     */
    public AnalysisSSUF(Problem problem) {
	super (problem) ;
    } // AnalysisSSUF

    public AnalysisSSUF(Problem problem, double rt_seed) {
	super(problem);	
	PseudoRandom.initializePseudoRandom(rt_seed);
    } // AnalysisSSUF

    /**   
     * @return a <code>SolutionSet</code> that is a set of non dominated solutions
     * as a result of the algorithm execution
     * @throws JMException 
     */
    public SolutionSet execute() throws JMException, ClassNotFoundException {
	int populationSize;
	int maxEvaluations;
	SolutionSet population;
	double randomVar;

	double tmpX1 = 0;
	double tmpX2 = 0;
	Solution newSolution;
	
	maxEvaluations = ((Integer) getInputParameter("maxEvaluations")).intValue();
	population = new SolutionSet(maxEvaluations);
	
	for (int i = 0; i < maxEvaluations; i++) {
	    newSolution = new Solution(problem_);
	    Variable[] decisionVariables  = newSolution.getDecisionVariables();

	    if  ("SSUF1".equals(problem_.getName())) { 
		tmpX1 = (3 - 1) * PseudoRandom.randDouble() + 1;
		tmpX2 = Math.sin(6 * Math.PI* Math.abs(tmpX1 - 2.0) + Math.PI);
	    }
	    else if  ("SSUF3".equals(problem_.getName())) { 
		tmpX2 = (2 - 0) * PseudoRandom.randDouble() + 0;
		tmpX1 = 0;

		if (tmpX2 >= 0 && tmpX2 <= 1) tmpX1 = tmpX2 * tmpX2;
		else if (tmpX2 > 1 && tmpX2 <= 2) tmpX1 = (tmpX2 -1) * (tmpX2 -1);
	    }

	    decisionVariables[0].setValue(tmpX1);	
	    decisionVariables[1].setValue(tmpX2);	

	    problem_.evaluate(newSolution);
	    problem_.evaluateConstraints(newSolution);
	    population.add(newSolution);
	} //for       

	population.printObjectivesToFile("FUN_" + problem_.getName());
	population.printVariablesToFile("VAR_" + problem_.getName());    
   
	return population;
    } // execute
}
