//  AnalysisSYMPART.java
//
//  Author:
//      Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2018 Ryoji Tanabe
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.metaheuristics.analysis;

import jmetal.core.*;
import jmetal.util.JMException;

import jmetal.util.PseudoRandom;
import jmetal.util.wrapper.XReal;

import java.text.DecimalFormat;
import java.util.Vector;

public class AnalysisSYMPART extends Algorithm {
  /**
   * Constructor
   * @param problem Problem to solve
   */
  public AnalysisSYMPART(Problem problem) {
      super (problem) ;
  } // AnalysisSYMPART

    public AnalysisSYMPART(Problem problem, double rt_seed) {
	super(problem);	
	PseudoRandom.initializePseudoRandom(rt_seed);
    } // AnalysisSYMPART

    /**   
     * @return a <code>SolutionSet</code> that is a set of non dominated solutions
     * as a result of the algorithm execution
     * @throws JMException 
     */
    public SolutionSet execute() throws JMException, ClassNotFoundException {
	int populationSize;
	int maxEvaluations;
	SolutionSet population;	
	Solution newSolution;
	
	maxEvaluations = ((Integer) getInputParameter("maxEvaluations")).intValue();
	population = new SolutionSet(maxEvaluations);
	
	double sympartA = 1.0;
	double sympartB = 10.0;
	double sympartC = 8.0;
	double rotationRadian = Math.toRadians(-45);
	double sympart3EpsilonVar = 0.001;
	double lowerLimit = -20.0;
	double upperLimit = 20.0;
	
	double centerX1 = 0;
	double centerX2 = 0;
	int tilePosition;
	double randomVar;
	double tmpX1;
	double tmpX2;
	double tmpVar;
	double distortedX1;

	double translatedX1 = 0;
	double translatedX2 = 0;
	
	for (int i = 0; i < maxEvaluations; i++) {
	    newSolution = new Solution(problem_);
	    Variable[] decisionVariables  = newSolution.getDecisionVariables();

	    tilePosition = PseudoRandom.randInt(0,9 - 1);
	
	    if (tilePosition == 0) {
		centerX1 = -sympartA - sympartC - sympartA;
		centerX2 = sympartB;
	    }
	    else if (tilePosition == 1) {
		centerX1 = 0.0;
		centerX2 = sympartB;
	    }
	    else if (tilePosition == 2) {
		centerX1 = sympartA + sympartC + sympartA;
		centerX2 = sympartB;
	    }
	    else if (tilePosition == 3) {
		centerX1 = -sympartA - sympartC - sympartA;
		centerX2 = 0.0;
	    }
	    else if (tilePosition == 4) {
		centerX1 = 0.0;
		centerX2 = 0.0;
	    }
	    else if (tilePosition == 5) {
		centerX1 = sympartA + sympartC + sympartA;
		centerX2 = 0.0;
	    }
	    if (tilePosition == 6) {
		centerX1 = -sympartA - sympartC - sympartA;
		centerX2 = -sympartB;
	    }
	    else if (tilePosition == 7) {
		centerX1 = 0.0;
		centerX2 = -sympartB;
	    }
	    else if (tilePosition == 8) {
		centerX1 = sympartA + sympartC + sympartA;
		centerX2 = -sympartB;
	    }

	    randomVar = (2 * sympartA) * PseudoRandom.randDouble() - sympartA;

	    tmpX1 = centerX1 + randomVar;
	    tmpX2 = centerX2 + 0.0;

	    if  ("SYMPART1".equals(problem_.getName())) { 
		translatedX1 = tmpX1;
		translatedX2 = tmpX2;
	    }	
	    else if  ("SYMPART2".equals(problem_.getName())) { 
		translatedX1 = tmpX1 * Math.cos(rotationRadian) - tmpX2 * Math.sin(rotationRadian);
		translatedX2 = tmpX1 * Math.sin(rotationRadian) + tmpX2 * Math.cos(rotationRadian);
	    }
	    else if  ("SYMPART3".equals(problem_.getName())) { 
		translatedX1 = tmpX1 * Math.cos(rotationRadian) - tmpX2 * Math.sin(rotationRadian);
		translatedX2 = tmpX1 * Math.sin(rotationRadian) + tmpX2 * Math.cos(rotationRadian);
       
		tmpVar = (translatedX2 - lowerLimit + sympart3EpsilonVar) / (upperLimit - lowerLimit);
		distortedX1 = translatedX1 / Math.pow(tmpVar, -1);

		translatedX1 = distortedX1;
	    }
	
	    decisionVariables[0].setValue(translatedX1);	
	    decisionVariables[1].setValue(translatedX2);	

	    problem_.evaluate(newSolution);
	    problem_.evaluateConstraints(newSolution);	
	    population.add(newSolution);
	} //for       
    
	population.printObjectivesToFile("FUN_" + problem_.getName());
	population.printVariablesToFile("VAR_" + problem_.getName());
	
	return population;
    } // execute
} 
