//  AnalysisTWOONONE.java
//
//  Author:
//      Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2018 Ryoji Tanabe
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.metaheuristics.analysis;

import jmetal.core.*;
import jmetal.util.JMException;

import jmetal.util.PseudoRandom;
import jmetal.util.wrapper.XReal;

import java.text.DecimalFormat;
import java.util.Vector;

public class AnalysisTWOONONE extends Algorithm {
    /**
     * Constructor
     * @param problem Problem to solve
     */
    public AnalysisTWOONONE(Problem problem) {
	super (problem) ;
    } // AnalysisTWOONONE

    public AnalysisTWOONONE(Problem problem, double rt_seed) {
	super(problem);	
	PseudoRandom.initializePseudoRandom(rt_seed);
    } // AnalysisTWOONONE

    /**   
     * @return a <code>SolutionSet</code> that is a set of non dominated solutions
     * as a result of the algorithm execution
     * @throws JMException 
     */
    public SolutionSet execute() throws JMException, ClassNotFoundException {
	int populationSize;
	int maxEvaluations;
	SolutionSet population;
	Solution newSolution;

	double rangePSX1 = (1.0/2.0)  * Math.sqrt(Math.sqrt(101.0) + 1.0);
	double tmpX1 = (2 * rangePSX1) * PseudoRandom.randDouble() - rangePSX1;
	double tmpX2 = tmpX1 * ((Math.sqrt(101.0) - 1.0) / 10.0);
		
	maxEvaluations = ((Integer) getInputParameter("maxEvaluations")).intValue();
	population = new SolutionSet(maxEvaluations);	

	for (int i = 0; i < maxEvaluations; i++) {
	    newSolution = new Solution(problem_);
	    Variable[] decisionVariables  = newSolution.getDecisionVariables();

	    tmpX1 = (2 * rangePSX1) * PseudoRandom.randDouble() - rangePSX1;
	    tmpX2 = tmpX1 * ((Math.sqrt(101.0) - 1.0) / 10.0);

	    decisionVariables[0].setValue(tmpX1);	
	    decisionVariables[1].setValue(tmpX2);	

	    problem_.evaluate(newSolution);
	    problem_.evaluateConstraints(newSolution);
	    population.add(newSolution);
	} //for       

	population.printObjectivesToFile("FUN_TWOONONE") ;
	population.printVariablesToFile("VAR_TWOONONE");    
   
	return population;
    } // execute
} 





