//  Analysis_main.java
//
//  Author:
//      Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2018 Ryoji Tanabe
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.metaheuristics.analysis;

import jmetal.core.Algorithm;
import jmetal.core.Problem;
import jmetal.core.SolutionSet;
import jmetal.problems.ProblemFactory;

import jmetal.problems.DT1;
import jmetal.problems.DT2;
import jmetal.problems.TWOONONE;
import jmetal.problems.SYMPART1;
import jmetal.problems.SYMPART2;
import jmetal.problems.SYMPART3;
import jmetal.problems.SSUF1;
import jmetal.problems.SSUF3;

import jmetal.util.Configuration;
import jmetal.util.JMException;

import java.io.IOException;
import java.util.HashMap;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

public class Analysis_main {
  public static Logger      logger_ ;      // Logger object
  public static FileHandler fileHandler_ ; // FileHandler object

  /**
   * @param args Command line arguments.
   * @throws JMException 
   * @throws IOException 
   * @throws SecurityException 
   */
  public static void main(String [] args) throws 
                                  JMException, 
                                  SecurityException, 
                                  IOException, 
                                  ClassNotFoundException {
    Problem   problem   ; // The problem to solve
    Algorithm algorithm ; // The algorithm to use
    
    // Logger object and file to store log messages
    logger_      = Configuration.logger_ ;
    fileHandler_ = new FileHandler("Analysis_main.log"); 
    logger_.addHandler(fileHandler_) ;

    // testFunc \in \{DT1 (Omni-test), DT2, TWO-ON-ONE, SYMPART1, SYMPART2, SYMPART3, SSUF1, SSUF3\}
    String testFunc = "SYMPART1";

    int maxFEvals = 5000;
    double rndSeed = 0;	      

    if ("DT1".equals(testFunc)) problem = new DT1("Real");
    else if ("DT2".equals(testFunc)) problem = new DT2("Real");
    else if ("TWO-ON-ONE".equals(testFunc)) problem = new TWOONONE("Real");
    else if ("SYMPART1".equals(testFunc)) problem = new SYMPART1("Real");
    else if ("SYMPART2".equals(testFunc)) problem = new SYMPART2("Real");
    else if ("SYMPART3".equals(testFunc)) problem = new SYMPART3("Real");
    else if ("SSUF1".equals(testFunc)) problem = new SSUF1("Real");
    else if ("SSUF3".equals(testFunc)) problem = new SSUF3("Real");
    else {
	System.out.println("Error ! " + testFunc + " has not been defined.");
	problem = new TWOONONE("Real");
	System.exit(1);
    }

    if ("SYMPART1".equals(testFunc) || "SYMPART2".equals(testFunc) || "SYMPART3".equals(testFunc)) {
	algorithm = new AnalysisSYMPART(problem, rndSeed);    
    }
    else if ("TWO-ON-ONE".equals(testFunc)) {
	algorithm = new AnalysisTWOONONE(problem, rndSeed);    
    }
    else if ("DT1".equals(testFunc) || "DT2".equals(testFunc)) {
	algorithm = new AnalysisDT(problem, rndSeed);    
    }
    else if ("SSUF1".equals(testFunc) || "SSUF3".equals(testFunc)) {
	algorithm = new AnalysisSSUF(problem, rndSeed);    
    }
    else {
	System.out.println("Error ! " + testFunc + " has not been defined.");
	algorithm = new AnalysisSYMPART(problem, rndSeed);
	System.exit(1);
    }
    
    // Algorithm parameters
    algorithm.setInputParameter("maxEvaluations",maxFEvals);

    //    algorithm.execute();
    SolutionSet population = algorithm.execute();
  } //main
} // Analysis_main
