//  MOEADAD.java
//
//  Author:
//      Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2018 Ryoji Tanabe
//
// NOTE:
// This program is based on MOEAD.java (the original jMetal code) implemented by Dr. Antonio J. Nebro and Dr. Juan J. Durillo.
// 
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.metaheuristics.moeadad;

import jmetal.core.*;
import jmetal.util.*;
import jmetal.util.JMException;
import jmetal.util.PseudoRandom;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.ArrayList;
import jmetal.util.wrapper.XReal;
import jmetal.util.comparators.DominanceComparator;
import java.util.Comparator;

public class MOEADAD extends Algorithm {

    private int populationSize_;
    /**
     * Stores the population
     */
    private SolutionSet population_;
    /**
     * Z vector (ideal point)
     */
    double[] z_;

    /**
     * Z vector (nadir point)
     */
    double[] nad_;


    /**
     * Lambda vectors
     */
    double[][] lambda_;

    Solution[] indArray_;
    String functionType_;
    int evaluations_;
    /**
     * Operators
     */
    Operator crossover_;
    Operator mutation_;
    
    String dataDirectory_;
    
    double penaltyTheta;

    double[] variablesUpperBounds;
    double[] variablesLowerBounds;

    int territorialNeighborhoodSize;
    double territorySizeRate;
    
    /**
     * stores a <code>Comparator</code> for dominance checking
     */
    private static final Comparator dominance_ = new DominanceComparator();
    
    /** 
     * Constructor
     * @param problem Problem to solve
     */
    public MOEADAD(Problem problem, double rndSeed) {
	super (problem) ;

	PseudoRandom.initializePseudoRandom(rndSeed);
    } // DMOEA

    public SolutionSet execute() throws JMException, ClassNotFoundException {
	int maxEvaluations;

	evaluations_ = 0;
	maxEvaluations = ((Integer) this.getInputParameter("maxEvaluations")).intValue();
	populationSize_ = ((Integer) this.getInputParameter("populationSize")).intValue();
	dataDirectory_ = this.getInputParameter("dataDirectory").toString();

	population_ = new SolutionSet(10000);
	indArray_ = new Solution[problem_.getNumberOfObjectives()];
    
	territorySizeRate = ((Double) this.getInputParameter("territorySizeRate")).doubleValue();

	functionType_  = this.getInputParameter("scalarizingFunc").toString();
	penaltyTheta = ((Double) this.getInputParameter("penaltyTheta")).doubleValue();
        
	z_ = new double[problem_.getNumberOfObjectives()];
	nad_ = new double[problem_.getNumberOfObjectives()];

	lambda_ = new double[populationSize_][problem_.getNumberOfObjectives()];

	crossover_ = operators_.get("crossover"); // default: DE crossover
	mutation_ = operators_.get("mutation"); // default: polynomial mutation

	// STEP 1. Initialization
	// STEP 1.1. Compute euclidean distances between weight vectors and find T
	initUniformWeight();

	// STEP 1.2. Initialize population
	initPopulation();

	// STEP 1.3. Initialize z_
	initIdealPoint();   
	initNadirPoint();
	population_.setNormalizedObjectiveFunctionValues(z_, nad_);

	XReal tmpInd = new XReal(population_.get(0));
	variablesUpperBounds = new double[problem_.getNumberOfVariables()];
	variablesLowerBounds = new double[problem_.getNumberOfVariables()];
    
	for (int k = 0; k < problem_.getNumberOfVariables(); k++) {
	    variablesUpperBounds[k] = tmpInd.getUpperBound(k);
	    variablesLowerBounds[k] = tmpInd.getLowerBound(k);
	}

	int r1, r2;

	// STEP 2. Update
	do {
	    // random selection
	    r1 = PseudoRandom.randInt(0, population_.size() - 1);
	    do {
		r2 = PseudoRandom.randInt(0, population_.size() - 1);
	    } while (r2 == r1);
		
	    // STEP 2.2. Reproduction
	    Solution[] parents = new Solution[2];
	    parents[0] = population_.get(r1);
	    parents[1] = population_.get(r2);

	    Solution[] offSpring = (Solution[]) crossover_.execute(parents);
	    Solution child = offSpring[0];

	    // Apply mutation
	    mutation_.execute(child);

	    // Evaluation
	    problem_.evaluate(child);             
	    evaluations_++;

	    // STEP 2.3. Repair. Not necessary

	    // STEP 2.4. Update z_
	    updateReference(child);
	    updateNadirPoint(child);
	    population_.setNormalizedObjectiveFunctionValues(z_, nad_);
	    child.setNormalizedObjectiveFunctionValues(z_, nad_);

	    // STEP 2.5. Update of solutions
	    updateProblem(child);
	} while (evaluations_ < maxEvaluations);

	Ranking tmpRanking = new Ranking(population_);
	SolutionSet reducedPopulation_ = getReducedPopulation(tmpRanking.getSubfront(0));

	reducedPopulation_.printFeasibleFUN("FUN_MOEADAD") ;	 
	reducedPopulation_.printVariablesToFile("VAR_MOEADAD") ;	 

	return population_;
    }

    SolutionSet getReducedPopulation(SolutionSet population_) throws JMException, ClassNotFoundException {
	SolutionSet reducedPopulation_ = new SolutionSet(populationSize_);
	boolean[] isSelected = new boolean[population_.size()];
	double[][] popDistMatrix = new double[population_.size()][population_.size()];
	double[] minDistVars = new double[population_.size()];

	double tmpSumVar, tmpVar;
	int maxDistIndivIndex;
	double maxDistVar;

	//	System.out.println(population_.size() + " " + populationSize_);

	if (population_.size() < populationSize_) {
	    for (int j = 0; j < population_.size(); j++) reducedPopulation_.add(population_.get(j));	    
	}
	else {
	    for (int j = 0; j < population_.size(); j++) {		   
		isSelected[j] = false;
		minDistVars[j] = 1e+30;
	    }

	    for (int j = 0; j < population_.size(); j++) {		   
		Variable[] variableX1 = population_.get(j).getDecisionVariables();

		for (int k = j; k < population_.size(); k++) {		   
		    if (j == k) {
			popDistMatrix[j][k] = 0;
		    }
		    else {
			Variable[] variableX2 = population_.get(k).getDecisionVariables();
			tmpSumVar = 0;
	    
			for (int l = 0; l < problem_.getNumberOfVariables(); l++) {
			    tmpVar = (variableX1[l].getValue() - variableX2[l].getValue()) / (variablesUpperBounds[l] - variablesLowerBounds[l]);			    
			    tmpSumVar += tmpVar * tmpVar;
			}
			popDistMatrix[j][k] = Math.sqrt(tmpSumVar);
		    }
		    popDistMatrix[k][j] = popDistMatrix[j][k];
		}		
	    }

	    int rndIndex = PseudoRandom.randInt(0, population_.size() - 1);
	    isSelected[rndIndex] = true;

	    for (int j = 0; j < population_.size(); j++) {		   
		if (minDistVars[j] > popDistMatrix[j][rndIndex] && isSelected[j] == false) minDistVars[j] = popDistMatrix[j][rndIndex];
	    }
    
	    for (int j = 0; j < populationSize_ - 1; j++) {		   
		maxDistIndivIndex = -1;
		maxDistVar = 0;

		for (int k = 0; k < population_.size(); k++) {		   
		    if (isSelected[k] == false && minDistVars[k] >= maxDistVar) {
			maxDistVar = minDistVars[k];
			maxDistIndivIndex = k;
		    }  	    
		}

		isSelected[maxDistIndivIndex] = true;
		
		for (int k = 0; k < population_.size(); k++) {		   
		    if (minDistVars[k] > popDistMatrix[k][maxDistIndivIndex] && isSelected[k] == false) minDistVars[k] = popDistMatrix[k][maxDistIndivIndex];
		}		
	    }

	    for (int j = 0; j < population_.size(); j++) {		   
		if (isSelected[j] == true) reducedPopulation_.add(population_.get(j));
	    }
	}

	return reducedPopulation_;       	
    }

    public void initNadirPoint() {
	for (int n = 0; n < problem_.getNumberOfObjectives(); n++) nad_[n] = -1.0e+30;
	
	for (int i = 0; i < populationSize_; i++) {
	    for (int n = 0; n < problem_.getNumberOfObjectives(); n++) {
		if (population_.get(i).getObjective(n) > nad_[n]) nad_[n] = population_.get(i).getObjective(n);		
	    }
	}
    }

    public void updateNadirPoint(Solution child) {
	for (int n = 0; n < problem_.getNumberOfObjectives(); n++) nad_[n] = -1.0e+30;
	
	for (int i = 0; i < populationSize_; i++) {
	    for (int n = 0; n < problem_.getNumberOfObjectives(); n++) {
		if (population_.get(i).getObjective(n) > nad_[n]) nad_[n] = population_.get(i).getObjective(n);		
	    }
	}

	for (int n = 0; n < problem_.getNumberOfObjectives(); n++) {
	    if (child.getObjective(n) > nad_[n]) nad_[n] = child.getObjective(n);		
	}	
    }

    /**
     * Initialize the weight vectors, this function only can read from the 
     * existing data file, instead of generating itself.
     * 
     */
    public void initUniformWeight() {
	String dataFileName;
	dataFileName = "M" + problem_.getNumberOfObjectives() + "_mu" + populationSize_  +  ".dat";

	try {
	    // Open the file
	    FileInputStream fis = new FileInputStream(dataDirectory_ + "/"
						      + dataFileName);
	    InputStreamReader isr = new InputStreamReader(fis);
	    BufferedReader br = new BufferedReader(isr);

	    int i = 0;
	    int j = 0;
	    String aux = br.readLine();
	    while (aux != null && i < populationSize_ ) {
		StringTokenizer st = new StringTokenizer(aux);
		j = 0;
		while (st.hasMoreTokens()) {
		    double value = (new Double(st.nextToken())).doubleValue();
		    if (value == 0) value = 1e-5;
		    lambda_[i][j] = value;

		    j++;
		}
		aux = br.readLine();
		i++;

		//				System.out.println(i);
	    }
	    br.close();
	} catch (Exception e) {
	    System.out
		.println("initUniformWeight: failed when reading for file: "
			 + dataDirectory_ + "/" + dataFileName);
	    e.printStackTrace();
	}
    } // initUniformWeight

    /**
     * 
     */
    public void initPopulation() throws JMException, ClassNotFoundException {
	for (int i = 0; i < populationSize_; i++) {
	    Solution newSolution = new Solution(problem_);
	    problem_.evaluate(newSolution);
	    newSolution.setSubProbID(i);
	    evaluations_++;
	    population_.add(newSolution) ;
	} // for
    } // initPopulation

    /**
     * 
     */
    void initIdealPoint() throws JMException, ClassNotFoundException {
	for (int i = 0; i < problem_.getNumberOfObjectives(); i++) {
	    z_[i] = 1.0e+30;
	    indArray_[i] = new Solution(problem_);
	    problem_.evaluate(indArray_[i]);
	    //      evaluations_++;
	} // for

	for (int i = 0; i < populationSize_; i++) {
	    updateReference(population_.get(i));
	} // for
    } // initIdealPoint


    /**
     * 
     * @param individual
     */
    void updateReference(Solution individual) {
	for (int n = 0; n < problem_.getNumberOfObjectives(); n++) {
	    if (individual.getObjective(n) < z_[n]) {
		z_[n] = individual.getObjective(n);

		indArray_[n] = individual;
	    }
	}

    } // updateReference


    void updateProblem(Solution child) throws JMException, ClassNotFoundException {
    	int nearestProbId = 0;
    	double minDistanceVar = 1e+30;
    	double tmpDistanceVar;
    	double minFitnessVar = 1e+30;
    	double tmpFitnessVar;

    	int tmpProbID;
    	int tmpIndvID;
    	boolean isExistsNeighborhood = false;
    	boolean isAlreadyEntered = false;
	
    	ArrayList<Integer> candidateIndivIDs = new ArrayList<Integer>();
    	ArrayList<Integer> replacedIndivIDs = new ArrayList<Integer>();
    	double fitnessChild;
    	double fitnessTarget;
	
	//	distance in the weight space
	for (int i = 0; i < populationSize_; i++) {
	    tmpDistanceVar = getPerpendicularDistance(child, lambda_[i]);
	    if (tmpDistanceVar < minDistanceVar) {
		minDistanceVar = tmpDistanceVar;
		nearestProbId = i;		
	    }
	}    	

	child.setSubProbID(nearestProbId);
	child.setReplacedOrder(-1);

	for (int i = 0; i < population_.size(); i++) population_.get(i).setReplacedOrder(-1);

	for (int i = 0; i < population_.size(); i++) {
	    tmpProbID = population_.get(i).getSubProbID();
	    if (tmpProbID == nearestProbId) candidateIndivIDs.add(i);
	}

	int[] sortedIndeces = getSortedIndeces(child);
	int replaced_count = 0;
	    
	territorialNeighborhoodSize = (int)(territorySizeRate * population_.size());

	for (int i = 0; i < candidateIndivIDs.size(); i++) {	
	    tmpIndvID = candidateIndivIDs.get(i);
	    isExistsNeighborhood = false;
		
	    if (isNeighborhood(tmpIndvID, sortedIndeces) == true) {
		isExistsNeighborhood = true;
		fitnessChild = fitnessFunction(child, lambda_[nearestProbId]);
		fitnessTarget = fitnessFunction(population_.get(tmpIndvID), lambda_[nearestProbId]);

		if (fitnessChild < fitnessTarget) {
		    population_.replace(tmpIndvID, new Solution(child));		    
		    population_.get(tmpIndvID).setReplacedOrder(replaced_count);
		    replaced_count++;
		}
	    }
	}

	if (isExistsNeighborhood == false && isAlreadyEntered == false) {
	    isAlreadyEntered = true;
	    population_.add(child);
	}
	if (replaced_count >= 2){
	    for (int targetRepOrder = 1; targetRepOrder < replaced_count; targetRepOrder++) {		   
		for (int j = 0; j < population_.size(); j++) {
		    if (population_.get(j).getReplacedOrder() == targetRepOrder) {
			population_.remove(j);		    
		    }
		}
	    }
    	}
    } // updateProblem
    
    int[] getSortedIndeces(Solution child) throws JMException, ClassNotFoundException {
	double[] distanceFromTarget = new double[population_.size()];
	int[] sortedIndeces = new int[population_.size()];

	Variable[] variablesTarget  = child.getDecisionVariables();
	double tmpSumVar;
	double tmpVar;

	for (int j = 0; j < population_.size(); j++) {
	    Variable[] variablesArchiveInds = population_.get(j).getDecisionVariables();
	    tmpSumVar = 0;
	    
	    for (int k = 0; k < problem_.getNumberOfVariables(); k++) {
		tmpVar = (variablesTarget[k].getValue() - variablesArchiveInds[k].getValue()) / (variablesUpperBounds[k] - variablesLowerBounds[k]);			    
		tmpSumVar += tmpVar * tmpVar;
	    }

	    distanceFromTarget[j] = Math.sqrt(tmpSumVar);
	}

	for (int j = 0; j < population_.size(); j++) sortedIndeces[j] = j;
	sortIndexWithQuickSort(distanceFromTarget, 0, population_.size() - 1, sortedIndeces);

	return sortedIndeces;
    }
    
    boolean isNeighborhood(int targetIndivID, int[] sortedIndeces) throws JMException, ClassNotFoundException {
	boolean isExistsNeighborhood = false;
	
	for (int j = 0; j < territorialNeighborhoodSize; j++) {
	    if (sortedIndeces[j] == targetIndivID) {
		isExistsNeighborhood = true;
		break;
	    }
	}

	return isExistsNeighborhood;
    }

    double getPerpendicularDistance(Solution individual, double[] lambda) {
	double d1, d2, nl;

	d1 = d2 = nl = 0.0;

	for (int i = 0; i < individual.getNumberOfObjectives(); i++) {
	    //	    d1 += (individual.getObjective(i) - z_[i]) * lambda[i];
	    d1 += individual.getNormalizedObjective(i) * lambda[i];

	    nl += (lambda[i] * lambda[i]);
	}
	nl = Math.sqrt(nl);
	d1 = Math.abs(d1) / nl;

	for (int i = 0; i < individual.getNumberOfObjectives(); i++) {
	    //	    d2 += ((individual.getObjective(i) - z_[i]) - d1 * (lambda[i] / nl)) * ((individual.getObjective(i) - z_[i]) - d1 * (lambda[i] / nl));
	    d2 += (individual.getNormalizedObjective(i) - d1 * (lambda[i] / nl)) * (individual.getNormalizedObjective(i) - d1 * (lambda[i] / nl));

	}
	d2 = Math.sqrt(d2);

	return d2;

    }
	
    double fitnessFunction(Solution individual, double[] lambda) {
	double fitness;
	fitness = 0.0;

	if (functionType_.equals("ws")) {
	    for (int n = 0; n < problem_.getNumberOfObjectives(); n++)  {
		if (lambda[n] == 0)  fitness += 0.000001 * individual.getNormalizedObjective(n);
		else fitness += lambda[n] * individual.getNormalizedObjective(n);
		// if (lambda[n] == 0)  fitness += 0.000001 * individual.getObjective(n);
		// else fitness += lambda[n] * individual.getObjective(n);
	    }
	} // if
	else if (functionType_.equals("tche-mul")) {
	    double maxFun = -1.0e+30;

	    for (int n = 0; n < problem_.getNumberOfObjectives(); n++) {
		//        double diff = Math.abs(individual.getObjective(n) - z_[n]);
		double diff = Math.abs(individual.getNormalizedObjective(n));

		double feval;
		if (lambda[n] == 0) {
		    feval = 0.000001 * diff;
		    //          feval = 0.0001 * diff;
		} else {
		    feval = diff * lambda[n];
		}
		if (feval > maxFun) {
		    maxFun = feval;
		}
	    } // for

	    fitness = maxFun;
	} // if
	else if (functionType_.equals("tche-div")) {
	    double maxFun = -1.0e+30;

	    for (int n = 0; n < problem_.getNumberOfObjectives(); n++) {
		//        double diff = Math.abs(individual.getObjective(n) - z_[n]);
		double diff = Math.abs(individual.getNormalizedObjective(n));

		double feval;
		if (lambda[n] == 0) {
		    feval = diff / 0.000001;
		} else {
		    feval = diff / lambda[n];
		}
		if (feval > maxFun) {
		    maxFun = feval;
		}
	    } // for

	    fitness = maxFun;
	} // if
	else if (functionType_.equals("pbi")) {
	    double theta; // penalty parameter
	    theta = penaltyTheta; //5.0;

	    // normalize the weight vector (line segment)
	    double nd = norm_vector(lambda);
	    for (int i = 0; i < problem_.getNumberOfObjectives(); i++)
		lambda[i] = lambda[i] / nd;

	    double[] realA = new double[problem_.getNumberOfObjectives()];
	    double[] realB = new double[problem_.getNumberOfObjectives()];

	    // difference between current point and reference point
	    for (int n = 0; n < problem_.getNumberOfObjectives(); n++) {
		//	    realA[n] = (individual.getObjective(n) - z_[n]);
		realA[n] = (individual.getNormalizedObjective(n));
	    }

	    // distance along the line segment
	    double d1 = Math.abs(innerproduct(realA, lambda));

	    // distance to the line segment
	    for (int n = 0; n < problem_.getNumberOfObjectives(); n++) {
		//	    realB[n] = (individual.getObjective(n) - (z_[n] + d1 * lambda[n]));
		realB[n] = (individual.getNormalizedObjective(n) - (d1 * lambda[n]));
	    }

	    double d2 = norm_vector(realB);

	    fitness = d1 + theta * d2;
	} 
	else {
	    System.out.println("MOEADAD.fitnessFunction: unknown type " + functionType_);
	    System.exit(-1);
	}
	return fitness;
    } // fitnessEvaluation


    /**
     * Calculate the norm of the vector
     * 
     * @param z
     * @return
     */
    public double norm_vector(double[] z) {
	double sum = 0;

	for (int i = 0; i < problem_.getNumberOfObjectives(); i++)
	    sum += z[i] * z[i];

	return Math.sqrt(sum);
    }

    /**
     * Calculate the dot product of two vectors
     * 
     * @param vec1
     * @param vec2
     * @return
     */
    public double innerproduct(double[] vec1, double[] vec2) {
	double sum = 0;

	for (int i = 0; i < vec1.length; i++)
	    sum += vec1[i] * vec2[i];

	return sum;
    }


    void sortIndexWithQuickSort(double[] array, int first, int last, int[] index) {
	double x = array[(first + last) / 2];
	int i = first;
	int j = last;
	double temp_var = 0;
	int temp_num = 0;

	while (true) {
	    while (array[i] < x) i++;
	    while (x < array[j]) j--;      
	    if (i >= j) break;

	    temp_var = array[i];
	    array[i] = array[j];
	    array[j] = temp_var;

	    temp_num = index[i];
	    index[i] = index[j];
	    index[j] = temp_num;

	    i++;
	    j--;
	}

	if (first < (i -1)) sortIndexWithQuickSort(array, first, i - 1, index);
	if ((j + 1) < last) sortIndexWithQuickSort(array, j + 1, last, index);
    }
} // MOEADAD

