//  MOEAD_main.java
//
//  Author:
//       Antonio J. Nebro <antonio@lcc.uma.es>
//       Juan J. Durillo <durillo@lcc.uma.es>
//
//  Copyright (c) 2011 Antonio J. Nebro, Juan J. Durillo
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.metaheuristics.moeadad;

import jmetal.core.Algorithm;
import jmetal.core.Operator;
import jmetal.core.Problem;
import jmetal.core.SolutionSet;
import jmetal.operators.crossover.CrossoverFactory;
import jmetal.operators.mutation.MutationFactory;

import jmetal.problems.DT1;
import jmetal.problems.DT2;
import jmetal.problems.TWOONONE;
import jmetal.problems.SYMPART1;
import jmetal.problems.SYMPART2;
import jmetal.problems.SYMPART3;
import jmetal.problems.SSUF1;
import jmetal.problems.SSUF3;

import jmetal.problems.ProblemFactory;
import jmetal.qualityIndicator.QualityIndicator;
import jmetal.util.Configuration;
import jmetal.util.JMException;

import java.io.IOException;
import java.util.HashMap;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
/**
 * This class executes the algorithm described in:
 *   H. Li and Q. Zhang, 
 *   "Multiobjective Optimization Problems with Complicated Pareto Sets,  MOEA/D 
 *   and NSGA-II". IEEE Trans on Evolutionary Computation, vol. 12,  no 2,  
 *   pp 284-302, April/2009.  
 */
public class MOEAD_main {
    public static Logger      logger_ ;      // Logger object
    public static FileHandler fileHandler_ ; // FileHandler object

    /**
     * @param args Command line arguments. The first (optional) argument specifies 
     *      the problem to solve.
     * @throws JMException 
     * @throws IOException 
     * @throws SecurityException 
     * Usage: three options
     *      - jmetal.metaheuristics.moead.MOEAD_main
     *      - jmetal.metaheuristics.moead.MOEAD_main problemName
     *      - jmetal.metaheuristics.moead.MOEAD_main problemName ParetoFrontFile
     * @throws ClassNotFoundException 
 
     */
    public static void main(String [] args) throws JMException, SecurityException, IOException, ClassNotFoundException {
	Problem   problem   ;         // The problem to solve
	Algorithm algorithm ;         // The algorithm to use
	Operator  crossover ;         // Crossover operator
	Operator  mutation  ;         // Mutation operator
     
	QualityIndicator indicators ; // Object to get quality indicators

	HashMap  parameters ; // Operator parameters

	// Logger object and file to store log messages
	logger_      = Configuration.logger_ ;
	fileHandler_ = new FileHandler("MOEAD.log"); 
	logger_.addHandler(fileHandler_) ;
    
	// testFunc \in \{DT1 (Omni-test), DT2, TWO-ON-ONE, SYMPART1, SYMPART2, SYMPART3, SSUF1, SSUF3\}
	String testFunc = "SYMPART1";
	int maxEvaluations = 30000;

	int populationSize = 100;		      
	double territorySizeRate = 0.1;
	String scalarizingFunc = "tche-mul";
	double penaltyTheta = 0;

	double rndSeed = 0.01;	      

	if ("DT1".equals(testFunc)) problem = new DT1("Real");
	else if ("DT2".equals(testFunc)) problem = new DT2("Real");
	else if ("TWO-ON-ONE".equals(testFunc)) problem = new TWOONONE("Real");
	else if ("SYMPART1".equals(testFunc)) problem = new SYMPART1("Real");
	else if ("SYMPART2".equals(testFunc)) problem = new SYMPART2("Real");
	else if ("SYMPART3".equals(testFunc)) problem = new SYMPART3("Real");
	else if ("SSUF1".equals(testFunc)) problem = new SSUF1("Real");
	else if ("SSUF3".equals(testFunc)) problem = new SSUF3("Real");
	else {
	    System.out.println("Error! " + testFunc + " is not defined.");
	    problem = new SSUF3("Real");
	    System.exit(1);
	}

	algorithm = new MOEADAD(problem, rndSeed);
  
	algorithm.setInputParameter("maxEvaluations", maxEvaluations);
	algorithm.setInputParameter("populationSize", populationSize);
	algorithm.setInputParameter("territorySizeRate", territorySizeRate);   
	algorithm.setInputParameter("scalarizingFunc",scalarizingFunc);
	algorithm.setInputParameter("penaltyTheta",penaltyTheta);
    
	algorithm.setInputParameter("dataDirectory", "sld_weight");    
    
	parameters = new HashMap() ;
	parameters.put("probability", 1.0) ;
	parameters.put("distributionIndex", 20.0) ;
	crossover = CrossoverFactory.getCrossoverOperator("SBXCrossover", parameters);                 

	// Mutation operator
	parameters = new HashMap() ;
	parameters.put("probability", 1.0/problem.getNumberOfVariables()) ;
	parameters.put("distributionIndex", 20.0) ;
	mutation = MutationFactory.getMutationOperator("PolynomialMutation", parameters);                    
    
	algorithm.addOperator("crossover",crossover);
	algorithm.addOperator("mutation",mutation);
    
	// Execute the Algorithm
	SolutionSet population = algorithm.execute();           
    } //main
} // MOEAD_main
