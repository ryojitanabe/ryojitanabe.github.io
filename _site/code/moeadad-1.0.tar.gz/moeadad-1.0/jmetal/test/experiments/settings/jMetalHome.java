package experiments.settings;

/**
 * Created by antelverde on 09/12/13.
 */
public class jMetalHome {
  public static String jMetalHomeConfDir="/Users/antelverde/Softw/jMetal/jMetalBB/jmetalbb/conf" ;
}
