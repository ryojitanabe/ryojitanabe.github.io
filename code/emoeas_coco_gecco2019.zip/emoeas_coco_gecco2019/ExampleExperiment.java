//  ExampleExperiment.java
//
//  Author:
//       Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
// This file is based on the original "ExampleExperiment.java" downloaded from https://github.com/numbbo/coco
// Souce codes of NSGA-II, SPEA2, IBEA, and SMS-EMOA were derived from jMetal 4.5 (http://jmetal.sourceforge.net/)
//

import jmetal.core.Algorithm;
import jmetal.core.Operator;
import jmetal.core.Problem;
import jmetal.core.SolutionSet;
import jmetal.operators.crossover.CrossoverFactory;
import jmetal.operators.mutation.MutationFactory;
import jmetal.operators.selection.SelectionFactory;
import jmetal.operators.selection.BinaryTournament;

import jmetal.problems.ProblemFactory;
import jmetal.problems.BiobjBBOB;

import jmetal.core.*;
import java.text.DecimalFormat;
import java.io.IOException;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

import jmetal.util.Distance;
import jmetal.util.JMException;
import jmetal.util.Ranking;
import java.util.Comparator;
import jmetal.util.comparators.CrowdingComparator;
import jmetal.util.comparators.CrowdingDistanceComparator;
import jmetal.util.comparators.DominanceComparator;
import jmetal.util.comparators.FitnessComparator;
import jmetal.qualityIndicator.fastHypervolume.FastHypervolume;
import jmetal.util.Spea2Fitness;

import jmetal.util.PseudoRandom;
import jmetal.util.wrapper.XReal;
import java.util.Vector;
import jmetal.util.Configuration;
import jmetal.util.JMException;
import java.util.HashMap;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.Random;

/**
 * An example of benchmarking random search on a COCO suite. 
 *
 * Set the parameter BUDGET_MULTIPLIER to suit your needs.
 */
public class ExampleExperiment {
    private static Comparator dominance_;
  
    public static String alg = "";
    public static String rankingMethod = "";    
    public static String outDirName = "";
    public static int populationSize = 0;

    public static double popSizeRate = 0;	   
    public static double numChildrenRate = 0; 
    public static String crossOperatorName = "";
    public static String environmetalSelection = "";

    // Random seeds for the jMetal algorithms and the COCO software are different (jmetalSeed vs. RANDOM_SEED).
    public static double jmetalSeed = 0;

    // for IBEA
    private static List<List<Double>> indicatorValues_;
    private static double maxIndicatorValue_;
    
    /**
     * The maximal budget for evaluations done by an optimization algorithm equals 
     * dimension * BUDGET_MULTIPLIER.
     * Increase the budget multiplier value gradually to see how it affects the runtime.
     */
    //	public static final int BUDGET_MULTIPLIER = 10000;
    public static int budgetMultiplier = 0;
    
    /**
     * The maximal number of independent restarts allowed for an algorithm that restarts itself. 
     */
    public static final int INDEPENDENT_RESTARTS = 10000;
	
    /**
     * The random seed. Change if needed.
     */
    public static final long RANDOM_SEED = 0xdeadbeef;

    /**
     * The problem to be optimized (needed in order to simplify the interface between the optimization
     * algorithm and the COCO platform).
     */
    public static ProblemCOCO PROBLEM;
	
    /**
     * Interface for function evaluation.
     */
    public interface Function {
	double[] evaluate(double[] x);
	double[] evaluateConstraint(double[] x);
    }

    /**
     * Evaluate the static PROBLEM.
     */
    public static final Function evaluateFunction = new Function() {
	    public double[] evaluate(double[] x) {
    		return PROBLEM.evaluateFunction(x);
	    }
	    public double[] evaluateConstraint(double[] x) {
		return PROBLEM.evaluateConstraint(x);
	    }
	};

    /**
     * The main method initializes the random number generator and calls the example experiment on the
     * bi-objective suite.
     */
    public static void main(String[] args) {
	// For all experiments, the random seed for jMetal is fixed.
	jmetalSeed = 0.1;

	// One of "generalEMOA", "Orig-NSGA-II", "Orig-SMS-EMOA", "Orig-IBEA", and "Orig-SPEA2"
	// When Orig-* is selected, parameters for "generalEMOA" are ignored
	alg = "generalEMOA";
	// One of "NSGA-II", "SMS-EMOA", "IBEA", and "SPEA2"
	rankingMethod = "NSGA-II";
	// One of "BA", "BF", and "BC"
	environmetalSelection = "BF";
	// One of "SBX", "SPX", "REX", "PCX", and "BLX"
	crossOperatorName = "SPX";

	budgetMultiplier = 10000;
	popSizeRate = 100;
	numChildrenRate = 10;
	outDirName = "";

	if (alg.equals("generalEMOA")) {
	    outDirName = environmetalSelection + "-" + crossOperatorName + "-" + rankingMethod + "-mu" + popSizeRate + "-lambda" + numChildrenRate;
	}
	else {
	    outDirName = alg + "-mu" + popSizeRate;
	}
		    
	// for (int i = 0; i < args.length; i++) {
	//     if ("-alg".equals(args[i])) {
	// 	alg = args[++i];
	//     }
	//     else if ("-rankingMethod".equals(args[i])) {
	// 	rankingMethod = args[++i];
	//     }
	//     else if ("-out_dir_name".equals(args[i])) {
	// 	outDirName = args[++i];
	//     } 
	//     else if ("-budget_multiplier".equals(args[i])) {
	// 	budgetMultiplier = Integer.parseInt(args[++i]);
	//     } 
	//     else if ("-pop_size".equals(args[i])) {
	// 	populationSize = Integer.parseInt(args[++i]);
	//     }	    
	//     else if ("-pop_size_rate".equals(args[i])) {
	// 	popSizeRate = Double.parseDouble(args[++i]);
	//     } 
	//     else if ("-num_children_rate".equals(args[i])) {
	// 	numChildrenRate = Double.parseDouble(args[++i]);
	//     } 
	//     else if ("-cross_operator".equals(args[i])) {
	// 	crossOperatorName = args[++i];
	//     }
	//     else if ("-environmetal_selection".equals(args[i])) {
	// 	environmetalSelection = args[++i];
	//     }	    
	//     else {
	// 	System.err.println("Error !! " + args[i] + " is an unnown argument");
	// 	System.exit(-1);
	//     }
	///    }
	
    Random randomGenerator = new Random(RANDOM_SEED);

    /* Change the log level to "warning" to get less output */
    CocoJNI.cocoSetLogLevel("info");

    System.out.println("Running the example experiment... (might take time, be patient)");
    System.out.flush();
		     
    /* Start the actual experiments on a test suite and use a matching logger, for
     * example one of the following:
     *
     *   bbob                 24 unconstrained noiseless single-objective functions
     *   bbob-biobj           55 unconstrained noiseless bi-objective functions
     *   bbob-biobj-ext       92 unconstrained noiseless bi-objective functions
     *   bbob-largescale      24 unconstrained noiseless single-objective functions in large dimension
     *   bbob-constrained     48 constrained noiseless single-objective functions
     *
     * Adapt to your need. Note that the experiment is run according
     * to the settings, defined in exampleExperiment(...) below.
     */
    //		exampleExperiment("bbob", "bbob", randomGenerator);
    exampleExperiment("bbob-biobj", "bbob-biobj", randomGenerator);

    System.out.println("Done!");
    System.out.flush();

    return;
}
	
/**
 * A simple example of benchmarking random search on a given suite with default instances
 * that can serve also as a timing experiment.
 *
 * @param suiteName Name of the suite (e.g. "bbob", "bbob-biobj", or "bbob-constrained").
 * @param observerName Name of the observer matching with the chosen suite (e.g. "bbob-biobj" 
 * when using the "bbob-biobj-ext" suite).
 * @param randomGenerator The random number generator.
 */
public static void exampleExperiment(String suiteName, String observerName, Random randomGenerator) {
    try {

	/* Set some options for the observer. See documentation for other options. */
	final String observerOptions = 
	    "result_folder: " + outDirName + "_on_" + suiteName + " " 
	    + "algorithm_name: " + outDirName + " "
	    + "algorithm_info: \"A simple random search algorithm\"";

	/* Initialize the suite and observer.
	 * For more details on how to change the default options, see
	 * http://numbbo.github.io/coco-doc/C/#suite-parameters and
	 * http://numbbo.github.io/coco-doc/C/#observer-parameters. */
	Suite suite = new Suite(suiteName, "", "");
	Observer observer = new Observer(observerName, observerOptions);
	Benchmark benchmark = new Benchmark(suite, observer);

	/* Initialize timing */
	Timing timing = new Timing();

	// initialize a random seed for algorithms in the jMetal framework
	PseudoRandom.initializePseudoRandom(jmetalSeed);	
			
	/* Iterate over all problems in thze suite */
	while ((PROBLEM = benchmark.getNextProblem()) != null) {
	    int dimension = PROBLEM.getDimension();
	    String problemInstanceName = PROBLEM.getId();
	
	    /* Run the algorithm at least once */
	    // for (int run = 1; run <= 1 + INDEPENDENT_RESTARTS; run++) {

	    long evaluationsDone = PROBLEM.getEvaluations() + PROBLEM.getEvaluationsConstraints();
	    long evaluationsRemaining = (long) (dimension * budgetMultiplier) - evaluationsDone;

	    /* Break the loop if the target was hit or there are no more remaining evaluations */
	    if (PROBLEM.isFinalTargetHit() || (evaluationsRemaining <= 0))
		break;

	    if (alg.equals("generalEMOA")) {			
		runEMOA(evaluateFunction, dimension,
			PROBLEM.getNumberOfObjectives(),
			PROBLEM.getNumberOfConstraints(),
			PROBLEM.getSmallestValuesOfInterest(),
			PROBLEM.getLargestValuesOfInterest(),
			evaluationsRemaining,
			randomGenerator,
			problemInstanceName
			);
	    }
	    else if (alg.equals("Orig-NSGA-II")) {			
		runOriginalNSGAII(evaluateFunction, dimension,
				  PROBLEM.getNumberOfObjectives(),
				  PROBLEM.getNumberOfConstraints(),
				  PROBLEM.getSmallestValuesOfInterest(),
				  PROBLEM.getLargestValuesOfInterest(),
				  evaluationsRemaining,
				  randomGenerator,
				  problemInstanceName
				  );
	    }
	    else if (alg.equals("Orig-SMS-EMOA")) {			
		runOriginalSMSEMOA(evaluateFunction, dimension,
				   PROBLEM.getNumberOfObjectives(),
				   PROBLEM.getNumberOfConstraints(),
				   PROBLEM.getSmallestValuesOfInterest(),
				   PROBLEM.getLargestValuesOfInterest(),
				   evaluationsRemaining,
				   randomGenerator,
				   problemInstanceName
				   );
	    }
	    else if (alg.equals("Orig-IBEA")) {			
		runOriginalIBEA(evaluateFunction, dimension,
				PROBLEM.getNumberOfObjectives(),
				PROBLEM.getNumberOfConstraints(),
				PROBLEM.getSmallestValuesOfInterest(),
				PROBLEM.getLargestValuesOfInterest(),
				evaluationsRemaining,
				randomGenerator,
				problemInstanceName
				);
	    }		
	    else if (alg.equals("Orig-SPEA2")) {			
		runOriginalSPEA2(evaluateFunction, dimension,
				 PROBLEM.getNumberOfObjectives(),
				 PROBLEM.getNumberOfConstraints(),
				 PROBLEM.getSmallestValuesOfInterest(),
				 PROBLEM.getLargestValuesOfInterest(),
				 evaluationsRemaining,
				 randomGenerator,
				 problemInstanceName
				 );
	    }
	    else {
		System.out.println("Error! " + alg + "is not defined");
		System.exit(-1);
	    }		
					
	    /* Break the loop if the algorithm perforNSGAIImed no evaluations or an unexpected thing happened */
	    if (PROBLEM.getEvaluations() == evaluationsDone) {
		System.out.println("WARNING: Budget has not been exhausted (" + evaluationsDone + "/"
				   + dimension * budgetMultiplier + " evaluations done)!\n");
		break;
	    } else if (PROBLEM.getEvaluations() < evaluationsDone)
		System.out.println("ERROR: Something unexpected happened - function evaluations were decreased!");
	    // }

	    /* Keep track of time */
	    timing.timeProblem(PROBLEM);
	}

	/* Output the timing data */
	timing.output();

	benchmark.finalizeBenchmark();

    } catch (Exception e) {
	System.err.println(e.toString());
    }
}

/** 
 * A simple random search algorithm that can be used for single- as well as multi-objective 
 * optimization.
 */
public static void myRandomSearch(Function f, 
				  int dimension, 
				  int numberOfObjectives,
				  int numberOfConstraints,
				  double[] lowerBounds,
				  double[] upperBounds, 
				  long maxBudget, 
				  Random randomGenerator) {

    double[] x = new double[dimension];
    double[] y = new double[numberOfObjectives];
    double[] z = new double[numberOfConstraints];
    double range;
		
    for (int i = 0; i < maxBudget; i++) {
			
	/* Construct x as a random point between the lower and upper bounds */
	for (int j = 0; j < dimension; j++) {
	    range = upperBounds[j] - lowerBounds[j];
	    x[j] = lowerBounds[j] + randomGenerator.nextDouble() * range;
	}

	/* Call the evaluate function to evaluate x on the current problem (this is where all the COCO logging
	 * is performed) */
	if (numberOfConstraints > 0)
	    z = f.evaluateConstraint(x);
	y = f.evaluate(x);
    }
		
}

public static void evaluateBiojectiveValues(Function f, int dimension, Solution solution) throws JMException, ClassNotFoundException {
    Variable[] decisionVariables  = solution.getDecisionVariables();
    double[] x = new double[dimension];
    double[] y = new double[2];

    for (int i = 0; i < dimension; i++) x[i] = decisionVariables[i].getValue();	
    y = f.evaluate(x);
    solution.setObjective(0, y[0]);	
    solution.setObjective(1, y[1]);	
}
    
/** 
 *  A general EMOA framework, which is based on the jMetal implementation of NSGA-II. In the environmental selection, individuals are ranked based on one of NSGA-II, SPEA2, IBEA, and SMS-EMOA.
 */
public static void runEMOA(Function f, int dimension, int numberOfObjectives, int numberOfConstraints, double[] lowerBounds, double[] upperBounds, long maxBudget, Random randomGenerator, String problemInstanceName) throws JMException, ClassNotFoundException {
    // for SMS-EMOA
    double offset = 100.0;
    FastHypervolume fastHypervolume = new FastHypervolume(offset);
	
    // initialize problem parameters
    Problem problem = new BiobjBBOB(dimension, lowerBounds, upperBounds);
	
    // initialize control parameters for NSGA-II
    Operator mutationOperator;
    Operator crossoverOperator;
    Operator selectionOperator;
    Distance distance = new Distance();	    
    HashMap parameters;

    int numParents;
    int numChildren;
    int totalNumChildren;

    populationSize = (int)Math.floor(popSizeRate * Math.log(dimension));
       
    if (crossOperatorName.equals("SPX") || crossOperatorName.equals("REX")) {			
	numParents = dimension + 1;
	numChildren = (int)Math.floor((dimension * numChildrenRate));
	if (environmetalSelection.equals("BC") && numChildren < numParents) numChildren = numParents;	 
	// if (environmetalSelection.equals("BA") && numChildren <= 0) numChildren = 1;	 
    }
    else if (crossOperatorName.equals("PCX")) {			
	numParents = dimension + 1;
	numChildren = (int)Math.floor((dimension * numChildrenRate));
	if (environmetalSelection.equals("BC") && numChildren < numParents) numChildren = numParents;	 
    }
    else {
	numParents = 2;
	numChildren = (int)Math.floor((dimension * numChildrenRate));
    }
       
    if (crossOperatorName.equals("SBX")) {			
	parameters = new HashMap();
	parameters.put("probability", 1.0);
	parameters.put("distributionIndex", 20.0);
	crossoverOperator = CrossoverFactory.getCrossoverOperator("SBXCrossover", parameters);               
    }
    else if (crossOperatorName.equals("BLX")) {
	parameters = new HashMap();
	parameters.put("probability", 1.0);
	parameters.put("alpha", 0.5);
	crossoverOperator = CrossoverFactory.getCrossoverOperator("BLXAlphaCrossover", parameters);	    
    }
    else if (crossOperatorName.equals("SPX")) {
	parameters = new HashMap() ;
	parameters.put("numParents", numParents);
	parameters.put("numChildren", numChildren);
	crossoverOperator = CrossoverFactory.getCrossoverOperator("SPXCrossover", parameters);
    }
    else if (crossOperatorName.equals("REX")) {
	parameters = new HashMap() ;
	parameters.put("numParents", numParents);
	parameters.put("numChildren", numChildren);
	crossoverOperator = CrossoverFactory.getCrossoverOperator("REXCrossover", parameters);
    }
    else if (crossOperatorName.equals("PCX")) {
	parameters = new HashMap() ;
	parameters.put("numParents", numParents);
	parameters.put("numChildren", numChildren);
	crossoverOperator = CrossoverFactory.getCrossoverOperator("PCXCrossover", parameters);
    }	
    else {
	System.out.println("Error! " + crossOperatorName + "is not defined");
	parameters = new HashMap() ;
	crossoverOperator = CrossoverFactory.getCrossoverOperator("SBXCrossover", parameters);                        
	System.exit(1);
    }
	
    parameters = new HashMap();
    parameters.put("probability", 1.0/problem.getNumberOfVariables());
    parameters.put("distributionIndex", 20.0);
    mutationOperator = MutationFactory.getMutationOperator("PolynomialMutation", parameters);                    

    parameters = null ;
    selectionOperator = SelectionFactory.getSelectionOperator("BinaryTournament2", parameters);
       
    int evaluations = 0;
    SolutionSet population;
    SolutionSet offspringPopulation;
    SolutionSet union;

    //Initialize the variables
    population = new SolutionSet(populationSize);

    // Create the initial solutionSet
    Solution newSolution;
	
    for (int i = 0; i < populationSize; i++) {
	newSolution = new Solution(problem);
	evaluateBiojectiveValues(f, dimension, newSolution);
	evaluations++;
	population.add(newSolution);
    }

    int[] shuffledIndices = new int[population.size()];
    for (int i = 0; i < population.size(); i++) shuffledIndices[i] = i;

    while (evaluations < maxBudget) {
	offspringPopulation = new SolutionSet(numChildren);	    

	// Initialize two makers
	for (int i = 0; i < population.size(); i++) {
	    population.get(i).setParentMaker(false);
	    population.get(i).setChildMaker(false);
	}

	if (crossOperatorName.equals("SBX")) {
	    Solution[] parents = new Solution[2];
	    int r1, r2;
	    // random selection
	    r1 = PseudoRandom.randInt(0, population.size() - 1);
	    do {
		r2 = PseudoRandom.randInt(0, population.size() - 1);
	    } while (r2 == r1);
		
	    parents[0] = population.get(r1);
	    parents[1] = population.get(r2);
	    population.get(r1).setParentMaker(true);
	    population.get(r2).setParentMaker(true);
		
	    for (int j = 0; j < numChildren/2; j++) {
		Solution[] offSpring = (Solution[]) crossoverOperator.execute(parents);
		mutationOperator.execute(offSpring[0]);
		mutationOperator.execute(offSpring[1]);		    
		evaluateBiojectiveValues(f, dimension, offSpring[0]);
		evaluateBiojectiveValues(f, dimension, offSpring[1]);		    
		offSpring[0].setChildMaker(true);
		offSpring[0].setParentMaker(false);
		offSpring[1].setChildMaker(true);
		offSpring[1].setParentMaker(false);
		offspringPopulation.add(offSpring[0]);
		offspringPopulation.add(offSpring[1]);
		evaluations += 2;	  
	    }			       
	}	    
	else if (crossOperatorName.equals("BLX")) {
	    Solution[] parents = new Solution[2];
	    int r1, r2;
	    // random selection
	    r1 = PseudoRandom.randInt(0, population.size() - 1);
	    do {
		r2 = PseudoRandom.randInt(0, population.size() - 1);
	    } while (r2 == r1);
		
	    parents[0] = population.get(r1);
	    parents[1] = population.get(r2);
	    population.get(r1).setParentMaker(true);
	    population.get(r2).setParentMaker(true);
		
	    for (int j = 0; j < numChildren/2; j++) {
		Solution[] offSpring = (Solution[]) crossoverOperator.execute(parents);
		// mutationOperator.execute(offSpring[0]);
		// mutationOperator.execute(offSpring[1]);		    
		evaluateBiojectiveValues(f, dimension, offSpring[0]);
		evaluateBiojectiveValues(f, dimension, offSpring[1]);		    
		offSpring[0].setChildMaker(true);
		offSpring[0].setParentMaker(false);
		offSpring[1].setChildMaker(true);
		offSpring[1].setParentMaker(false);
		offspringPopulation.add(offSpring[0]);
		offspringPopulation.add(offSpring[1]);
		evaluations += 2;	  
	    }			       
	}
	else if (crossOperatorName.equals("SPX") || crossOperatorName.equals("REX") || crossOperatorName.equals("PCX")) {
	    Solution[] parents = new Solution[numParents];

	    shuffleArray(shuffledIndices, population.size());
	    for (int j = 0; j < numParents; j++) {
		parents[j] = population.get(shuffledIndices[j]);
		population.get(shuffledIndices[j]).setParentMaker(true);
	    }
	       
	    Solution[] offSpring = (Solution[]) crossoverOperator.execute(new Object[]{parents});
				
	    for (int j = 0; j < numChildren; j++) {
		evaluateBiojectiveValues(f, dimension, offSpring[j]);
		offSpring[j].setChildMaker(true);
		offSpring[j].setParentMaker(false);
		offspringPopulation.add(offSpring[j]);
		evaluations += 1;	  
	    }
	}
	else {
	    System.out.println("Error! " + crossOperatorName + " is not defined");
	    System.exit(-1);
	}
	    
	// This is for the environmental selection in BC. Parents are removed from the population without any comparisons. Adios elitism!
	if (environmetalSelection.equals("BC")) {
	    int counter1 = 0;
	    int counter2 = 0;

	    while (counter1 < numParents) {
		if (population.get(counter2).isParent() == true) {
		    population.remove(counter2);		    
		    counter1++;
		}
		else {
		    counter2++;
		}
	    }
	}

	// This is for the environmental selection in BF. Parents are labeled as children for the following selection
	if (environmetalSelection.equals("BF")) {
	    for (int j = 0; j < numParents; j++) {
		population.get(shuffledIndices[j]).setChildMaker(true);
	    }
	}
	    	    
	union = ((SolutionSet) population).union(offspringPopulation);	    

	// All individual in "union" are labeled as childlen in BA
	if (environmetalSelection.equals("BA")) {
	    for (int i = 0; i < union.size(); i++) {
		union.get(i).setChildMaker(true);
	    }		
	}

	if (rankingMethod.equals("SMS-EMOA")) {			
	    // ensure crowding distance values are up to date
	    // (may be important for parent selection)
	    for (int i = 0; i < union.size(); i++) union.get(i).setCrowdingDistance(0.0);
	}
	    
	Ranking ranking = new Ranking(union);
	int remain = numParents;

	// While "numParents" individuals are updated in BF and BC, all "populationSize" individuals are updated in BA
	if (environmetalSelection.equals("BA")) {
	    remain = populationSize;
	    population.clear();			
	}
	else if (environmetalSelection.equals("BF")) {
	    // Remove only parents from "population". Note that "union" contains the parents removed from "population" at this time
	    int counter1 = 0;
	    int counter2 = 0;

	    while (counter1 < numParents) {
		if (population.get(counter2).isParent() == true) {
		    population.remove(counter2);		    
		    counter1++;
		}
		else {
		    counter2++;
		}
	    }
	}	    

	if (rankingMethod.equals("IBEA") || rankingMethod.equals("SPEA2")) {
	    if (rankingMethod.equals("IBEA")) {
		calculateFitnessEpsilon(union, problem.getNumberOfObjectives());
		union.sort(new FitnessComparator());
	    }
	    else if (rankingMethod.equals("SPEA2")) {
		Spea2Fitness spea = new Spea2Fitness(union);
		spea.fitnessAssign();		    
		union.sort(new FitnessComparator());
	    }
		
	    int k = 0;
	    while (population.size() < populationSize) {
		if (union.get(k).isChild() == true) population.add(union.get(k));		    
		k++;
	    }
	}
	else {
	    int index = 0;
	    SolutionSet front = null;
	    front = ranking.getSubfront(index);	    

	    // This implementation is not efficient for BA
	    while (remain > 0) {
		if (rankingMethod.equals("NSGA-II")) {
		    distance.crowdingDistanceAssignment(front, problem.getNumberOfObjectives());
		    front.sort(new CrowdingComparator());
		}
		else if (rankingMethod.equals("SMS-EMOA")) {
		    fastHypervolume.computeHVContributions(front);
		    front.sort(new CrowdingDistanceComparator());
		}
		else {
		    System.out.println("Error! " + alg + " is not defined");
		    System.exit(-1);		    
		}
		
		for (int k = 0; k < front.size(); k++) {
		    if (front.get(k).isChild() == true) {
			population.add(front.get(k));
			remain--;
		    }

		    if (remain <= 0) break;
		}

		index++;
		if (remain > 0) {
		    front = ranking.getSubfront(index);
		}		
	    }
	}	    
    }

    // Output objective vectors of nondominated solutions in the final population
    // Ranking ranking = new Ranking(population);
    // ranking.getSubfront(0).printFeasibleFUN("finalobj_" + problemInstanceName + ".dat") ;
}
    

public static void calculateFitnessEpsilon(SolutionSet solutionSet, int numberOfObjectives) {
    // Obtains the lower and upper bounds of the population
    double [] maximumValues = new double[numberOfObjectives];
    double [] minimumValues = new double[numberOfObjectives];

    for (int i = 0; i < numberOfObjectives;i++) {
	maximumValues[i] = - Double.MAX_VALUE; // i.e., the minus maxium value
	minimumValues[i] =   Double.MAX_VALUE; // i.e., the maximum value
    }

    for (int pos = 0; pos < solutionSet.size(); pos++) {
	for (int obj = 0; obj < numberOfObjectives; obj++) {
	    double value = solutionSet.get(pos).getObjective(obj);
	    if (value > maximumValues[obj])
		maximumValues[obj] = value;
	    if (value < minimumValues[obj])
		minimumValues[obj] = value;
	}
    }

    computeEpsilonValues(solutionSet, maximumValues, minimumValues, numberOfObjectives);

    for (int pos =0; pos < solutionSet.size(); pos++) {
	fitness(solutionSet,pos);
    }
}

/**
 * Calculate the fitness for the individual at position pos
 */
public static void fitness(SolutionSet solutionSet, int pos) {
    double fitness = 0.0;
    double kappa   = 0.05;
    
    for (int i = 0; i < solutionSet.size(); i++) {
	if (i!=pos) {
	    fitness += Math.exp((-1 * indicatorValues_.get(i).get(pos)/maxIndicatorValue_) / kappa);
	}
    }
    solutionSet.get(pos).setFitness(fitness);
}

/**
 * This structure store the indicator values of each pair of elements
 */

public static void computeEpsilonValues(SolutionSet solutionSet, double [] maximumValues, double [] minimumValues, int numberOfObjectives) {
    SolutionSet A, B;
    // Initialize the structures
    indicatorValues_ = new ArrayList<List<Double>>();
    maxIndicatorValue_ = - Double.MAX_VALUE;

    for (int j = 0; j < solutionSet.size(); j++) {
	A = new SolutionSet(1);
	A.add(solutionSet.get(j));

	List<Double> aux = new ArrayList<Double>();
	for (int i = 0; i < solutionSet.size(); i++) {
	    B = new SolutionSet(1);
	    B.add(solutionSet.get(i));

	    double epsilon_value = 0.0;
	    double temp_epsilon_value;

	    double r = maximumValues[0] - minimumValues[0];
	    epsilon_value = (A.get(0).getObjective(0) - minimumValues[0]) / r - (B.get(0).getObjective(0) - minimumValues[0]) / r;
	    //epsilon_value = A.get(0).getObjective(0) - B.get(0).getObjective(0);

	    for (int obj = 1; obj < numberOfObjectives; obj++) {
		r = maximumValues[obj] - minimumValues[obj];
		temp_epsilon_value = (A.get(0).getObjective(obj) - minimumValues[obj]) / r - (B.get(0).getObjective(obj) - minimumValues[obj]) / r;
		//temp_epsilon_value = A.get(0).getObjective(obj) - B.get(0).getObjective(obj);

		if (temp_epsilon_value > epsilon_value) epsilon_value = temp_epsilon_value;
	    }

	    //Update the max value of the indicator
	    if (Math.abs(epsilon_value) > maxIndicatorValue_)
		maxIndicatorValue_ = Math.abs(epsilon_value);
	    aux.add(epsilon_value);
	}
	indicatorValues_.add(aux);
    }
} // computeIndicatorValues
      
public static void shuffleArray(int[] array, int array_size) {
    int rand_num = 0;
    int temp_var = 0;
  
    for(int i = 1; i < array_size; i++){
	rand_num = PseudoRandom.randInt(0, i - 1);
	temp_var = array[i];
	array[i] = array[rand_num];
	array[rand_num] = temp_var;
    }
}

/**
 * Performs the operation
 * @param object Object representing a SolutionSet
 * @return the selected solution
 */
public static Solution selectParent(SolutionSet population, int[] a_, int index_) {   
    Solution solution1,solution2;
    solution1 = population.get(a_[index_]);
    solution2 = population.get(a_[index_+1]);
                
    int flag = dominance_.compare(solution1,solution2);
    if (flag == -1)
	return solution1;
    else if (flag == 1)
	return solution2;
    else if (solution1.getCrowdingDistance() > solution2.getCrowdingDistance())
	return solution1;
    else if (solution2.getCrowdingDistance() > solution1.getCrowdingDistance())
	return solution2;
    else
	if (PseudoRandom.randDouble()<0.5)
	    return solution1;
	else
	    return solution2;        
} // execute

public static int[] getSortedIndeces(Solution targetInd, int targetIndID, SolutionSet population, Problem problem, double[] variablesUpperBounds, double[] variablesLowerBounds) throws JMException, ClassNotFoundException {
    double[] distanceFromTarget = new double[population.size()];
    int[] sortedIndeces = new int[population.size()];
    Variable[] variablesTarget  = targetInd.getDecisionVariables();
    double tmpSumVar;
    double tmpVar;

    for (int j = 0; j < population.size(); j++) {
	if (j == targetIndID) {
	    distanceFromTarget[j] = 1e+30;
	}
	else {
	    Variable[] variablesArchiveInds = population.get(j).getDecisionVariables();
	    tmpSumVar = 0;
	    
	    for (int k = 0; k < problem.getNumberOfVariables(); k++) {
		tmpVar = (variablesTarget[k].getValue() - variablesArchiveInds[k].getValue()) / (variablesUpperBounds[k] - variablesLowerBounds[k]);			    
		tmpSumVar += tmpVar * tmpVar;
	    }

	    distanceFromTarget[j] = Math.sqrt(tmpSumVar);
	}
    }
	
    for (int j = 0; j < population.size(); j++) sortedIndeces[j] = j;
    sortIndexWithQuickSort(distanceFromTarget, 0, population.size() - 1, sortedIndeces);
	
    return sortedIndeces;
}

public static void sortIndexWithQuickSort(double[] array, int first, int last, int[] index) {
    double x = array[(first + last) / 2];
    int i = first;
    int j = last;
    double temp_var = 0;
    int temp_num = 0;

    while (true) {
	while (array[i] < x) i++;
	while (x < array[j]) j--;      
	if (i >= j) break;

	temp_var = array[i];
	array[i] = array[j];
	array[j] = temp_var;

	temp_num = index[i];
	index[i] = index[j];
	index[j] = temp_num;

	i++;
	j--;
    }

    if (first < (i -1)) sortIndexWithQuickSort(array, first, i - 1, index);
    if ((j + 1) < last) sortIndexWithQuickSort(array, j + 1, last, index);
}

/** 
 * NSGA-II
 */
public static void runOriginalNSGAII(Function f, int dimension, int numberOfObjectives, int numberOfConstraints, double[] lowerBounds, double[] upperBounds, long maxBudget, Random randomGenerator, String problemInstanceName) throws JMException, ClassNotFoundException {
    // initialize problem parameters
    Problem problem = new BiobjBBOB(dimension, lowerBounds, upperBounds);
	
    // initialize control parameters for NSGA-II
    Operator mutationOperator;
    Operator crossoverOperator;
    Operator selectionOperator;
    Distance distance = new Distance();	    
    HashMap parameters;

    if (popSizeRate <= 0) populationSize = 100;
    else populationSize = (int)Math.floor(popSizeRate * Math.log(dimension));

    if (populationSize % 2 != 0) populationSize += 1;
	
    if (crossOperatorName.equals("SBX")) {			
	parameters = new HashMap();
	//	    parameters.put("probability", 1.0);
	parameters.put("probability", 0.9);
	parameters.put("distributionIndex", 20.0);
	crossoverOperator = CrossoverFactory.getCrossoverOperator("SBXCrossover", parameters);               
    }
    else if (crossOperatorName.equals("DE")) {
	parameters = new HashMap() ;
	parameters.put("CR", 1.0);
	parameters.put("F", 0.5);
	crossoverOperator = CrossoverFactory.getCrossoverOperator("DifferentialEvolutionCrossover", parameters);
    }
    else {
	System.out.println("Error! " + crossOperatorName + "is not defined");
	parameters = new HashMap() ;
	crossoverOperator = CrossoverFactory.getCrossoverOperator("SBXCrossover", parameters);                        
	System.exit(1);
    }
	
    parameters = new HashMap();
    parameters.put("probability", 1.0/problem.getNumberOfVariables());
    parameters.put("distributionIndex", 20.0);
    mutationOperator = MutationFactory.getMutationOperator("PolynomialMutation", parameters);                    

    parameters = null ;
    selectionOperator = SelectionFactory.getSelectionOperator("BinaryTournament2", parameters);
       
    int evaluations = 0;
    SolutionSet population;
    SolutionSet offspringPopulation;
    SolutionSet union;

    //Initialize the variables
    population = new SolutionSet(populationSize);

    // Create the initial solutionSet
    Solution newSolution;
	
    for (int i = 0; i < populationSize; i++) {
	newSolution = new Solution(problem);
	evaluateBiojectiveValues(f, dimension, newSolution);
	evaluations++;
	population.add(newSolution);
    }

    while (evaluations < maxBudget) {
	offspringPopulation = new SolutionSet(populationSize);	    

	if (crossOperatorName.equals("SBX")) {
	    Solution[] parents = new Solution[2];
	    for (int i = 0; i < populationSize/2; i++) {
		if (evaluations < maxBudget) {
		    parents[0] = (Solution) selectionOperator.execute(population);
		    parents[1] = (Solution) selectionOperator.execute(population);
		    Solution[] offSpring = (Solution[]) crossoverOperator.execute(parents);
		    mutationOperator.execute(offSpring[0]);
		    mutationOperator.execute(offSpring[1]);		    
		    evaluateBiojectiveValues(f, dimension, offSpring[0]);
		    evaluateBiojectiveValues(f, dimension, offSpring[1]);
		    offspringPopulation.add(offSpring[0]);
		    offspringPopulation.add(offSpring[1]);
		    evaluations += 2;
		} // if                            
	    } // for
	}
	else if (crossOperatorName.equals("DE")) {
	    Solution[] parents = new Solution[3];
	    int r1, r2;
		
	    for (int i = 0; i < populationSize; i++) {
		if (evaluations < maxBudget) {

		    // random selection
		    do {
			r1 = PseudoRandom.randInt(0, population.size() - 1);
		    } while (r1 == i);
		    do {
			r2 = PseudoRandom.randInt(0, population.size() - 1);
		    } while (r2 == i || r2 == r1);
	
		    parents[0] = population.get(i);
		    parents[1] = population.get(r1);
		    parents[2] = population.get(r2);
		    Solution child = (Solution) crossoverOperator.execute(new Object[]{population.get(i), parents});
		    //mutationOperator.execute(child);		    
		    evaluateBiojectiveValues(f, dimension, child);
		    offspringPopulation.add(child);
		    evaluations += 1;						
		}
	    }
	}
	else {
	    System.out.println("Error! " + crossOperatorName + " is not defined");
	    System.exit(-1);
	}
	    
	union = ((SolutionSet) population).union(offspringPopulation);	    
	Ranking ranking = new Ranking(union);

	int remain = populationSize;
	int index = 0;
	SolutionSet front = null;
	population.clear();			
	    
	front = ranking.getSubfront(index);

	while ((remain > 0) && (remain >= front.size())) {
	    //Assign crowding distance to individuals
	    distance.crowdingDistanceAssignment(front, problem.getNumberOfObjectives());
	    //Add the individuals of this front
	    for (int k = 0; k < front.size(); k++) {
		population.add(front.get(k));
	    } // for

	    //Decrement remain
	    remain = remain - front.size();

	    //Obtain the next front
	    index++;
	    if (remain > 0) {
		front = ranking.getSubfront(index);
	    } // if        
	} // while

	// Remain is less than front(index).size, insert only the best one
	if (remain > 0) {  // front contains individuals to insert                        
	    distance.crowdingDistanceAssignment(front, problem.getNumberOfObjectives());
	    front.sort(new CrowdingComparator());
	    for (int k = 0; k < remain; k++) {
		population.add(front.get(k));
	    } // for

	    remain = 0;
	} // if                               

    } // while

    // Output objective vectors of nondominated solutions in the final population
    // Ranking ranking = new Ranking(population);
    // ranking.getSubfront(0).printFeasibleFUN("finalobj_" + problemInstanceName + ".dat") ;
}

/** 
 * SMS-EMOA
 */
public static void runOriginalSMSEMOA(Function f, int dimension, int numberOfObjectives, int numberOfConstraints, double[] lowerBounds, double[] upperBounds, long maxBudget, Random randomGenerator, String problemInstanceName) throws JMException, ClassNotFoundException {
    double offset = 100.0;
    FastHypervolume fastHypervolume = new FastHypervolume(offset);       

    // initialize problem parameters
    Problem problem = new BiobjBBOB(dimension, lowerBounds, upperBounds);
	
    // initialize control parameters for NSGA-II
    Operator mutationOperator;
    Operator crossoverOperator;
    Operator selectionOperator;
    Distance distance = new Distance();	    
    HashMap parameters;

    populationSize = (int)Math.floor(popSizeRate * Math.log(dimension));

    if (popSizeRate <= 0) populationSize = 100;
    else populationSize = (int)Math.floor(popSizeRate * Math.log(dimension));

    // if (populationSize % 2 != 0) populationSize += 1;
	
    if (crossOperatorName.equals("SBX")) {			
	parameters = new HashMap();
	//	    parameters.put("probability", 1.0);
	parameters.put("probability", 0.9);
	parameters.put("distributionIndex", 20.0);
	crossoverOperator = CrossoverFactory.getCrossoverOperator("SBXCrossover", parameters);               
    }
    else if (crossOperatorName.equals("DE")) {
	parameters = new HashMap() ;
	parameters.put("CR", 1.0);
	parameters.put("F", 0.5);
	crossoverOperator = CrossoverFactory.getCrossoverOperator("DifferentialEvolutionCrossover", parameters);
    }
    else {
	System.out.println("Error! " + crossOperatorName + "is not defined");
	parameters = new HashMap() ;
	crossoverOperator = CrossoverFactory.getCrossoverOperator("SBXCrossover", parameters);                        
	System.exit(1);
    }
	
    parameters = new HashMap();
    parameters.put("probability", 1.0/problem.getNumberOfVariables());
    parameters.put("distributionIndex", 20.0);
    mutationOperator = MutationFactory.getMutationOperator("PolynomialMutation", parameters);                    
       
    parameters = null ;
    selectionOperator = SelectionFactory.getSelectionOperator("BinaryTournament2", parameters);
       
    int evaluations = 0;
    SolutionSet population;
    SolutionSet offspringPopulation;
    SolutionSet union;

    //Initialize the variables
    population = new SolutionSet(populationSize);

    // Create the initial solutionSet
    Solution newSolution;
	
    for (int i = 0; i < populationSize; i++) {
	newSolution = new Solution(problem);
	evaluateBiojectiveValues(f, dimension, newSolution);
	evaluations++;
	population.add(newSolution);
    }

    int deIndexCounter = 0;
	
    while (evaluations < maxBudget) {

	// select parents
	offspringPopulation = new SolutionSet(populationSize);

	if (crossOperatorName.equals("SBX")) {
	    LinkedList<Solution> selectedParents = new LinkedList<Solution>();
	    Solution[] parents = new Solution[0];
	    while (selectedParents.size() < 2) {
		Object selected = selectionOperator.execute(population);
		try {
		    Solution parent = (Solution) selected;
		    selectedParents.add(parent);
		} catch (ClassCastException e) {
		    parents = (Solution[]) selected;
		    Collections.addAll(selectedParents, parents);
		}
	    }
	    parents = selectedParents.toArray(parents);

	    // crossover
	    Solution[] offSpring = (Solution[]) crossoverOperator.execute(parents);

	    // mutation
	    mutationOperator.execute(offSpring[0]);

	    // evaluation      
	    evaluateBiojectiveValues(f, dimension, offSpring[0]);
	    offspringPopulation.add(offSpring[0]);
	    evaluations += 1;
	}
	else if (crossOperatorName.equals("DE")) {
	    Solution[] parents = new Solution[3];
	    int r1, r2;
		
	    // random selection
	    do {
		r1 = PseudoRandom.randInt(0, population.size() - 1);
	    } while (r1 == deIndexCounter);
	    do {
		r2 = PseudoRandom.randInt(0, population.size() - 1);
	    } while (r2 == deIndexCounter || r2 == r1);
	
	    parents[0] = population.get(deIndexCounter);
	    parents[1] = population.get(r1);
	    parents[2] = population.get(r2);
	    Solution child = (Solution) crossoverOperator.execute(new Object[]{population.get(deIndexCounter), parents});
	    //mutationOperator.execute(child);		    
	    evaluateBiojectiveValues(f, dimension, child);
	    offspringPopulation.add(child);
	    evaluations += 1;						

	    deIndexCounter += 1;
	    if (deIndexCounter >= populationSize) deIndexCounter = 0;
	}
	else {
	    System.out.println("Error! " + crossOperatorName + " is not defined");
	    System.exit(-1);
	}
	    
	union = ((SolutionSet) population).union(offspringPopulation);

	// Ranking the union (non-dominated sorting)
	Ranking ranking = new Ranking(union);

	// ensure crowding distance values are up to date
	// (may be important for parent selection)
	for (int j = 0; j < population.size(); j++) {
	    population.get(j).setCrowdingDistance(0.0);
	}

	SolutionSet lastFront = ranking.getSubfront(ranking.getNumberOfSubfronts() - 1);

	//FastHypervolume fastHypervolume = new FastHypervolume() ;
	fastHypervolume.computeHVContributions(lastFront);
	lastFront.sort(new CrowdingDistanceComparator());

	// all but the worst are carried over to the survivor population
	SolutionSet front = null;
	population.clear();
	for (int i = 0; i < ranking.getNumberOfSubfronts() - 1; i++) {
	    front = ranking.getSubfront(i);
	    for (int j = 0; j < front.size(); j++) {
		population.add(front.get(j));
	    }
	}
	for (int i = 0; i < lastFront.size() - 1; i++) {
	    population.add(lastFront.get(i));
	}

    } // while

    // Output objective vectors of nondominated solutions in the final population
    // Ranking ranking = new Ranking(population);
    // ranking.getSubfront(0).printFeasibleFUN("finalobj_" + problemInstanceName + ".dat") ;
}

/** 
 * IBEA 
 */
public static void runOriginalIBEA(Function f, int dimension, int numberOfObjectives, int numberOfConstraints, double[] lowerBounds, double[] upperBounds, long maxBudget, Random randomGenerator, String problemInstanceName) throws JMException, ClassNotFoundException {	
    // initialize problem parameters
    Problem problem = new BiobjBBOB(dimension, lowerBounds, upperBounds);
	
    Operator mutationOperator;
    Operator crossoverOperator;
    Operator selectionOperator;
    Distance distance = new Distance();	    
    HashMap parameters;
	
    populationSize = (int)Math.floor(popSizeRate * Math.log(dimension));

    if (popSizeRate <= 0) populationSize = 100;
    else populationSize = (int)Math.floor(popSizeRate * Math.log(dimension));

    // if (populationSize % 2 != 0) populationSize += 1;
	
    parameters = new HashMap();
    //	    parameters.put("probability", 1.0);
    parameters.put("probability", 0.9);
    parameters.put("distributionIndex", 20.0);
    crossoverOperator = CrossoverFactory.getCrossoverOperator("SBXCrossover", parameters);               
	
    parameters = new HashMap();
    parameters.put("probability", 1.0/problem.getNumberOfVariables());
    parameters.put("distributionIndex", 20.0);
    mutationOperator = MutationFactory.getMutationOperator("PolynomialMutation", parameters);                    
       
    parameters = new HashMap();
    parameters.put("comparator", new FitnessComparator());
    selectionOperator = new BinaryTournament(parameters);
    // System.out.println("-------------------------------");
	
    int evaluations = 0;
    SolutionSet population;
    SolutionSet offspringPopulation;

    //Initialize the variables
    population = new SolutionSet(populationSize);

    int archiveSize = populationSize;
    int TOURNAMENTS_ROUNDS = 1;

    SolutionSet solutionSet, archive, offSpringSolutionSet;
 
    //Initialize the variables
    solutionSet  = new SolutionSet(populationSize);
    archive     = new SolutionSet(archiveSize);
    evaluations = 0;

    //-> Create the initial solutionSet
    Solution newSolution;
    for (int i = 0; i < populationSize; i++) {
	newSolution = new Solution(problem);
	evaluateBiojectiveValues(f, dimension, newSolution);
	evaluations++;
	solutionSet.add(newSolution);
    }

    while (evaluations < maxBudget){
	SolutionSet union = ((SolutionSet)solutionSet).union(archive);
	calculateFitnessEpsilon(union, problem.getNumberOfObjectives());
	archive = union;
      
	while (archive.size() > populationSize) {
	    removeWorst(archive);
	}

	// Create a new offspringPopulation
	offSpringSolutionSet= new SolutionSet(populationSize);
	Solution  [] parents = new Solution[2];
	//      while (offSpringSolutionSet.size() < populationSize){
	while (offSpringSolutionSet.size() < populationSize){  
	    int j = 0;
	    do{
		j++;
		parents[0] = (Solution)selectionOperator.execute(archive);
	    } while (j < TOURNAMENTS_ROUNDS); // do-while
	    int k = 0;
	    do{
		k++;
		parents[1] = (Solution)selectionOperator.execute(archive);
	    } while (k < TOURNAMENTS_ROUNDS); // do-while

	    //make the crossover
	    Solution [] offSpring = (Solution [])crossoverOperator.execute(parents);
	    mutationOperator.execute(offSpring[0]);
	    evaluateBiojectiveValues(f, dimension, offSpring[0]);	       
	    offSpringSolutionSet.add(offSpring[0]);
	    evaluations++;
	} // while

	// End Create a offSpring solutionSet
	solutionSet = offSpringSolutionSet;
    } // while

    SolutionSet union = ((SolutionSet)solutionSet).union(archive);
    calculateFitnessEpsilon(union, problem.getNumberOfObjectives());
    archive = union;
      
    while (archive.size() > populationSize) {
	removeWorst(archive);
    }

    // Output objective vectors of nondominated solutions in the final populationSize
    // Ranking ranking = new Ranking(archive);
    // ranking.getSubfront(0).printFeasibleFUN("finalobj_" + problemInstanceName + ".dat") ;
} // execute
    

/** 
 * Update the fitness before removing an individual
 */
public static void removeWorst(SolutionSet solutionSet) {
   
    // Find the worst;
    double worst      = solutionSet.get(0).getFitness();
    int    worstIndex = 0;
    double kappa = 0.05;
     
    for (int i = 1; i < solutionSet.size(); i++) {
	if (solutionSet.get(i).getFitness() > worst) {
	    worst = solutionSet.get(i).getFitness();
	    worstIndex = i;
	}
    }

    // Update the population
    for (int i = 0; i < solutionSet.size(); i++) {
	if (i!=worstIndex) {
	    double fitness = solutionSet.get(i).getFitness();
	    fitness -= Math.exp((- indicatorValues_.get(worstIndex).get(i)/maxIndicatorValue_) / kappa);
	    solutionSet.get(i).setFitness(fitness);
	}
    }

    // remove worst from the indicatorValues list
    indicatorValues_.remove(worstIndex); // Remove its own list
    Iterator<List<Double>> it = indicatorValues_.iterator();
    while (it.hasNext())
	it.next().remove(worstIndex);

    // remove the worst individual from the population
    solutionSet.remove(worstIndex);
} // removeWorst

/** 
 * SPEA2 
 */
public static void runOriginalSPEA2(Function f, int dimension, int numberOfObjectives, int numberOfConstraints, double[] lowerBounds, double[] upperBounds, long maxBudget, Random randomGenerator, String problemInstanceName) throws JMException, ClassNotFoundException {	
    // initialize problem parameters
    Problem problem = new BiobjBBOB(dimension, lowerBounds, upperBounds);
	
    Operator mutationOperator;
    Operator crossoverOperator;
    Operator selectionOperator;
    Distance distance = new Distance();	    
    HashMap parameters;
	
    populationSize = (int)Math.floor(popSizeRate * Math.log(dimension));

    if (popSizeRate <= 0) populationSize = 100;
    else populationSize = (int)Math.floor(popSizeRate * Math.log(dimension));

    // if (populationSize % 2 != 0) populationSize += 1;
	
    parameters = new HashMap();
    //	    parameters.put("probability", 1.0);
    parameters.put("probability", 0.9);
    parameters.put("distributionIndex", 20.0);
    crossoverOperator = CrossoverFactory.getCrossoverOperator("SBXCrossover", parameters);               
	
    parameters = new HashMap();
    parameters.put("probability", 1.0/problem.getNumberOfVariables());
    parameters.put("distributionIndex", 20.0);
    mutationOperator = MutationFactory.getMutationOperator("PolynomialMutation", parameters);                    
       
    parameters = new HashMap();
    parameters.put("comparator", new FitnessComparator());
    selectionOperator = new BinaryTournament(parameters);
    // System.out.println("-------------------------------");
	
    int evaluations = 0;
    SolutionSet population;
    SolutionSet offspringPopulation;

    //Initialize the variables
    population = new SolutionSet(populationSize);

    int archiveSize = populationSize;
    int TOURNAMENTS_ROUNDS = 1;

    SolutionSet solutionSet, archive, offSpringSolutionSet;
 
    //Initialize the variables
    solutionSet  = new SolutionSet(populationSize);
    archive     = new SolutionSet(archiveSize);
    evaluations = 0;

    //-> Create the initial solutionSet
    Solution newSolution;
    for (int i = 0; i < populationSize; i++) {
	newSolution = new Solution(problem);
	evaluateBiojectiveValues(f, dimension, newSolution);
	evaluations++;
	solutionSet.add(newSolution);
    }
	
    while (evaluations < maxBudget){
	SolutionSet union = ((SolutionSet)solutionSet).union(archive);
	Spea2Fitness spea = new Spea2Fitness(union);
	spea.fitnessAssign();
	archive = spea.environmentalSelection(archiveSize);                       

	// Create a new offspringPopulation
	offSpringSolutionSet= new SolutionSet(populationSize);    
	Solution  [] parents = new Solution[2];
	while (offSpringSolutionSet.size() < populationSize){           
	    int j = 0;
	    do{
		j++;                
		parents[0] = (Solution)selectionOperator.execute(archive);
	    } while (j < TOURNAMENTS_ROUNDS); // do-while                    
	    int k = 0;
	    do{
		k++;                
		parents[1] = (Solution)selectionOperator.execute(archive);
	    } while (k < TOURNAMENTS_ROUNDS); // do-while
            
	    //make the crossover 
	    Solution [] offSpring = (Solution [])crossoverOperator.execute(parents);            
	    mutationOperator.execute(offSpring[0]);            
	    evaluateBiojectiveValues(f, dimension, offSpring[0]);
	    offSpringSolutionSet.add(offSpring[0]);
	    evaluations++;
	} // while
	// End Create a offSpring solutionSet
	solutionSet = offSpringSolutionSet;                   
    } // while

    // Output objective vectors of nondominated solutions in the final populationSize
    // Ranking ranking = new Ranking(archive);
    // ranking.getSubfront(0).printFeasibleFUN("finalobj_" + problemInstanceName + ".dat") ;
} // execute       
}
