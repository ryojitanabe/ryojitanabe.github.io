This package includes jMetal implementations of evolutionary multi-objective optimization algorithms with the BA, BF, and BC environmental selections for the bi-objective BBOB test problem suite. For details of the BA, BF, and BC selections, please refer to the following paper:

Ryoji Tanabe and Hisao Ishibuchi: Non-elitist Evolutionary Multi-objective Optimizers Revisited, Proc. ACM Genetic and Evolutionary Computation Conference (GECCO2019)

This package also includes NSGA-II, SPEA2, IBEA, and SMS-EMOA. The jMetal 4.5 framework (http://jmetal.sourceforge.net/) and the COCO software (https://github.com/numbbo/coco) were used for the implementation. The author of this code is Ryoji Tanabe (rt.ryoji.tanabe [at] gmail.com, https://ryojitanabe.github.io/). If you have any troubles, please let him know.

[How to run]

Step 1. Generate the shared library "libCocoJNI.so".

The old libCocoJNI.so should be replaced with the new one to correctly run the program on your computer. The easiest way is to use "do.py" in the COCO software (https://github.com/numbbo/coco). After "python do.py run-java" in COCO, you can copy code-experiments/build/java/libCocoJNI.so to this package. README.md also introduces how to compile the shared library without do.py.

Step 2. Compile Java files.

Please type the following on your terminal.

javac *java

Step 3. Run ExampleExperiment

Please type the following on your terminal.

java -Djava.library.path=. ExampleExperiment

The default setting is an EMOA with the BF environmental selection, the SPX crossover, and the ranking method in NSGA-II (BF-SPX-NS). For details, please see the main method in ExampleExperiment.java. It will take 3 or 4 hours to finish the run.
