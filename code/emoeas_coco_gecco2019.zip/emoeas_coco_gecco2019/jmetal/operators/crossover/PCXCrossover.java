//  PCXCrossover.java
//
//  Author:
//       Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2019 Ryoji Tanabe
//
// NOTE:
// This is a translated version of the implementation of G3PCX (http://www.iitk.ac.in/kangal/codes/g3pcx/g3pcx.tar) by Dr. Kalyanmoy Deb
// Most comments are as is
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.operators.crossover;

import jmetal.core.Solution;
import jmetal.encodings.solutionType.ArrayRealSolutionType;
import jmetal.encodings.solutionType.RealSolutionType;
import jmetal.util.Configuration;
import jmetal.util.JMException;
import jmetal.util.PseudoRandom;
import jmetal.util.wrapper.XReal;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

/**
 * This class allows to apply a PCX crossover operator using two parent
 * solutions.
 */
public class PCXCrossover extends Crossover {                                                                                      

    /**
     * Valid solution types to apply this operator 
     */
    private static final List VALID_TYPES = Arrays.asList(RealSolutionType.class,
							  ArrayRealSolutionType.class) ;

    private static final double EPSILON = 1e-40;
    private int numParents_;
    private int numChildren_;
        
    /** 
     * Constructor
     * Create a new PCX crossover operator whit a default
     * index given by <code>DEFAULT_INDEX_CROSSOVER</code>
     */
    public PCXCrossover(HashMap<String, Object> parameters) {
  	super (parameters) ;

	if (parameters.get("numParents") != null) numParents_ = (Integer) parameters.get("numParents");  		
	if (parameters.get("numChildren") != null) numChildren_ = (Integer) parameters.get("numChildren");  		       
    } // PCXCrossover

    /*
      Return random value from normal distribution with mean "mu" and variance "gamma"
      http://www.sat.t.u-tokyo.ac.jp/~omi/random_variables_generation.html#Gauss
    */
    public double gauss(double mu, double sigma){
	return mu + sigma * Math.sqrt(-2.0 * Math.log(PseudoRandom.randDouble())) * Math.sin(2.0 * Math.PI * PseudoRandom.randDouble());
    }
    
    /**
     * Perform the crossover operation. 
     * @param probability Crossover probability
     * @param parent1 The first parent
     * @param parent2 The second parent
     * @return An array containing the two offsprings
     */
    public Object execute(Object object) throws JMException {	
	Object[] parameters = (Object[])object ;
	Solution[] parents = (Solution [])parameters[0];	
    	Solution[] offSpring = new Solution[numChildren_];	       
	XReal[] xParents = new XReal[numParents_];

	for (int i = 0; i < numParents_; i++) {
	    xParents[i] = new XReal(parents[i]);
	}
	
	int numberOfVariables = xParents[0].getNumberOfDecisionVariables() ;
	double sigma_eta = 0.1;
	double sigma_zeta = 0.1;
       	double[] centerOfGravity = new double[numberOfVariables];
	double[] d = new double[numberOfVariables];
	double[][] diff = new double[numParents_][numberOfVariables];
	double[] D = new double[numParents_];
	double[] tempar1 = new double[numberOfVariables];
	double[] tempar2 = new double[numberOfVariables];
  	
	for (int i = 0; i < numberOfVariables; i++) {
	    double tmpSumValue = 0;
	    for (int j = 0; j < numParents_; j++) {
		tmpSumValue += xParents[j].getValue(i);
	    }

	    centerOfGravity[i] = tmpSumValue / numParents_;	    
	}

	for (int i = 0; i < numChildren_; i++) {
	    offSpring[i] = new Solution(parents[0]);
	    XReal xOff = new XReal(offSpring[i]);

	    //	    int centerParentID = 0;
	    int centerParentID = PseudoRandom.randInt(0, numParents_ - 1);
	    
	    for (int j = 0; j < numberOfVariables; j++) {
		d[j] = centerOfGravity[j] - xParents[centerParentID].getValue(j);
	    }
	    
	    for (int j = 0; j < numParents_; j++) {
		for (int k = 0; k < numberOfVariables; k++) {
		    diff[j][k] = xParents[j].getValue(k) - xParents[centerParentID].getValue(k);
		}
	    }

	    double dist = modu(d, numberOfVariables); // modu calculates the magnitude of the vector

	    // if (dist < EPSILON) {	
	    // 	System.out.println("Points are very close to each other. Quitting this run");
	    // 	//		return null;
	    // 	//		System.exit(-1);
	    // }

	    double temp1, temp2, temp3;
	    double moduValue;
	    
	    // orthogonal directions are computed (see the paper)
	    for (int j = 0; j < numParents_; j++) {
		if (j != centerParentID) {
		    moduValue = modu(diff[j], numberOfVariables);
		    temp1 = innerprod(diff[j], d, numberOfVariables);
		    temp2 = temp1 / (moduValue * dist);
		    temp3 = 1.0 - Math.pow(temp2, 2.0);
		    if (temp3 < 0) temp3 = 0;
		    D[j] = moduValue * Math.sqrt(temp3);
		}
	    }

	    double D_not = 0;
	    for(int j = 0; j < numParents_; j++) {
		if (j != centerParentID) {
		    D_not += D[j];
		}
	    }

	    D_not /= (numParents_ - 1); //this is the average of the perpendicular distances from all other parents (minus the index parent) to the index vector

	    // Next few steps compute the child, by starting with a random vector
	    for (int j = 0; j < numberOfVariables; j++) {
		tempar1[j] = gauss(0.0, D_not * sigma_eta);
		// System.out.println(tempar1[j]);
		tempar2[j] = tempar1[j];
	    }

	    double innerprodValue = innerprod(tempar1, d, numberOfVariables);
	    for (int j = 0; j < numberOfVariables; j++) {
		tempar2[j] = tempar1[j] - ((innerprodValue * d[j])/Math.pow(dist,2.0));
	    }
  
	    for (int j = 0; j < numberOfVariables; j++) {
		tempar1[j]=tempar2[j];
	    }

	    double tempvar = gauss(0.0,(sigma_zeta));

	    for (int j = 0; j < numberOfVariables; j++) {

		if (Double.isNaN(tempar1[j])) {
		    tempar1[j] = 0;
		}

		double tmpValue = xParents[centerParentID].getValue(j) + (tempvar * d[j]) + tempar1[j];
		
		if (tmpValue < xOff.getLowerBound(j)) tmpValue =  xOff.getLowerBound(j);
		if (tmpValue > xOff.getUpperBound(j)) tmpValue =  xOff.getUpperBound(j);
		xOff.setValue(j, tmpValue);	   
	    }
	}
	
	return offSpring;                                                                                      
    } // doCrossover


    // calculates the magnitude of a vector
    double modu(double index[], int numberOfVariables)
    {
	int i;
	double sum,modul;
  
	sum=0.0;
	for(i=0;i<numberOfVariables;i++)
	    sum+=(index[i]*index[i]);
  
	modul=Math.sqrt(sum);
	return modul;
    }   

    // calculates the inner product of two vectors
    double innerprod(double ind1[],double ind2[], int numberOfVariables)
    {
	int i;
	double sum;
  
	sum=0.0;
  
	for(i=0;i<numberOfVariables;i++)
	    sum+=(ind1[i]*ind2[i]);
  
	return sum;
    }      
} // PCXCrossover
