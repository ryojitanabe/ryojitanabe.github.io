//  REXCrossover.java
//
//  Author:
//       Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2019 Ryoji Tanabe
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.operators.crossover;

import jmetal.core.Solution;
import jmetal.encodings.solutionType.ArrayRealSolutionType;
import jmetal.encodings.solutionType.RealSolutionType;
import jmetal.util.Configuration;
import jmetal.util.JMException;
import jmetal.util.PseudoRandom;
import jmetal.util.wrapper.XReal;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

/**
 * This class allows to apply a REX crossover operator using two parent
 * solutions.
 */
public class REXCrossover extends Crossover {                                                                                      

    /**
     * Valid solution types to apply this operator 
     */
    private static final List VALID_TYPES = Arrays.asList(RealSolutionType.class,
							  ArrayRealSolutionType.class) ;

    private int numParents_;
    private int numChildren_;
    
    /** 
     * Constructor
     * Create a new REX crossover operator whit a default
     * index given by <code>DEFAULT_INDEX_CROSSOVER</code>
     */
    public REXCrossover(HashMap<String, Object> parameters) {
  	super (parameters) ;

	if (parameters.get("numParents") != null) numParents_ = (Integer) parameters.get("numParents");  		
	if (parameters.get("numChildren") != null) numChildren_ = (Integer) parameters.get("numChildren");  		       
    } // REXCrossover


    /*
      Return random value from normal distribution with mean "mu" and variance "gamma"
      http://www.sat.t.u-tokyo.ac.jp/~omi/random_variables_generation.html#Gauss
    */
    public double gauss(double mu, double sigma){
	return mu + sigma * Math.sqrt(-2.0 * Math.log(PseudoRandom.randDouble())) * Math.sin(2.0 * Math.PI * PseudoRandom.randDouble());
    }
    
    /**
     * Perform the crossover operation. 
     * @param probability Crossover probability
     * @param parent1 The first parent
     * @param parent2 The second parent
     * @return An array containing the two offsprings
     */
    public Object execute(Object object) throws JMException {	
	Object[] parameters = (Object[])object ;
	Solution[] parents = (Solution [])parameters[0];	
    	Solution[] offSpring = new Solution[numChildren_];	       
	XReal[] xParents = new XReal[numParents_];

	for (int i = 0; i < numParents_; i++) {
	    xParents[i] = new XReal(parents[i]);
	}

	int numberOfVariables = xParents[0].getNumberOfDecisionVariables() ;
	double randomVariance = 1.0 / Math.sqrt((numberOfVariables));
	double[] centerOfGravity = new double[numberOfVariables];
	double[] randomOffset = new double[numberOfVariables];
	
	for (int i = 0; i < numberOfVariables; i++) {
	    double tmpSumValue = 0;
	    for (int j = 0; j < numParents_; j++) {
		tmpSumValue += xParents[j].getValue(i);
	    }

	    centerOfGravity[i] = tmpSumValue / numParents_;	    
	}
	
	for (int i = 0; i < numChildren_; i++) {
	    offSpring[i] = new Solution(parents[1]);
	    XReal xOff = new XReal(offSpring[i]) ;

	    for (int j = 0; j < numberOfVariables; j++) {
		randomOffset[j] = 0;
	    }
	    
	    for (int j = 0; j < numParents_; j++) {
		double randomValue = gauss(0, randomVariance);
		// double aValue = Math.sqrt(3.0/(numParents_));
		// double maxRndValue = Math.sqrt(3.0/(numParents_));
		// double minRndValue = -Math.sqrt(3.0/(numParents_));
		// double randomValue = (maxRndValue - minRndValue) * PseudoRandom.randDouble() + minRndValue;		
		
		for (int k = 0; k < numberOfVariables; k++) {
		    randomOffset[k] += randomValue * (xParents[j].getValue(k) - centerOfGravity[k]);
		}	       
	    }

	    for (int j = 0; j < numberOfVariables; j++) {
		double tmpValue = centerOfGravity[j] + randomOffset[j];

		if (tmpValue < xOff.getLowerBound(j)) tmpValue =  xOff.getLowerBound(j);
		if (tmpValue > xOff.getUpperBound(j)) tmpValue =  xOff.getUpperBound(j);
		xOff.setValue(j, tmpValue);
	    }
	}
	
	return offSpring;                                                                                      
    } // doCrossover
    
} // REXCrossover
