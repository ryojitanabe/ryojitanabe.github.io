//  SPXCrossover.java
//
//  Author:
//       Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2019 Ryoji Tanabe
//
// NOTE:
// This is based on the implementation of MOEA Framework of SPX (http://moeaframework.org/) by Dr. David Hadka
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.operators.crossover;

import jmetal.core.Solution;
import jmetal.encodings.solutionType.ArrayRealSolutionType;
import jmetal.encodings.solutionType.RealSolutionType;
import jmetal.util.Configuration;
import jmetal.util.JMException;
import jmetal.util.PseudoRandom;
import jmetal.util.wrapper.XReal;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

/**
 * This class allows to apply a SPX crossover operator using two parent
 * solutions.
 */
public class SPXCrossover extends Crossover {                                                                                      

    /**
     * Valid solution types to apply this operator 
     */
    private static final List VALID_TYPES = Arrays.asList(RealSolutionType.class,
							  ArrayRealSolutionType.class) ;

    private int numParents_;
    private int numChildren_;
    
    /** 
     * Constructor
     * Create a new SPX crossover operator whit a default
     * index given by <code>DEFAULT_INDEX_CROSSOVER</code>
     */
    public SPXCrossover(HashMap<String, Object> parameters) {
  	super (parameters) ;

	if (parameters.get("numParents") != null) numParents_ = (Integer) parameters.get("numParents");  		
	if (parameters.get("numChildren") != null) numChildren_ = (Integer) parameters.get("numChildren");  		       
    } // SPXCrossover
    
    /**
     * Perform the crossover operation. 
     * @param probability Crossover probability
     * @param parent1 The first parent
     * @param parent2 The second parent
     * @return An array containing the two offsprings
     */
    public Object execute(Object object) throws JMException {	
	Object[] parameters = (Object[])object ;
	Solution[] parents = (Solution [])parameters[0];	
    	Solution[] offSpring = new Solution[numChildren_];	       
	XReal[] xParents = new XReal[numParents_];

	for (int i = 0; i < numParents_; i++) {
	    xParents[i] = new XReal(parents[i]);
	}
	
	int numberOfVariables = xParents[0].getNumberOfDecisionVariables() ;
	double expansionRate = Math.sqrt(numberOfVariables + 2.0);
	double[] centerOfGravity = new double[numberOfVariables];
	double[][] simplexVertices = new double[numParents_][numberOfVariables];
	double[] randomOffset = new double[numberOfVariables];
	
	for (int i = 0; i < numberOfVariables; i++) {
	    double tmpSumValue = 0;
	    for (int j = 0; j < numParents_; j++) {
		tmpSumValue += xParents[j].getValue(i);
	    }

	    centerOfGravity[i] = tmpSumValue / numParents_;	    
	}

	for (int i = 0; i < numParents_; i++) {
	    for (int j = 0; j < numberOfVariables; j++) {	
		simplexVertices[i][j] = centerOfGravity[j] + expansionRate * (xParents[i].getValue(j) - centerOfGravity[j]);
	    }
	}
	
	for (int i = 0; i < numChildren_; i++) {
	    offSpring[i] = new Solution(parents[0]);
	    XReal xOff = new XReal(offSpring[i]) ;

	    for (int j = 0; j < numberOfVariables; j++) {
		randomOffset[j] = 0;
	    }
		
	    for (int j = 1; j < numParents_; j++) {
		double rndValue = Math.pow(PseudoRandom.randDouble(), 1.0 / j);
		
		for (int k = 0; k < numberOfVariables; k++) {
		    randomOffset[k] = rndValue * (simplexVertices[j - 1][k] - simplexVertices[j][k] + randomOffset[k]);		    
		}		    
	    }

	    for (int k = 0; k < numberOfVariables; k++) {
		double tmpValue = simplexVertices[numParents_ - 1][k] + randomOffset[k];

		if (tmpValue < xOff.getLowerBound(k)) tmpValue =  xOff.getLowerBound(k);
		if (tmpValue > xOff.getUpperBound(k)) tmpValue =  xOff.getUpperBound(k);
		xOff.setValue(k, tmpValue);
	    }
	}
	
	return offSpring;                                                                                      
    } // doCrossover
    
} // SPXCrossover
