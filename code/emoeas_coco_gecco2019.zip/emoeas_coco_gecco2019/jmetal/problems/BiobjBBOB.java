//  BiobjBBOB.java
//
//  Author:
//       Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
//  Copyright (c) 2019 Ryoji Tanabe
// 
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.
package jmetal.problems;

import jmetal.core.Problem;
import jmetal.core.Solution;
import jmetal.core.Variable;
import jmetal.encodings.solutionType.RealSolutionType;
import jmetal.util.JMException;

/**
 * Class representing problem BiobjBBOB
 */
public class BiobjBBOB extends Problem {  
     
  /** 
   * Constructor.
   * Creates a new instance of the BiobjBBOB problem.
   */
    public BiobjBBOB(int numberOfVariables, double[] lowerLimit, double[] upperLimit) {
	numberOfVariables_   = numberOfVariables;
	numberOfObjectives_  = 2;
	numberOfConstraints_ = 0;
	problemName_         = "BiobjBBOB";
        
	upperLimit_ = new double[numberOfVariables_] ;
	lowerLimit_ = new double[numberOfVariables_] ;
       
	for (int i = 0; i < numberOfVariables_; i++) {
	    lowerLimit_[i] = lowerLimit[i];
	    upperLimit_[i] = upperLimit[i];
	}
        
	solutionType_ = new RealSolutionType(this);
    } // BiobjBBOB
    
    /** 

     * This function is not used
     * Evaluates a solution 
     * @param solution The solution to evaluate
     * @throws JMException 
     */
    public void evaluate(Solution solution) throws JMException {
    }
} // BiobjBBOB
