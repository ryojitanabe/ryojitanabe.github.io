//  SpeedReducerDesign.java
//
//  Author:
//       Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
// Reference:
//  C. A. C. Coello and G. T. Pulido, “Multiobjective structural optimization using a microgenetic algorithm,” Stru. and Multi. Opt., vol. 30, no. 5, pp. 388–403, 2005
//
//  Copyright (c) 2017 Ryoji Tanabe
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.problems;

import jmetal.core.Problem;
import jmetal.core.Solution;
import jmetal.encodings.solutionType.BinaryRealSolutionType;
import jmetal.encodings.solutionType.RealSolutionType;
import jmetal.util.JMException;

/**
 * Class representing problem Speed reducer design
 */
public class SpeedReducerDesign extends Problem {
  
    // defining the lower and upper limits
    public static final double [] LOWERLIMIT = {2.6, 0.7, 17, 7.3, 7.3, 2.9, 5.0};
    public static final double [] UPPERLIMIT = {3.6, 0.8, 28, 8.3, 8.3, 3.9, 5.5};                          

    /**
     * Constructor.
     * Creates a default instance of the Speed reducer design problem.
     * @param solutionType The solution type must "Real" or "BinaryReal".
     */
    public SpeedReducerDesign(String solutionType) {
	numberOfVariables_   = 7;
	numberOfObjectives_  = 2;
	numberOfConstraints_ = 11 ;
	problemName_         = "SpeedReducerDesign";
	        
	upperLimit_ = new double[numberOfVariables_];
	lowerLimit_ = new double[numberOfVariables_];
	upperLimit_ = new double[numberOfVariables_];
	lowerLimit_ = new double[numberOfVariables_];
	for (int var = 0; var < numberOfVariables_; var++){
	    lowerLimit_[var] = LOWERLIMIT[var];
	    upperLimit_[var] = UPPERLIMIT[var];
	} // for
	        
	if (solutionType.compareTo("BinaryReal") == 0)
	    solutionType_ = new BinaryRealSolutionType(this) ;
	else if (solutionType.compareTo("Real") == 0)
	    solutionType_ = new RealSolutionType(this) ;
	else {
	    System.out.println("Error: solution type " + solutionType + " invalid") ;
	    System.exit(-1) ;
	}  
    } // SpeedReducerDesign
	
    /**
     * Evaluates a solution
     * @param solution The solution to evaluate
     * @throws JMException 
     */
    public void evaluate(Solution solution) throws JMException {         
	double [] x = new double[7] ; // 7 decision variables
	double [] f = new double[2] ; // 2 functions
	x[0] = solution.getDecisionVariables()[0].getValue();
	x[1] = solution.getDecisionVariables()[1].getValue();
	x[2] = solution.getDecisionVariables()[2].getValue();
	x[3] = solution.getDecisionVariables()[3].getValue();
	x[4] = solution.getDecisionVariables()[4].getValue();
	x[5] = solution.getDecisionVariables()[5].getValue();
	x[6] = solution.getDecisionVariables()[6].getValue();
    
	// First function (weight)
	f[0] = 0.7854 * x[0] * (x[1] * x[1]) * (((10.0 * x[2] * x[2]) / 3.0) + (14.933 * x[2]) - 43.0934)
	    - 1.508 * x[0] * (x[5] * x[5] + x[6] * x[6])
	    + 7.477 * (x[5] * x[5] * x[5] + x[6] * x[6] * x[6])
	    + 0.7854 * (x[3] * x[5] * x[5] + x[4] * x[6] * x[6]);
    
	// // Second function (stress)
	double tmp_val = Math.pow((745.0 * x[3]) / (x[1] * x[2]), 2.0)  + 1.69 * 1e7;
	f[1] =  Math.sqrt(tmp_val) / (0.1 * x[5] * x[5] * x[5]);
    
	solution.setObjective(0,f[0]);    
	solution.setObjective(1,f[1]);
    } // evaluate

    /** 
     * Evaluates the constraint overhead of a solution 
     * @param solution The solution
     * @throws JMException 
     */  
    public void evaluateConstraints(Solution solution) throws JMException {
	double [] constraint = new double[11]; // 11 constraints
	double [] x          = new double[7]; // 7 variables
        
	x[0] = solution.getDecisionVariables()[0].getValue();
	x[1] = solution.getDecisionVariables()[1].getValue();
	x[2] = solution.getDecisionVariables()[2].getValue();
	x[3] = solution.getDecisionVariables()[3].getValue();
	x[4] = solution.getDecisionVariables()[4].getValue();
	x[5] = solution.getDecisionVariables()[5].getValue();
	x[6] = solution.getDecisionVariables()[6].getValue();
 
	constraint[0] = -(1.0 / (x[0] * x[1] * x[1] * x[2])) + 1.0 / 27.0;
	constraint[1] = -(1.0 / (x[0] * x[1] * x[1] * x[2] * x[2])) + 1.0 / 397.5;
	constraint[2] = -(x[3] * x[3] * x[3]) / (x[1] * x[2] * x[5] * x[5] * x[5] * x[5]) + 1.0 / 1.93;
	constraint[3] = -(x[4] * x[4] * x[4]) / (x[1] * x[2] * x[6] * x[6] * x[6] * x[6]) + 1.0 / 1.93;
	constraint[4] = -(x[1] * x[2]) + 40.0;
	constraint[5] = -(x[0] / x[1]) + 12.0;
	constraint[6] = -5.0 + (x[0] / x[1]);
	constraint[7] = -1.9 + x[3] - 1.5 * x[5];
	constraint[8] = -1.9 + x[4] - 1.1 * x[6];
        
	constraint[9] =  -solution.getObjective(1) + 1300.0;
	double tmp_val = Math.pow((745.0 * x[4]) / (x[1] * x[2]), 2.0) + 1.575 * 1e8;
	constraint[10] = -Math.sqrt(tmp_val) / (0.1 * x[6] * x[6] * x[6]) + 1100.0;
    
    
	double total = 0.0;
	int number = 0;

	for (int i = 0; i < numberOfConstraints_; i++) {
	    if (constraint[i]<0.0){
		total+= -constraint[i];
		number++;
	    } // int
	} // for

       
	// for (int i = 0; i < numberOfConstraints_; i++) {
	// 	if (constraint[i] < 0.0) solution.setEachConstraintViolation(i, -constraint[i]);    
	// 	else solution.setEachConstraintViolation(i, 0.0);    
	// }
    
	solution.setOverallConstraintViolation(total);    
	solution.setNumberOfViolatedConstraint(number);        
    } // evaluateConstraints   
} // SpeedReducerDesign
