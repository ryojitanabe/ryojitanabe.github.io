//  TwoBarTrussDesign.java
//
//  Author:
//       Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
// Reference:
//  C. A. C. Coello and G. T. Pulido, “Multiobjective structural optimization using a microgenetic algorithm,” Stru. and Multi. Opt., vol. 30, no. 5, pp. 388–403, 2005.
//
//  Copyright (c) 2017 Ryoji Tanabe
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.problems;

import jmetal.core.Problem;
import jmetal.core.Solution;
import jmetal.encodings.solutionType.BinaryRealSolutionType;
import jmetal.encodings.solutionType.RealSolutionType;
import jmetal.util.JMException;

/**
 * Class representing problem Welded Beam
 */
public class TwoBarTrussDesign extends Problem {
  
  // defining the lower and upper limits
    //    public static final double [] LOWERLIMIT = {0.0, 0.0, 1.0};
    public static final double [] LOWERLIMIT = {0.00001, 0.00001, 1.0};
    public static final double [] UPPERLIMIT = {100.0, 100.0, 3.0};                          

    // public static final double [] LOWERLIMIT = {0.0, 0.0, 1};
    // public static final double [] UPPERLIMIT = {???, ???, 3.0};                          

 /**
  * Constructor.
  * Creates a default instance of the Welded Beam problem.
  * @param solutionType The solution type must "Real" or "BinaryReal".
  */
  public TwoBarTrussDesign(String solutionType) {
    numberOfVariables_   = 3;
    numberOfObjectives_  = 2;
    numberOfConstraints_ = 3;
    problemName_         = "TwoBarTrussDesign";
	        
    upperLimit_ = new double[numberOfVariables_];
    lowerLimit_ = new double[numberOfVariables_];
    upperLimit_ = new double[numberOfVariables_];
    lowerLimit_ = new double[numberOfVariables_];
    for (int var = 0; var < numberOfVariables_; var++){
      lowerLimit_[var] = LOWERLIMIT[var];
      upperLimit_[var] = UPPERLIMIT[var];
    } // for
	        
    if (solutionType.compareTo("BinaryReal") == 0)
      solutionType_ = new BinaryRealSolutionType(this) ;
    else if (solutionType.compareTo("Real") == 0)
    	solutionType_ = new RealSolutionType(this) ;
    else {
    	System.out.println("Error: solution type " + solutionType + " invalid") ;
    	System.exit(-1) ;
    }  
 } // TwoBarTrussDesign
	
  /**
   * Evaluates a solution
   * @param solution The solution to evaluate
   * @throws JMException 
   */
  public void evaluate(Solution solution) throws JMException {         
    double [] x = new double[3] ; // 3 decision variables
    double [] f = new double[2] ; // 2  functions
    x[0] = solution.getDecisionVariables()[0].getValue(); // x1
    x[1] = solution.getDecisionVariables()[1].getValue(); // x2
    x[2] = solution.getDecisionVariables()[2].getValue(); // y
   
    // First function
    f[0] = x[0] * Math.pow(16.0 + (x[2] * x[2]), 0.5) + x[1] * Math.pow(1.0 + x[2] * x[2], 0.5);
    // Second function
    f[1] = (20.0 * Math.pow(16.0 + (x[2] * x[2]), 0.5)) / (x[0] * x[2]);
             
    solution.setObjective(0,f[0]);    
    solution.setObjective(1,f[1]);
  } // evaluate

  /** 
   * Evaluates the constraint overhead of a solution 
   * @param solution The solution
   * @throws JMException 
   */  
  public void evaluateConstraints(Solution solution) throws JMException {
    double [] constraint = new double[3]; // 3 constraints
    double [] x          = new double[3]; // 3 variables
    double [] f          = new double[2]; // 2 functions
        
    x[0] = solution.getDecisionVariables()[0].getValue(); // x1
    x[1] = solution.getDecisionVariables()[1].getValue(); // x2
    x[2] = solution.getDecisionVariables()[2].getValue();  // y

    f[0] = solution.getObjective(0);
    f[1] = solution.getObjective(1);
    
    constraint[0] = 0.1 - f[0];
    constraint[1] = 100000.0 - f[1];
    constraint[2] = 100000 - ((80.0 * Math.pow(1.0 + x[2] * x[2], 0.5)) / (x[1] * x[2]));
    
    double total = 0.0;
    int number = 0;

    for (int i = 0; i < numberOfConstraints_; i++) {
      if (constraint[i]<0.0){
        total+= -constraint[i];
        number++;
      } // int
    } // for


    // for (int i = 0; i < numberOfConstraints_; i++) {
    // 	if (constraint[i] < 0.0) solution.setEachConstraintViolation(i, -constraint[i]);    
    // 	else solution.setEachConstraintViolation(i, 0.0);    
    // }
        
    solution.setOverallConstraintViolation(total);    
    solution.setNumberOfViolatedConstraint(number);        
  } // evaluateConstraints   
} // TwoBarTrussDesign
