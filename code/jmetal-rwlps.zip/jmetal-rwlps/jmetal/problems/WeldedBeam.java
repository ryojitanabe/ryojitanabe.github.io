//  WeldedBeam.java
//
//  Author:
//       Ryoji Tanabe <rt.ryoji.tanabe@gmail.com>
//
// Reference:
//  T. Ray and K. M. Liew, “A swarm metaphor for multiobjective design optimization,” Eng. opt., vol. 34, no. 2, pp. 141–153, 2002.
//
//  Copyright (c) 2017 Ryoji Tanabe
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package jmetal.problems;

import jmetal.core.Problem;
import jmetal.core.Solution;
import jmetal.encodings.solutionType.BinaryRealSolutionType;
import jmetal.encodings.solutionType.RealSolutionType;
import jmetal.util.JMException;

/**
 * Class representing problem Welded Beam
 */
public class WeldedBeam extends Problem {
  
  // defining the lower and upper limits
    public static final double [] LOWERLIMIT = {0.125, 0.00001, 0.1, 0.00001};
    public static final double [] UPPERLIMIT = {30.0, 5.0, 30.0, 10.0};                          

    // public static final double [] LOWERLIMIT = {0.125, ???, 0.1, ???};
    // public static final double [] UPPERLIMIT = {???, 5.0, ???, 10.0};                          

 /**
  * Constructor.
  * Creates a default instance of the Welded Beam problem.
  * @param solutionType The solution type must "Real" or "BinaryReal".
  */
  public WeldedBeam(String solutionType) {
    numberOfVariables_   = 4;
    numberOfObjectives_  = 2;
    numberOfConstraints_ = 4;
    problemName_         = "WeldedBeam";
	        
    upperLimit_ = new double[numberOfVariables_];
    lowerLimit_ = new double[numberOfVariables_];
    upperLimit_ = new double[numberOfVariables_];
    lowerLimit_ = new double[numberOfVariables_];
    for (int var = 0; var < numberOfVariables_; var++){
      lowerLimit_[var] = LOWERLIMIT[var];
      upperLimit_[var] = UPPERLIMIT[var];
    } // for
	        
    if (solutionType.compareTo("BinaryReal") == 0)
      solutionType_ = new BinaryRealSolutionType(this) ;
    else if (solutionType.compareTo("Real") == 0)
    	solutionType_ = new RealSolutionType(this) ;
    else {
    	System.out.println("Error: solution type " + solutionType + " invalid") ;
    	System.exit(-1) ;
    }  
 } // WeldedBeam
	
  /**
   * Evaluates a solution
   * @param solution The solution to evaluate
   * @throws JMException 
   */
  public void evaluate(Solution solution) throws JMException {         
    double [] x = new double[4] ; // 4 decision variables
    double [] f = new double[2] ; // 2  functions
    x[0] = solution.getDecisionVariables()[0].getValue();
    x[1] = solution.getDecisionVariables()[1].getValue();
    x[2] = solution.getDecisionVariables()[2].getValue();
    x[3] = solution.getDecisionVariables()[3].getValue();
   
    // First function
    f[0] = (1.10471 * x[0] * x[0] * x[2]) + (0.04811 * x[3] * x[1]) * (14.0 + x[3]);
    // Second function
    f[1] = 2.1952 / (x[3] * x[3] * x[3] *  x[1]);
             
    solution.setObjective(0,f[0]);    
    solution.setObjective(1,f[1]);
  } // evaluate

  /** 
   * Evaluates the constraint overhead of a solution 
   * @param solution The solution
   * @throws JMException 
   */  
  public void evaluateConstraints(Solution solution) throws JMException {
    double [] constraint = new double[4]; // 4 constraints
    double [] x          = new double[4]; // 4 variables
        
    x[0] = solution.getDecisionVariables()[0].getValue(); // h
    x[1] = solution.getDecisionVariables()[1].getValue(); // b
    x[2] = solution.getDecisionVariables()[2].getValue();  // l
    x[3] = solution.getDecisionVariables()[3].getValue(); // t
 
    double tmp_val1 = 6000.0 / (Math.sqrt(2.0) * x[0] * x[2]); 
    double tmp_val2_part1 = 6000.0 * (14.0 + (0.5 * x[2])) * Math.sqrt(0.25 * (x[2] * x[2] + (x[0] + x[3]) * (x[0] + x[3])));
    double tmp_val2_part2 = 0.707 * x[0] * x[2] * (((x[2] * x[2]) / 12.0) + 0.25 * (x[2] * x[2] + (x[0] + x[3]) * (x[0] + x[3])));
    tmp_val2_part2 *= 2.0;
    double tmp_val2 = tmp_val2_part1 / tmp_val2_part2;
    double tmp_val3 = (tmp_val1 * tmp_val1) + (tmp_val2 * tmp_val2) + (x[2] * tmp_val1 * tmp_val2 / Math.sqrt(0.25 * (x[2] * x[2] + (x[0] + x[3]) * (x[0] + x[3]))));

    constraint[0] = 13600.0 - Math.sqrt(tmp_val3);
    constraint[1] = 30000.0 - (504000.0 / (x[3] * x[3] * x[1]));
    constraint[2] = x[1] - x[0];
    constraint[3] = 64764.022 * (1.0 - (0.0282346 * x[3])) * (x[3] * x[1] * x[1] * x[1]) - 6000.0;

      double total = 0.0;
    int number = 0;

    for (int i = 0; i < numberOfConstraints_; i++) {
      if (constraint[i]<0.0){
        total+= -constraint[i];
        number++;
      } // int
    } // for


    // for (int i = 0; i < numberOfConstraints_; i++) {
    // 	if (constraint[i] < 0.0) solution.setEachConstraintViolation(i, -constraint[i]);    
    // 	else solution.setEachConstraintViolation(i, 0.0);    
    // }

    solution.setOverallConstraintViolation(total);    
    solution.setNumberOfViolatedConstraint(number);        
  } // evaluateConstraints   
} // WeldedBeam
