Author: Ryoji Tanabe (rt.ryoji.tanabe@gmail.com)

This jMetal package includes the source code of seven real-world problems, which were used in the experimental study of the following paper:

* Ryoji Tanabe, Akira Oyama: A Note on Constrained Multi-Objective Optimization Benchmark Problems, IEEE CEC2017, pp. 1127-1134 (2017)

For details, please see the following files, respectively:

(1) The two bar truss design problem: jmetal/problems/TwoBarTrussDesign.java
(2) The speed reducer design problem: jmetal/problems/SpeedReducerDesign.java
(3) The disc brake design problem: jmetal/problems/DiscBrakeDesign.java
(4) The welded beam problem: jmetal/problems/WeldedBeam.java
(5) The car side impact problem: jmetal/problems/CarSideImpact.java
(6) The ship parametric design problem: jmetal/problems/ShipParametricDesign.java
(7) The water problem: jmetal/problems/Water.java

Except for the file "Water.java", which is an existing program in the original jMetal 4.5 package, I newly implemented all the remained problems according to the description for each reference. CNSGA-II will be applied for the two bar truss design problem in the default setting. For details, please see "jmetal/metaheuristics/nsgaII/NSGAII_main.java".

If you found a bug in those files, please let me know!
